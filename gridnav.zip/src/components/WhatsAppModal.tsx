import React, { useState, useEffect } from 'react';
import { MessageSquare, Copy, Check, X, Phone, User, Send, ExternalLink } from 'lucide-react';
import { cleanPhoneNumber, getWhatsAppUrl } from '../utils/whatsapp';

interface WhatsAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  recipientName: string;
  defaultPhone?: string;
  messageText: string;
}

export const WhatsAppModal: React.FC<WhatsAppModalProps> = ({
  isOpen,
  onClose,
  title,
  recipientName,
  defaultPhone = '',
  messageText,
}) => {
  const [phone, setPhone] = useState(defaultPhone);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setPhone(defaultPhone);
  }, [defaultPhone]);

  if (!isOpen) return null;

  const cleanPhone = cleanPhoneNumber(phone);
  const whatsappUrl = getWhatsAppUrl(phone, messageText);

  const handleCopy = () => {
    navigator.clipboard.writeText(messageText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-1.5 rounded-full bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 text-stone-500 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-700 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
            <MessageSquare className="w-5 h-5 text-emerald-600" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-emerald-300">{title}</h3>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              إرسال رسالة مفصلة مباشرة عبر تطبيق واتساب
            </p>
          </div>
        </div>

        {/* Recipient Details & Phone Input */}
        <div className="bg-stone-50 dark:bg-stone-800/60 p-3.5 rounded-2xl border border-stone-200 dark:border-stone-700 mb-4 space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 font-bold text-stone-600 dark:text-stone-300">
              <User className="w-3.5 h-3.5 text-emerald-600" />
              <span>المستلم:</span>
            </span>
            <span className="font-extrabold text-stone-900 dark:text-stone-100 text-sm">{recipientName}</span>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-600 dark:text-stone-300 mb-1">
              رقم الواتساب:
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="077... أو 77... أو مع رمز الدولة"
                dir="ltr"
                className="w-full pl-3 pr-9 py-2 bg-white dark:bg-stone-900 border border-stone-300 dark:border-stone-600 rounded-xl text-sm font-mono font-bold text-stone-900 dark:text-stone-100 focus:ring-2 focus:ring-emerald-600 outline-none text-right"
              />
            </div>
            <div className="flex items-center justify-between text-[11px] text-stone-400 mt-1">
              <span>{cleanPhone ? `الرقم المعتمد: +${cleanPhone}` : 'يمكنك ترك الرقم فارغاً لاختيار جهة الاتصال في واتساب مباشرة'}</span>
            </div>
          </div>
        </div>

        {/* WhatsApp Message Bubble Preview */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-bold text-stone-600 dark:text-stone-300">
              معاينة نص الرسالة:
            </span>
            <button
              onClick={handleCopy}
              className="text-xs text-emerald-700 dark:text-emerald-400 hover:text-emerald-800 font-bold flex items-center gap-1 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ!' : 'نسخ النص'}</span>
            </button>
          </div>

          <div className="bg-[#e7fedb] dark:bg-[#153424] text-stone-900 dark:text-emerald-100 border border-emerald-300 dark:border-emerald-700/60 rounded-2xl p-3.5 text-xs sm:text-sm font-sans whitespace-pre-line leading-relaxed max-h-56 overflow-y-auto shadow-inner">
            {messageText}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2.5">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={onClose}
            className="flex-1 py-3 px-4 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-stone-950 font-black text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>📱 إرسال عبر واتساب الآن</span>
            <ExternalLink className="w-3.5 h-3.5 opacity-70" />
          </a>

          <button
            onClick={onClose}
            className="px-4 py-3 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 font-bold text-xs sm:text-sm transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
