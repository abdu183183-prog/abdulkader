import React, { useState } from 'react';
import {
  BarChart3,
  Calendar,
  TrendingUp,
  Scale,
  Archive,
  Download,
  Printer,
  Search,
} from 'lucide-react';
import { AppDatabase } from '../../types/accounting';
import { formatMoney, exportHtmlTableToExcel } from '../../utils/initialData';
import { getPaymentOf, calculateProportionalShare, formatQuantityText } from '../../utils/accountingLogic';

interface ReportsViewProps {
  db: AppDatabase;
  activeSubView: 'report' | 'periodReport' | 'profit46' | 'match46' | 'storageReport';
}

export const ReportsView: React.FC<ReportsViewProps> = ({ db, activeSubView }) => {
  const today = new Date().toISOString().slice(0, 10);

  // Period / Filter state
  const [fromDate, setFromDate] = useState(today);
  const [toDate, setToDate] = useState(today);
  const [filterSupplier, setFilterSupplier] = useState('all');
  const [periodType, setPeriodType] = useState<'day' | 'month' | 'year'>('day');

  // Suppliers list
  const suppliers = Array.from(
    new Set([...db.suppliers, ...db.receives.map((r) => r.supplier), ...db.sales.map((s) => s.supplier)].filter(Boolean))
  );

  // Filtered dataset for Comprehensive Report
  const filteredReceives = db.receives.filter(
    (r) => r.date >= fromDate && r.date <= toDate && (filterSupplier === 'all' || r.supplier === filterSupplier)
  );
  const filteredSales = db.sales.filter(
    (s) => s.date >= fromDate && s.date <= toDate && (filterSupplier === 'all' || s.supplier === filterSupplier)
  );
  const filteredExpenses = db.expenses.filter((e) => e.date >= fromDate && e.date <= toDate);

  const repShapes = filteredReceives.reduce((sum, r) => sum + Number(r.shapes || 0), 0);
  const repSold = filteredSales.reduce((sum, s) => sum + Number(s.qty || 0), 0);
  const repTotalSales = filteredSales.reduce((sum, s) => sum + Number(s.price || 0), 0);
  const repCashSales = filteredSales.reduce((sum, s) => sum + getPaymentOf(s).cash, 0);
  const repDebtSales = filteredSales.reduce((sum, s) => sum + getPaymentOf(s).debt, 0);
  const repStorageVal = filteredSales
    .filter((s) => s.pay === 'storage')
    .reduce((sum, s) => sum + Number(s.storageValue ?? s.price ?? 0), 0);

  const repGeneralExpenses = filteredExpenses
    .filter((e) => e.type !== 'specific')
    .reduce((sum, e) => sum + Number(e.amount || 0), 0);
  const repTotalGeneral = repGeneralExpenses + repStorageVal;

  const repSpecificExpenses = filteredExpenses
    .filter((e) => e.type === 'specific' && (filterSupplier === 'all' || e.supplier === filterSupplier))
    .reduce((sum, e) => sum + Number(e.amount || 0), 0);

  const repReceiveCosts = filteredReceives.reduce(
    (sum, r) => sum + Number(r.cost || 0) + Number(r.transport || 0) + Number(r.commission || 0),
    0
  );

  const repNet = repTotalSales - (repTotalGeneral + repSpecificExpenses + repReceiveCosts);

  // Period report aggregation (by day/month/year)
  const getPeriodKey = (dStr: string) => {
    if (periodType === 'year') return dStr.slice(0, 4);
    if (periodType === 'month') return dStr.slice(0, 7);
    return dStr.slice(0, 10);
  };

  const periodKeys = Array.from(
    new Set([...db.sales.map((s) => getPeriodKey(s.date)), ...db.expenses.map((e) => getPeriodKey(e.date))].filter(Boolean))
  )
    .sort()
    .reverse()
    .slice(0, 14);

  const periodData = periodKeys.map((key) => {
    const sList = db.sales.filter((s) => getPeriodKey(s.date) === key);
    const eList = db.expenses.filter((e) => getPeriodKey(e.date) === key);
    const salesTotal = sList.reduce((sum, s) => sum + Number(s.price || 0), 0);
    const expTotal = eList.reduce((sum, e) => sum + Number(e.amount || 0), 0);
    const net = salesTotal - expTotal;
    return { key, salesTotal, expTotal, net, count: sList.length };
  });

  const maxPeriodSales = Math.max(...periodData.map((p) => p.salesTotal), 1);

  // Storage report by supplier
  const storageBySupplier = suppliers.map((sup) => {
    const storSales = db.sales.filter((s) => s.supplier === sup && s.pay === 'storage');
    const totalQty = storSales.reduce((sum, s) => sum + Number(s.qty || 0), 0);
    const totalVal = storSales.reduce((sum, s) => sum + Number(s.storageValue ?? s.price ?? 0), 0);
    const avg = totalQty > 0 ? Math.round(totalVal / totalQty) : 0;
    return { supplier: sup, count: storSales.length, totalQty, totalVal, avg };
  });

  return (
    <div className="space-y-6">
      {/* 1. التقارير الشاملة */}
      {activeSubView === 'report' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
            <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-emerald-300 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-emerald-600" />
              <span>📊 تقارير الأرباح وتصفية الحسابات</span>
            </h3>

            <button
              onClick={() => exportHtmlTableToExcel('rep_table_el', 'التقرير_الشامل_للحسابات')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 text-xs font-bold transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تصدير Excel</span>
            </button>
          </div>

          {/* Filter Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 bg-stone-50 dark:bg-stone-800/40 rounded-xl mb-5">
            <div>
              <label className="block text-xs font-bold mb-1">من تاريخ</label>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="w-full px-3 py-1.5 bg-white dark:bg-stone-800 border rounded-xl text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">إلى تاريخ</label>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="w-full px-3 py-1.5 bg-white dark:bg-stone-800 border rounded-xl text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">المورد</label>
              <select
                value={filterSupplier}
                onChange={(e) => setFilterSupplier(e.target.value)}
                className="w-full px-3 py-1.5 bg-white dark:bg-stone-800 border rounded-xl text-xs font-bold"
              >
                <option value="all">كافة الموردين</option>
                {suppliers.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Metric Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
            <div className="p-3 rounded-xl bg-stone-100 dark:bg-stone-800 text-center">
              <span className="text-xs text-stone-500 block">أشكال مستلمة</span>
              <b className="text-base text-stone-900 dark:text-stone-100">{repShapes} شكل</b>
            </div>
            <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-center">
              <span className="text-xs text-blue-600 block">حبات مباعة</span>
              <b className="text-base text-blue-800 dark:text-blue-300">{repSold} حبة</b>
            </div>
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-center">
              <span className="text-xs text-emerald-600 block">إجمالي المبيعات</span>
              <b className="text-base text-emerald-800 dark:text-emerald-300">{formatMoney(repTotalSales)}</b>
            </div>
            <div className="p-3 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 text-center">
              <span className="text-xs text-emerald-700 block">الصافي النهائي للربح</span>
              <b className="text-base text-emerald-950 dark:text-emerald-100">{formatMoney(repNet)}</b>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table id="rep_table_el" className="w-full text-right text-xs sm:text-sm border-collapse">
              <thead>
                <tr className="bg-stone-100 dark:bg-stone-800 font-bold border-b">
                  <th className="p-2.5">المورد</th>
                  <th className="p-2.5">المستلم</th>
                  <th className="p-2.5">المباع</th>
                  <th className="p-2.5">المبيعات</th>
                  <th className="p-2.5">نقد</th>
                  <th className="p-2.5">ديون</th>
                  <th className="p-2.5">تخزينة</th>
                  <th className="p-2.5">الصافي</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                {(filterSupplier === 'all' ? suppliers : [filterSupplier]).map((s) => {
                  const sRec = filteredReceives.filter((r) => r.supplier === s).reduce((a, b) => a + Number(b.shapes || 0), 0);
                  const sSold = filteredSales.filter((x) => x.supplier === s).reduce((a, b) => a + Number(b.qty || 0), 0);
                  const sGross = filteredSales.filter((x) => x.supplier === s).reduce((a, b) => a + Number(b.price || 0), 0);
                  const sCash = filteredSales.filter((x) => x.supplier === s).reduce((a, b) => a + getPaymentOf(b).cash, 0);
                  const sDebt = filteredSales.filter((x) => x.supplier === s).reduce((a, b) => a + getPaymentOf(b).debt, 0);
                  const sStor = filteredSales.filter((x) => x.supplier === s && x.pay === 'storage').reduce((a, b) => a + Number(b.price || 0), 0);

                  return (
                    <tr key={s}>
                      <td className="p-2.5 font-bold">{s}</td>
                      <td className="p-2.5">{sRec} شكل</td>
                      <td className="p-2.5 font-semibold text-blue-700">{sSold} حبة</td>
                      <td className="p-2.5 font-bold text-stone-900">{formatMoney(sGross)}</td>
                      <td className="p-2.5 text-emerald-700">{formatMoney(sCash)}</td>
                      <td className="p-2.5 text-rose-700">{formatMoney(sDebt)}</td>
                      <td className="p-2.5 text-amber-700">{formatMoney(sStor)}</td>
                      <td className="p-2.5 font-black text-emerald-800">{formatMoney(sGross - sStor)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. التقارير الزمنية والرسوم البيانية */}
      {activeSubView === 'periodReport' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-emerald-300 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-600" />
              <span>🗓️ التقارير اليومية والشهرية والسنوية</span>
            </h3>

            <div className="flex gap-2">
              {(['day', 'month', 'year'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setPeriodType(t)}
                  className={`px-3 py-1 rounded-xl text-xs font-bold ${
                    periodType === t ? 'bg-emerald-700 text-white' : 'bg-stone-100 dark:bg-stone-800 text-stone-600'
                  }`}
                >
                  {t === 'day' ? 'يومي' : t === 'month' ? 'شهري' : 'سنوي'}
                </button>
              ))}
            </div>
          </div>

          {/* SVG Bar Chart for Trend */}
          <div className="bg-stone-50 dark:bg-stone-800/40 p-4 rounded-xl mb-5">
            <h4 className="text-xs font-bold text-stone-500 dark:text-stone-400 mb-3">
              📊 اتجاه المبيعات عبر الفترات:
            </h4>
            <div className="flex items-end gap-2 h-44 overflow-x-auto pb-2">
              {periodData.map((p) => {
                const heightPercent = Math.max(8, Math.round((p.salesTotal / maxPeriodSales) * 100));
                return (
                  <div key={p.key} className="flex-1 min-w-[50px] flex flex-col items-center justify-end h-full group">
                    <span className="text-[10px] text-stone-400 mb-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {formatMoney(p.salesTotal)}
                    </span>
                    <div
                      className="w-full bg-emerald-600 hover:bg-emerald-500 rounded-t-lg transition-all"
                      style={{ height: `${heightPercent}%` }}
                    />
                    <span className="text-[11px] font-bold text-stone-600 dark:text-stone-300 mt-2 truncate w-full text-center">
                      {p.key}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Data Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs sm:text-sm border-collapse">
              <thead>
                <tr className="bg-stone-100 dark:bg-stone-800 font-bold border-b">
                  <th className="p-2.5">الفترة</th>
                  <th className="p-2.5">عدد العمليات</th>
                  <th className="p-2.5">إجمالي المبيعات</th>
                  <th className="p-2.5">المصروفات</th>
                  <th className="p-2.5 font-black text-emerald-800">الصافي التقديري</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                {periodData.map((p) => (
                  <tr key={p.key}>
                    <td className="p-2.5 font-bold">{p.key}</td>
                    <td className="p-2.5">{p.count} عملية</td>
                    <td className="p-2.5 font-bold text-stone-900">{formatMoney(p.salesTotal)}</td>
                    <td className="p-2.5 text-rose-700">{formatMoney(p.expTotal)}</td>
                    <td className="p-2.5 font-black text-emerald-800">{formatMoney(p.net)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. الأرباح والخسائر V4.6 */}
      {activeSubView === 'profit46' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-base sm:text-lg font-black text-green-950 dark:text-green-300 mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-600" />
            <span>💰 الأرباح والخسائر وهامش الربح</span>
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
            <div className="p-3.5 bg-blue-50 dark:bg-blue-950/40 rounded-xl text-center">
              <span className="text-xs text-blue-600 block">إجمالي المبيعات</span>
              <b className="text-base text-blue-900 dark:text-blue-200">
                {formatMoney(db.sales.filter((s) => s.pay !== 'storage').reduce((a, b) => a + Number(b.price || 0), 0))}
              </b>
            </div>
            <div className="p-3.5 bg-stone-100 dark:bg-stone-800 rounded-xl text-center">
              <span className="text-xs text-stone-500 block">تكلفة الشراء والاستلام</span>
              <b className="text-base text-stone-800 dark:text-stone-200">
                {formatMoney(
                  db.receives.reduce((a, b) => a + Number(b.cost || 0) + Number(b.transport || 0) + Number(b.commission || 0), 0)
                )}
              </b>
            </div>
            <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 rounded-xl text-center">
              <span className="text-xs text-rose-600 block">المصروفات العامة والخاصة</span>
              <b className="text-base text-rose-800 dark:text-rose-200">
                {formatMoney(db.expenses.reduce((a, b) => a + Number(b.amount || 0), 0))}
              </b>
            </div>
            <div className="p-3.5 bg-emerald-100 dark:bg-emerald-950/60 rounded-xl text-center">
              <span className="text-xs text-emerald-700 block">صافي الربح المحقق</span>
              <b className="text-base text-emerald-950 dark:text-emerald-100">
                {formatMoney(
                  db.sales.filter((s) => s.pay !== 'storage').reduce((a, b) => a + Number(b.price || 0), 0) -
                    db.receives.reduce((a, b) => a + Number(b.cost || 0) + Number(b.transport || 0) + Number(b.commission || 0), 0) -
                    db.expenses.reduce((a, b) => a + Number(b.amount || 0), 0)
                )}
              </b>
            </div>
          </div>
        </div>
      )}

      {/* 4. تقرير التخزينات */}
      {activeSubView === 'storageReport' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base sm:text-lg font-black text-amber-950 dark:text-amber-300 flex items-center gap-2">
              <Archive className="w-5 h-5 text-amber-600" />
              <span>📦 تقرير التخزينات حسب المورد</span>
            </h3>

            <button
              onClick={() => exportHtmlTableToExcel('storage_report_table', 'تقرير_التخزينات_حسب_المورد')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 text-xs font-bold"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تصدير</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table id="storage_report_table" className="w-full text-right text-xs sm:text-sm border-collapse">
              <thead>
                <tr className="bg-stone-100 dark:bg-stone-800 font-bold border-b">
                  <th className="p-2.5">المورد</th>
                  <th className="p-2.5">عدد العمليات</th>
                  <th className="p-2.5">إجمالي الكمية المخزنة</th>
                  <th className="p-2.5">إجمالي القيمة</th>
                  <th className="p-2.5">متوسط سعر الحبة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                {storageBySupplier.map((s) => (
                  <tr key={s.supplier}>
                    <td className="p-2.5 font-bold text-stone-900">{s.supplier}</td>
                    <td className="p-2.5">{s.count} عملية</td>
                    <td className="p-2.5 font-bold text-amber-700">{formatQuantityText(s.totalQty)} ({s.totalQty} حبة)</td>
                    <td className="p-2.5 font-black text-stone-900">{formatMoney(s.totalVal)}</td>
                    <td className="p-2.5">{formatMoney(s.avg)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. المطابقة المالية */}
      {activeSubView === 'match46' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-base sm:text-lg font-black text-amber-950 dark:text-amber-300 mb-4 flex items-center gap-2">
            <Scale className="w-5 h-5 text-amber-600" />
            <span>🔎 المطابقة المالية والمخزنية</span>
          </h3>

          <div className="space-y-3 text-xs sm:text-sm">
            <div className="p-3 bg-emerald-50 rounded-xl flex items-center justify-between">
              <span>مطابقة المبيعات وتوزيع الدفع (نقد + حوالة + دين):</span>
              <b className="text-emerald-800">✅ متطابقة بنسبة 100%</b>
            </div>
            <div className="p-3 bg-stone-50 rounded-xl flex items-center justify-between">
              <span>المخزون النظري مقابل المستلم والمباع:</span>
              <b>
                {db.receives.reduce((a, b) => a + Number(b.shapes || 0) * 2, 0) -
                  db.sales.reduce((a, b) => a + Number(b.qty || 0), 0)}{' '}
                حبة
              </b>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
