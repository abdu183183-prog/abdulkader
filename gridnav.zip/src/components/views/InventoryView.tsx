import React, { useState } from 'react';
import { Boxes, Search, Download, Printer } from 'lucide-react';
import { AppDatabase } from '../../types/accounting';
import { formatMoney, exportHtmlTableToExcel } from '../../utils/initialData';

interface InventoryViewProps {
  db: AppDatabase;
}

export const InventoryView: React.FC<InventoryViewProps> = ({ db }) => {
  const [search, setSearch] = useState('');

  const suppliers = Array.from(
    new Set([...db.suppliers, ...db.receives.map((r) => r.supplier), ...db.sales.map((s) => s.supplier)].filter(Boolean))
  );

  const inventoryData = suppliers.map((supplier) => {
    const receivedPieces = db.receives
      .filter((r) => r.supplier === supplier)
      .reduce((sum, r) => sum + Number(r.shapes || 0) * 2, 0);

    const soldPieces = db.sales
      .filter((s) => s.supplier === supplier && s.pay !== 'storage')
      .reduce((sum, s) => sum + Number(s.qty || 0), 0);

    const storagePieces = db.sales
      .filter((s) => s.supplier === supplier && s.pay === 'storage')
      .reduce((sum, s) => sum + Number(s.qty || 0), 0);

    const remainingStock = receivedPieces - (soldPieces + storagePieces);

    const receiveCost = db.receives
      .filter((r) => r.supplier === supplier)
      .reduce((sum, r) => sum + Number(r.cost || 0) + Number(r.transport || 0) + Number(r.commission || 0), 0);

    const unitCost = receivedPieces > 0 ? Math.round(receiveCost / receivedPieces) : 0;
    const estimatedValue = Math.max(0, remainingStock) * unitCost;

    return {
      supplier,
      receivedPieces,
      soldPieces,
      storagePieces,
      remainingStock,
      receiveCost,
      unitCost,
      estimatedValue,
      status:
        remainingStock < 0
          ? '❌ عجز'
          : remainingStock === 0
          ? '✅ مصفّى'
          : remainingStock <= 4
          ? '⚠️ منخفض'
          : '🟢 متوفر',
    };
  });

  const totalReceived = inventoryData.reduce((a, b) => a + b.receivedPieces, 0);
  const totalSold = inventoryData.reduce((a, b) => a + b.soldPieces, 0);
  const totalStorage = inventoryData.reduce((a, b) => a + b.storagePieces, 0);
  const totalStock = totalReceived - totalSold - totalStorage;
  const totalCost = inventoryData.reduce((a, b) => a + b.receiveCost, 0);
  const totalEstimatedValue = inventoryData.reduce((a, b) => a + b.estimatedValue, 0);

  const filtered = inventoryData.filter((i) => !search || i.supplier.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
      {/* Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-3.5 rounded-2xl shadow-sm text-center">
          <span className="text-xs text-stone-500 block">إجمالي المستلم</span>
          <b className="text-base sm:text-xl text-stone-900 dark:text-stone-100">{totalReceived} حبة</b>
        </div>
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-3.5 rounded-2xl shadow-sm text-center">
          <span className="text-xs text-blue-600 block">إجمالي المباع</span>
          <b className="text-base sm:text-xl text-blue-700 dark:text-blue-300">{totalSold} حبة</b>
        </div>
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-3.5 rounded-2xl shadow-sm text-center">
          <span className="text-xs text-amber-600 block">إجمالي التخزين</span>
          <b className="text-base sm:text-xl text-amber-700 dark:text-amber-300">{totalStorage} حبة</b>
        </div>
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-3.5 rounded-2xl shadow-sm text-center">
          <span className="text-xs text-emerald-600 block">المخزون المتبقي</span>
          <b className="text-base sm:text-xl text-emerald-700 dark:text-emerald-300">{totalStock} حبة</b>
        </div>
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-3.5 rounded-2xl shadow-sm text-center">
          <span className="text-xs text-stone-500 block">تكلفة الاستلام</span>
          <b className="text-xs sm:text-sm text-stone-800 dark:text-stone-200">{formatMoney(totalCost)}</b>
        </div>
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-3.5 rounded-2xl shadow-sm text-center">
          <span className="text-xs text-emerald-600 block">قيمة المخزون المقدرة</span>
          <b className="text-xs sm:text-sm text-emerald-800 dark:text-emerald-300">{formatMoney(totalEstimatedValue)}</b>
        </div>
      </div>

      {/* Main Inventory Table */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              placeholder="🔍 بحث في المخزون والموردين..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-3 pr-9 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => exportHtmlTableToExcel('inv_table_el', 'تقرير_المخزون_والتكلفة')}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 text-xs font-bold transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تصدير Excel</span>
            </button>
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 text-stone-700 dark:text-stone-300 text-xs font-bold transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table id="inv_table_el" className="w-full text-right text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-stone-100 dark:bg-stone-800 text-emerald-900 dark:text-emerald-300 font-bold border-b border-stone-200 dark:border-stone-700">
                <th className="p-2.5">المورد</th>
                <th className="p-2.5">المستلم</th>
                <th className="p-2.5">المباع</th>
                <th className="p-2.5">التخزين</th>
                <th className="p-2.5">المتبقي</th>
                <th className="p-2.5">تكلفة الاستلام</th>
                <th className="p-2.5">متوسط تكلفة الحبة</th>
                <th className="p-2.5">قيمة المخزون المقدرة</th>
                <th className="p-2.5">الحالة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
              {filtered.map((item) => (
                <tr key={item.supplier} className="hover:bg-stone-50 dark:hover:bg-stone-800/50">
                  <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{item.supplier}</td>
                  <td className="p-2.5">{item.receivedPieces}</td>
                  <td className="p-2.5 text-blue-700 dark:text-blue-400 font-semibold">{item.soldPieces}</td>
                  <td className="p-2.5 text-amber-700 dark:text-amber-400">{item.storagePieces}</td>
                  <td
                    className={`p-2.5 font-black ${
                      item.remainingStock < 0
                        ? 'text-rose-600'
                        : item.remainingStock <= 4
                        ? 'text-amber-600'
                        : 'text-emerald-600'
                    }`}
                  >
                    {item.remainingStock}
                  </td>
                  <td className="p-2.5">{formatMoney(item.receiveCost)}</td>
                  <td className="p-2.5">{formatMoney(item.unitCost)}</td>
                  <td className="p-2.5 font-bold text-emerald-700 dark:text-emerald-400">
                    {formatMoney(item.estimatedValue)}
                  </td>
                  <td className="p-2.5 font-bold">{item.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Batches Table */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-5 shadow-sm">
        <h4 className="font-bold text-sm text-stone-800 dark:text-stone-200 mb-3">📊 تفاصيل دفعات الاستلام الواردة</h4>
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs border-collapse">
            <thead>
              <tr className="bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 font-bold">
                <th className="p-2">التاريخ</th>
                <th className="p-2">المورد</th>
                <th className="p-2">النوع</th>
                <th className="p-2">الأشكال</th>
                <th className="p-2">الحبات</th>
                <th className="p-2">تكلفة الشراء</th>
                <th className="p-2">النقل</th>
                <th className="p-2">العمولة</th>
                <th className="p-2">إجمالي التكلفة</th>
                <th className="p-2">تكلفة الحبة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
              {db.receives.map((r) => {
                const pieces = Number(r.shapes || 0) * 2;
                const total = Number(r.cost || 0) + Number(r.transport || 0) + Number(r.commission || 0);
                const unit = pieces > 0 ? Math.round(total / pieces) : 0;
                return (
                  <tr key={r.id}>
                    <td className="p-2">{r.date}</td>
                    <td className="p-2 font-bold">{r.supplier}</td>
                    <td className="p-2">{r.type || '—'}</td>
                    <td className="p-2">{r.shapes}</td>
                    <td className="p-2 font-bold">{pieces}</td>
                    <td className="p-2">{formatMoney(r.cost)}</td>
                    <td className="p-2">{formatMoney(r.transport)}</td>
                    <td className="p-2">{formatMoney(r.commission)}</td>
                    <td className="p-2 font-bold text-emerald-800 dark:text-emerald-300">{formatMoney(total)}</td>
                    <td className="p-2 font-semibold text-amber-700 dark:text-amber-400">{formatMoney(unit)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
