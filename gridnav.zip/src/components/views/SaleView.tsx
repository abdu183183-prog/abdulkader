import React, { useState } from 'react';
import {
  ShoppingCart,
  Plus,
  Trash2,
  Save,
  Search,
  Printer,
  Download,
  AlertTriangle,
  Info,
  CheckCircle,
  MessageSquare,
  Phone,
} from 'lucide-react';
import { AppDatabase, SaleItem, PaymentBreakdown } from '../../types/accounting';
import { formatMoney, exportHtmlTableToExcel } from '../../utils/initialData';
import { formatQuantityText, getPaymentOf, calculateCustomerDebt } from '../../utils/accountingLogic';
import { buildCustomerSaleMessage, getWhatsAppUrl } from '../../utils/whatsapp';

interface SaleViewProps {
  db: AppDatabase;
  onUpdateDb: (updater: (prev: AppDatabase) => AppDatabase) => void;
  onOpenReceipt: (data: { title: string; items: { label: string; value: string | number }[]; notes?: string }) => void;
  onOpenWhatsApp?: (payload: { title: string; recipientName: string; defaultPhone?: string; messageText: string }) => void;
}

interface RowItem {
  id: string;
  qty: number | '';
  price: number | '';
  pay: 'cash' | 'transfer' | 'debt' | 'storage' | 'mixed';
  cashAmount: number | '';
  transferAmount: number | '';
  debtAmount: number | '';
  customer: string;
  customerPhone: string;
  note: string;
}

export const SaleView: React.FC<SaleViewProps> = ({ db, onUpdateDb, onOpenReceipt, onOpenWhatsApp }) => {
  const today = new Date().toISOString().slice(0, 10);
  const [saleDate, setSaleDate] = useState(today);
  const [selectedSupplier, setSelectedSupplier] = useState(db.suppliers[0] || '');
  const [search, setSearch] = useState('');
  const [lastSavedSale, setLastSavedSale] = useState<SaleItem | null>(null);

  // Row items builder
  const [rows, setRows] = useState<RowItem[]>([
    {
      id: '1',
      qty: 2,
      price: '',
      pay: 'cash',
      cashAmount: '',
      transferAmount: '',
      debtAmount: '',
      customer: '',
      customerPhone: '',
      note: '',
    },
  ]);

  // Supplier stock calculations
  const supplierReceivedPieces = db.receives
    .filter((r) => r.supplier === selectedSupplier)
    .reduce((sum, r) => sum + Number(r.shapes || 0) * 2, 0);

  const supplierSoldPieces = db.sales
    .filter((s) => s.supplier === selectedSupplier && s.pay !== 'storage')
    .reduce((sum, s) => sum + Number(s.qty || 0), 0);

  const supplierStoragePieces = db.sales
    .filter((s) => s.supplier === selectedSupplier && s.pay === 'storage')
    .reduce((sum, s) => sum + Number(s.qty || 0), 0);

  const supplierRemainingStock = supplierReceivedPieces - (supplierSoldPieces + supplierStoragePieces);

  // Average price for storage calculation
  const normalSales = db.sales.filter(
    (s) => s.supplier === selectedSupplier && s.pay !== 'storage' && Number(s.price || 0) > 0
  );
  const totalNormalQty = normalSales.reduce((a, s) => a + Number(s.qty || 0), 0);
  const totalNormalVal = normalSales.reduce((a, s) => a + Number(s.price || 0), 0);
  const avgPrice = totalNormalQty > 0 ? Math.round(totalNormalVal / totalNormalQty) : 0;

  const handleAddRow = () => {
    setRows((prev) => [
      ...prev,
      {
        id: String(Date.now() + Math.random()),
        qty: 1,
        price: '',
        pay: 'cash',
        cashAmount: '',
        transferAmount: '',
        debtAmount: '',
        customer: '',
        customerPhone: '',
        note: '',
      },
    ]);
  };

  const handleRemoveRow = (id: string) => {
    if (rows.length === 1) return;
    setRows((prev) => prev.filter((r) => r.id !== id));
  };

  const updateRow = (id: string, updates: Partial<RowItem>) => {
    setRows((prev) =>
      prev.map((r) => {
        if (r.id !== id) return r;
        const updated = { ...r, ...updates };

        // Auto-lookup customer phone if customer name changed
        if (updates.customer !== undefined) {
          const foundCust = db.customers.find((c) => c.name.trim() === updates.customer?.trim());
          if (foundCust && foundCust.phone && !updated.customerPhone) {
            updated.customerPhone = foundCust.phone;
          }
        }

        // If changed to storage, auto-compute estimated price
        if (updates.pay === 'storage') {
          const q = Number(updated.qty || 0);
          updated.price = avgPrice ? avgPrice * q : 0;
        }

        return updated;
      })
    );
  };

  const handleSaveAll = () => {
    if (!selectedSupplier) {
      alert('يرجى اختيار المورد أولاً');
      return;
    }

    let totalRequestedQty = 0;
    const newSales: SaleItem[] = [];

    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      const q = Number(r.qty || 0);
      const p = Number(r.price || 0);

      if (q <= 0) continue;
      totalRequestedQty += q;

      if (p <= 0 && r.pay !== 'storage') {
        alert(`يرجى إدخال مبلغ البند رقم #${i + 1}`);
        return;
      }

      let payments: PaymentBreakdown = { cash: 0, transfer: 0, debt: 0 };

      if (r.pay === 'cash') payments.cash = p;
      else if (r.pay === 'transfer') payments.transfer = p;
      else if (r.pay === 'debt') payments.debt = p;
      else if (r.pay === 'mixed') {
        const c = Number(r.cashAmount || 0);
        const t = Number(r.transferAmount || 0);
        const d = Number(r.debtAmount || 0);
        if (Math.abs(c + t + d - p) > 0.01) {
          alert(`البند #${i + 1}: مجموع النقد (${c}) + الحوالة (${t}) + الآجل (${d}) يجب أن يساوي إجمالي المبلغ ${p}`);
          return;
        }
        payments = { cash: c, transfer: t, debt: d };
      }

      // Check debt requirement
      if (payments.debt > 0 && !r.customer.trim()) {
        alert(`البند #${i + 1}: يجب إدخال اسم الزبون لتسجيل الدين والآجل`);
        return;
      }

      newSales.push({
        id: Date.now() + i,
        date: saleDate,
        supplier: selectedSupplier,
        qty: q,
        price: p,
        pay: r.pay,
        payments,
        storageValue: r.pay === 'storage' ? p : 0,
        customer: r.customer.trim(),
        customerPhone: r.customerPhone.trim() || undefined,
        note: r.note.trim(),
      });
    }

    if (newSales.length === 0) {
      alert('يرجى إدخال كميات صحيحة للبيع');
      return;
    }

    if (totalRequestedQty > supplierRemainingStock) {
      alert(
        `❌ الكمية الإجمالية المطلوبة (${totalRequestedQty} حبة) أكبر من المخزون المتبقي لدى المورد (${supplierRemainingStock} حبة)!`
      );
      return;
    }

    onUpdateDb((prev) => {
      // Also register or update customer phone
      const customerMap = new Map(prev.customers.map((c) => [c.name, { ...c }]));

      newSales.forEach((s) => {
        if (s.customer) {
          const existing = customerMap.get(s.customer);
          if (!existing) {
            customerMap.set(s.customer, {
              id: Date.now() + Math.floor(Math.random() * 1000),
              name: s.customer,
              phone: s.customerPhone || '',
            });
          } else if (s.customerPhone && !existing.phone) {
            existing.phone = s.customerPhone;
          }
        }
      });

      return {
        ...prev,
        customers: Array.from(customerMap.values()),
        sales: [...newSales, ...prev.sales],
      };
    });

    setLastSavedSale(newSales[0]);

    if (onOpenWhatsApp && newSales[0]) {
      const cust = newSales[0].customer || '';
      const allCustDebt = cust
        ? calculateCustomerDebt(cust, [...newSales, ...db.sales], db.debtPayments)
        : 0;
      onOpenWhatsApp({
        title: 'إرسال فاتورة مبيعات للعميل عبر واتساب',
        recipientName: cust || 'الزبون',
        defaultPhone:
          newSales[0].customerPhone || db.customers.find((c) => c.name === cust)?.phone || '',
        messageText: buildCustomerSaleMessage(newSales[0], {
          settings: db.settings,
          customerTotalDebt: allCustDebt,
        }),
      });
    }

    // Reset to single row
    setRows([
      {
        id: '1',
        qty: 1,
        price: '',
        pay: 'cash',
        cashAmount: '',
        transferAmount: '',
        debtAmount: '',
        customer: '',
        customerPhone: '',
        note: '',
      },
    ]);
  };

  const handleDeleteSale = (id: number) => {
    if (!confirm('هل أنت متأكد من حذف عملية البيع هذه؟')) return;
    onUpdateDb((prev) => ({
      ...prev,
      sales: prev.sales.filter((s) => s.id !== id),
    }));
  };

  const filteredSales = db.sales.filter(
    (s) =>
      !search ||
      s.supplier.toLowerCase().includes(search.toLowerCase()) ||
      (s.customer && s.customer.toLowerCase().includes(search.toLowerCase())) ||
      s.date.includes(search)
  );

  return (
    <div className="space-y-6">
      {/* Last Saved Sale WhatsApp Banner */}
      {lastSavedSale && (
        <div className="bg-emerald-50 dark:bg-emerald-950/60 border-2 border-emerald-500 rounded-2xl p-3.5 sm:p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-sm shrink-0">✓</div>
            <div>
              <div className="font-black text-sm text-emerald-950 dark:text-emerald-100">
                تم حفظ عملية البيع بنجاح {lastSavedSale.customer ? `للزبون (${lastSavedSale.customer})` : ''}!
              </div>
              <div className="text-xs text-emerald-700 dark:text-emerald-300">
                المبلغ: {formatMoney(lastSavedSale.price)} — الكمية: {lastSavedSale.qty} حبة
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => {
                if (onOpenWhatsApp) {
                  const custDebt = lastSavedSale.customer
                    ? calculateCustomerDebt(lastSavedSale.customer, db.sales, db.debtPayments)
                    : 0;
                  onOpenWhatsApp({
                    title: 'إرسال فاتورة المبيعات للعميل عبر واتساب',
                    recipientName: lastSavedSale.customer || 'الزبون',
                    defaultPhone: lastSavedSale.customerPhone || db.customers.find((c) => c.name === lastSavedSale.customer)?.phone || '',
                    messageText: buildCustomerSaleMessage(lastSavedSale, {
                      settings: db.settings,
                      customerTotalDebt: custDebt,
                    }),
                  });
                }
              }}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-stone-950 font-black text-xs sm:text-sm shadow cursor-pointer"
            >
              <MessageSquare className="w-4 h-4" />
              <span>📱 إرسال الفاتورة للعميل عبر واتساب</span>
            </button>
            <button
              type="button"
              onClick={() => setLastSavedSale(null)}
              className="p-2 text-stone-400 hover:text-stone-600 text-xs cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Top Supplier Picker & Live Stock Bar */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-5 shadow-sm">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
          <div>
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">تاريخ البيع</label>
            <input
              type="date"
              value={saleDate}
              onChange={(e) => setSaleDate(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-600 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
              اختر المورد المراد البيع من شحنته
            </label>
            <select
              value={selectedSupplier}
              onChange={(e) => setSelectedSupplier(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm font-bold text-emerald-900 dark:text-emerald-300 focus:ring-2 focus:ring-emerald-600 outline-none"
            >
              {db.suppliers.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Live Stock Indicators for selected supplier */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs text-center">
          <div className="p-2.5 rounded-xl bg-stone-100 dark:bg-stone-800">
            <span className="text-stone-500 dark:text-stone-400 block text-[11px]">المستلم</span>
            <b className="text-base text-stone-900 dark:text-stone-100">{supplierReceivedPieces} حبة</b>
          </div>

          <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/40">
            <span className="text-blue-700 dark:text-blue-300 block text-[11px]">المباع</span>
            <b className="text-base text-blue-900 dark:text-blue-200">{supplierSoldPieces} حبة</b>
          </div>

          <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/40">
            <span className="text-amber-700 dark:text-amber-300 block text-[11px]">التخزينة</span>
            <b className="text-base text-amber-900 dark:text-amber-200">{supplierStoragePieces} حبة</b>
          </div>

          <div
            className={`p-2.5 rounded-xl border ${
              supplierRemainingStock < 0
                ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 text-rose-800'
                : supplierRemainingStock === 0
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 text-emerald-800'
                : 'bg-emerald-100 dark:bg-emerald-950/60 border-emerald-400 text-emerald-950 dark:text-emerald-200'
            }`}
          >
            <span className="block text-[11px]">المخزون المتاح</span>
            <b className="text-base font-black">{supplierRemainingStock} حبة</b>
          </div>

          <div className="p-2.5 rounded-xl bg-stone-100 dark:bg-stone-800 col-span-2 sm:col-span-1">
            <span className="text-stone-500 dark:text-stone-400 block text-[11px]">متوسط سعر الحبة</span>
            <b className="text-sm text-stone-800 dark:text-stone-200">{formatMoney(avgPrice)}</b>
          </div>
        </div>
      </div>

      {/* Sale Rows Card */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-stone-200 dark:border-stone-700 pb-3">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-amber-500" />
            <h3 className="text-base sm:text-lg font-black text-stone-900 dark:text-stone-100">
              تسجيل بنود المبيعات والديون والتخزين
            </h3>
          </div>
          <span className="text-xs text-stone-500">{rows.length} بنود في القائمة</span>
        </div>

        {/* Rows loop */}
        <div className="space-y-4">
          {rows.map((row, index) => (
            <div
              key={row.id}
              className="p-3.5 sm:p-4 rounded-xl border border-amber-300 dark:border-amber-700/60 bg-amber-50/40 dark:bg-amber-950/20 space-y-3"
            >
              <div className="flex items-center justify-between text-xs font-bold text-amber-900 dark:text-amber-300 border-b border-amber-200 dark:border-amber-800 pb-2">
                <span>🛒 بند بيع #{index + 1}</span>
                {rows.length > 1 && (
                  <button
                    onClick={() => handleRemoveRow(row.id)}
                    className="text-rose-600 dark:text-rose-400 hover:text-rose-800 flex items-center gap-1 font-bold cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>حذف البند</span>
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                {/* الكمية بالحبات */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                    الكمية (بالحبات){' '}
                    <span className="text-amber-600 dark:text-amber-400 font-black">
                      ({formatQuantityText(Number(row.qty || 0))})
                    </span>
                  </label>
                  <input
                    type="number"
                    step="0.25"
                    min="0.25"
                    value={row.qty}
                    onChange={(e) => updateRow(row.id, { qty: e.target.value ? Number(e.target.value) : '' })}
                    placeholder="مثال: 2"
                    className="w-full px-3 py-2 bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm font-bold text-emerald-800 dark:text-emerald-300 focus:ring-2 focus:ring-emerald-600 outline-none"
                  />
                </div>

                {/* المبلغ الإجمالي */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                    المبلغ الإجمالي (ريال)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={row.price}
                    onChange={(e) => updateRow(row.id, { price: e.target.value ? Number(e.target.value) : '' })}
                    placeholder="المبلغ"
                    className="w-full px-3 py-2 bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-600 outline-none"
                  />
                </div>

                {/* طريقة الدفع */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">طريقة الدفع</label>
                  <select
                    value={row.pay}
                    onChange={(e) => updateRow(row.id, { pay: e.target.value as any })}
                    className="w-full px-3 py-2 bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm font-semibold focus:ring-2 focus:ring-emerald-600 outline-none"
                  >
                    <option value="cash">💵 نقد كامل</option>
                    <option value="transfer">🏦 حوالة كاملة</option>
                    <option value="debt">📕 آجل كامل (دين)</option>
                    <option value="mixed">💳 دفع متعدد (نقد + حوالة + دين)</option>
                    <option value="storage">📦 تخزينة</option>
                  </select>
                </div>

                {/* اسم الزبون / المشتري */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                    الزبون / المشتري {row.pay === 'debt' && <span className="text-rose-600">* (مطلوب)</span>}
                  </label>
                  <input
                    list="customersDatalist"
                    value={row.customer}
                    onChange={(e) => updateRow(row.id, { customer: e.target.value })}
                    placeholder="اسم الزبون"
                    className="w-full px-3 py-2 bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-600 outline-none"
                  />
                </div>

                {/* جوال الزبون للواتساب */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1 flex items-center gap-1">
                    <Phone className="w-3 h-3 text-emerald-600" />
                    <span>جوال الزبون (واتساب)</span>
                  </label>
                  <input
                    type="tel"
                    value={row.customerPhone}
                    onChange={(e) => updateRow(row.id, { customerPhone: e.target.value })}
                    placeholder="077... لإرسال الفاتورة"
                    dir="ltr"
                    className="w-full px-3 py-2 bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-600 outline-none text-right"
                  />
                </div>
              </div>

              {/* Mixed Payment Sub-inputs */}
              {row.pay === 'mixed' && (
                <div className="bg-white/80 dark:bg-stone-800/80 p-3 rounded-xl border border-stone-200 dark:border-stone-700">
                  <div className="text-xs font-bold text-stone-700 dark:text-stone-300 mb-2">
                    💳 توزيع الدفع المتعدد:
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-[11px] text-stone-500 mb-1">نقد</label>
                      <input
                        type="number"
                        min="0"
                        value={row.cashAmount}
                        onChange={(e) =>
                          updateRow(row.id, { cashAmount: e.target.value ? Number(e.target.value) : '' })
                        }
                        placeholder="0"
                        className="w-full px-2 py-1.5 bg-stone-50 dark:bg-stone-900 border rounded-lg text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-stone-500 mb-1">حوالة</label>
                      <input
                        type="number"
                        min="0"
                        value={row.transferAmount}
                        onChange={(e) =>
                          updateRow(row.id, { transferAmount: e.target.value ? Number(e.target.value) : '' })
                        }
                        placeholder="0"
                        className="w-full px-2 py-1.5 bg-stone-50 dark:bg-stone-900 border rounded-lg text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-stone-500 mb-1">آجل (دين)</label>
                      <input
                        type="number"
                        min="0"
                        value={row.debtAmount}
                        onChange={(e) =>
                          updateRow(row.id, { debtAmount: e.target.value ? Number(e.target.value) : '' })
                        }
                        placeholder="0"
                        className="w-full px-2 py-1.5 bg-stone-50 dark:bg-stone-900 border rounded-lg text-xs"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* ملاحظات البند */}
              <div>
                <input
                  type="text"
                  value={row.note}
                  onChange={(e) => updateRow(row.id, { note: e.target.value })}
                  placeholder="ملاحظات البند..."
                  className="w-full px-3 py-1.5 bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-xs focus:ring-2 focus:ring-emerald-600 outline-none"
                />
              </div>
            </div>
          ))}
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 pt-2">
          <button
            type="button"
            onClick={handleAddRow}
            className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-sm shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>➕ إضافة بند بيع آخر للقائمة</span>
          </button>

          <button
            type="button"
            onClick={handleSaveAll}
            className="flex-1 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Save className="w-4 h-4 text-amber-300" />
            <span>💾 حفظ كافة المبيعات والديون والتخزين</span>
          </button>
        </div>
      </div>

      {/* Sales History Table */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              placeholder="🔍 بحث بالمورد أو الزبون..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-3 pr-9 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs sm:text-sm text-stone-800 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <button
            onClick={() => exportHtmlTableToExcel('s_table_el', 'سجل_المبيعات_والديون')}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 text-xs font-bold shadow-sm transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تصدير Excel</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table id="s_table_el" className="w-full text-right text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-stone-100 dark:bg-stone-800 text-emerald-900 dark:text-emerald-300 font-bold border-b border-stone-200 dark:border-stone-700">
                <th className="p-2.5">التاريخ</th>
                <th className="p-2.5">المورد</th>
                <th className="p-2.5">الكمية</th>
                <th className="p-2.5">المبلغ</th>
                <th className="p-2.5">طريقة الدفع</th>
                <th className="p-2.5">الزبون / ملاحظات</th>
                <th className="p-2.5 no-print text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
              {filteredSales.map((s) => {
                const p = getPaymentOf(s);
                return (
                  <tr key={s.id} className="hover:bg-stone-50 dark:hover:bg-stone-800/50 transition-colors">
                    <td className="p-2.5 font-medium">{s.date}</td>
                    <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{s.supplier}</td>
                    <td className="p-2.5 font-bold text-amber-700 dark:text-amber-400">
                      {formatQuantityText(s.qty)} ({s.qty} حبة)
                    </td>
                    <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{formatMoney(s.price)}</td>
                    <td className="p-2.5">
                      {s.pay === 'cash' && (
                        <span className="px-2 py-0.5 rounded-full text-xs bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold">
                          نقد
                        </span>
                      )}
                      {s.pay === 'transfer' && (
                        <span className="px-2 py-0.5 rounded-full text-xs bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300 font-bold">
                          حوالة
                        </span>
                      )}
                      {s.pay === 'debt' && (
                        <span className="px-2 py-0.5 rounded-full text-xs bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 font-bold">
                          دين / آجل
                        </span>
                      )}
                      {s.pay === 'storage' && (
                        <span className="px-2 py-0.5 rounded-full text-xs bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-bold">
                          تخزينة
                        </span>
                      )}
                      {s.pay === 'mixed' && (
                        <span className="px-2 py-0.5 rounded-full text-xs bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 font-bold">
                          مختلط (نقد {formatMoney(p.cash)} + حوالة {formatMoney(p.transfer)} + دين {formatMoney(p.debt)})
                        </span>
                      )}
                    </td>
                    <td className="p-2.5 text-stone-700 dark:text-stone-300">
                      <b>{s.customer || '—'}</b> {s.note && <span className="text-stone-500 text-xs">({s.note})</span>}
                    </td>
                    <td className="p-2.5 no-print">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() =>
                            onOpenReceipt({
                              title: 'فاتورة بيع قات',
                              items: [
                                { label: 'المورد', value: s.supplier },
                                { label: 'التاريخ', value: s.date },
                                { label: 'الكمية', value: `${formatQuantityText(s.qty)} (${s.qty} حبة)` },
                                { label: 'المبلغ الإجمالي', value: formatMoney(s.price) },
                                {
                                  label: 'طريقة الدفع',
                                  value:
                                    s.pay === 'cash'
                                      ? 'نقد'
                                      : s.pay === 'transfer'
                                      ? 'حوالة'
                                      : s.pay === 'debt'
                                      ? 'آجل (دين)'
                                      : s.pay === 'storage'
                                      ? 'تخزينة'
                                      : `مختلط (نقد ${p.cash} + حوالة ${p.transfer} + دين ${p.debt})`,
                                },
                                { label: 'الزبون', value: s.customer || 'نقدي' },
                              ],
                              notes: s.note,
                            })
                          }
                          className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 text-emerald-700 dark:text-emerald-300 cursor-pointer"
                          title="طباعة إيصال الفاتورة"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => {
                            if (onOpenWhatsApp) {
                              const custDebt = s.customer
                                ? calculateCustomerDebt(s.customer, db.sales, db.debtPayments)
                                : 0;
                              onOpenWhatsApp({
                                title: 'إرسال فاتورة مبيعات للعميل عبر واتساب',
                                recipientName: s.customer || 'الزبون',
                                defaultPhone: s.customerPhone || db.customers.find((c) => c.name === s.customer)?.phone || '',
                                messageText: buildCustomerSaleMessage(s, {
                                  settings: db.settings,
                                  customerTotalDebt: custDebt,
                                }),
                              });
                            } else {
                              const phone = s.customerPhone || db.customers.find((c) => c.name === s.customer)?.phone || '';
                              window.open(getWhatsAppUrl(phone, buildCustomerSaleMessage(s, { settings: db.settings })), '_blank');
                            }
                          }}
                          className="p-1.5 rounded-lg bg-green-50 dark:bg-green-950/60 hover:bg-green-100 text-green-700 dark:text-green-300 cursor-pointer"
                          title="إرسال الفاتورة للعميل عبر واتساب"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => handleDeleteSale(s.id)}
                          className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 text-rose-700 dark:text-rose-300"
                          title="حذف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <datalist id="customersDatalist">
        {db.customers.map((c) => (
          <option key={c.id} value={c.name} />
        ))}
      </datalist>
    </div>
  );
};
