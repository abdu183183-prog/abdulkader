import React, { useState } from 'react';
import {
  Users,
  Truck,
  FileSpreadsheet,
  FileText,
  BadgeDollarSign,
  CreditCard,
  Hourglass,
  Printer,
  Trash2,
  Edit3,
  Download,
  MessageSquare,
} from 'lucide-react';
import { AppDatabase, Customer, SupplierDetail } from '../../types/accounting';
import { formatMoney, exportHtmlTableToExcel } from '../../utils/initialData';
import { calculateCustomerDebt, calculateDebtAging, getPaymentOf, formatQuantityText } from '../../utils/accountingLogic';
import { getWhatsAppUrl } from '../../utils/whatsapp';

interface ContactsAndLedgersViewProps {
  db: AppDatabase;
  activeSubView:
    | 'supplier'
    | 'customers'
    | 'supplierStatement'
    | 'customerStatement'
    | 'supplierPayments'
    | 'customerPayments'
    | 'customerDebtAging'
    | 'contacts45';
  onUpdateDb: (updater: (prev: AppDatabase) => AppDatabase) => void;
  onOpenWhatsApp?: (payload: { title: string; recipientName: string; defaultPhone?: string; messageText: string }) => void;
}

export const ContactsAndLedgersView: React.FC<ContactsAndLedgersViewProps> = ({
  db,
  activeSubView,
  onUpdateDb,
  onOpenWhatsApp,
}) => {
  const today = new Date().toISOString().slice(0, 10);

  // Customer form state
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [custAddress, setCustAddress] = useState('');
  const [custNote, setCustNote] = useState('');
  const [editingCustId, setEditingCustId] = useState<number | null>(null);

  // Supplier form state
  const [supName, setSupName] = useState('');
  const [supPhone, setSupPhone] = useState('');
  const [supAddress, setSupAddress] = useState('');
  const [supNote, setSupNote] = useState('');
  const [editingSupId, setEditingSupId] = useState<number | null>(null);

  // Supplier payment form
  const [spSupplier, setSpSupplier] = useState(db.suppliers[0] || '');
  const [spDate, setSpDate] = useState(today);
  const [spAmount, setSpAmount] = useState<number | ''>('');
  const [spMethod, setSpMethod] = useState<'cash' | 'transfer'>('cash');
  const [spNote, setSpNote] = useState('');

  // Individual ledger selections
  const [ledgerCust, setLedgerCust] = useState(db.customers[0]?.name || '');
  const [ledgerSup, setLedgerSup] = useState(db.suppliers[0] || '');

  // Calculate supplier financial status
  const getSupplierFinances = (name: string) => {
    const receivedCost = db.receives
      .filter((r) => r.supplier === name)
      .reduce((sum, r) => sum + Number(r.cost || 0) + Number(r.transport || 0) + Number(r.commission || 0), 0);
    const paid = db.supplierPayments
      .filter((p) => p.supplier === name)
      .reduce((sum, p) => sum + Number(p.amount || 0), 0);
    const due = Math.max(0, receivedCost - paid);
    return { receivedCost, paid, due };
  };

  // Save Customer
  const handleSaveCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    const name = custName.trim();
    if (!name) return alert('يرجى كتابة اسم العميل');

    if (editingCustId) {
      onUpdateDb((prev) => ({
        ...prev,
        customers: prev.customers.map((c) =>
          c.id === editingCustId
            ? { ...c, name, phone: custPhone.trim(), address: custAddress.trim(), note: custNote.trim() }
            : c
        ),
      }));
      setEditingCustId(null);
      alert('تم تحديث بيانات العميل');
    } else {
      onUpdateDb((prev) => ({
        ...prev,
        customers: [
          ...prev.customers,
          { id: Date.now(), name, phone: custPhone.trim(), address: custAddress.trim(), note: custNote.trim() },
        ],
      }));
      alert('تمت إضافة العميل بنجاح');
    }

    setCustName('');
    setCustPhone('');
    setCustAddress('');
    setCustNote('');
  };

  // Save Supplier
  const handleSaveSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    const name = supName.trim();
    if (!name) return alert('يرجى كتابة اسم المورد');

    if (editingSupId) {
      onUpdateDb((prev) => ({
        ...prev,
        suppliers: prev.suppliers.map((s) => (s === supName ? name : s)),
        supplierDetails: prev.supplierDetails.map((s) =>
          s.id === editingSupId
            ? { ...s, name, phone: supPhone.trim(), address: supAddress.trim(), note: supNote.trim() }
            : s
        ),
      }));
      setEditingSupId(null);
      alert('تم تحديث بيانات المورد');
    } else {
      onUpdateDb((prev) => ({
        ...prev,
        suppliers: prev.suppliers.includes(name) ? prev.suppliers : [...prev.suppliers, name],
        supplierDetails: [
          ...prev.supplierDetails,
          { id: Date.now(), name, phone: supPhone.trim(), address: supAddress.trim(), note: supNote.trim() },
        ],
      }));
      alert('تمت إضافة المورد بنجاح');
    }

    setSupName('');
    setSupPhone('');
    setSupAddress('');
    setSupNote('');
  };

  // Save Supplier Payment
  const handleSaveSupplierPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!spSupplier) return alert('اختر المورد أولاً');
    const amt = Number(spAmount);
    if (!amt || amt <= 0) return alert('أدخل مبلغ صحيح');

    const fin = getSupplierFinances(spSupplier);
    if (amt > fin.due) {
      if (!confirm(`المبلغ المدخل (${formatMoney(amt)}) أكبر من المستحق المسجل (${formatMoney(fin.due)}). هل تود المتابعة؟`)) {
        return;
      }
    }

    onUpdateDb((prev) => ({
      ...prev,
      supplierPayments: [
        {
          id: Date.now(),
          date: spDate,
          supplier: spSupplier,
          amount: amt,
          method: spMethod,
          note: spNote.trim(),
        },
        ...prev.supplierPayments,
      ],
    }));

    setSpAmount('');
    setSpNote('');
    alert(`✅ تم تسجيل تسديد المورد (${spSupplier}) بمبلغ ${formatMoney(amt)}`);
  };

  return (
    <div className="space-y-6">
      {/* 1. إدارة العملاء */}
      {(activeSubView === 'customers' || activeSubView === 'contacts45') && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-base sm:text-lg font-black text-blue-950 dark:text-blue-300 mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            <span>👥 إدارة العملاء والزبائن</span>
          </h3>

          <form onSubmit={handleSaveCustomer} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
            <div>
              <label className="block text-xs font-bold mb-1">اسم العميل</label>
              <input
                type="text"
                value={custName}
                onChange={(e) => setCustName(e.target.value)}
                placeholder="اسم العميل"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">رقم الجوال</label>
              <input
                type="tel"
                value={custPhone}
                onChange={(e) => setCustPhone(e.target.value)}
                placeholder="077..."
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">العنوان / المنطقة</label>
              <input
                type="text"
                value={custAddress}
                onChange={(e) => setCustAddress(e.target.value)}
                placeholder="المنصورة، الشيخ عثمان..."
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">ملاحظات</label>
              <input
                type="text"
                value={custNote}
                onChange={(e) => setCustNote(e.target.value)}
                placeholder="أي ملاحظات..."
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <div className="sm:col-span-2 lg:col-span-4 flex gap-2">
              <button
                type="submit"
                className="py-2.5 px-6 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-sm shadow cursor-pointer"
              >
                {editingCustId ? '💾 حفظ تعديل العميل' : '➕ إضافة عميل جديد'}
              </button>
              {editingCustId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingCustId(null);
                    setCustName('');
                    setCustPhone('');
                  }}
                  className="py-2.5 px-4 rounded-xl bg-stone-200 text-stone-700 text-sm font-bold cursor-pointer"
                >
                  إلغاء
                </button>
              )}
            </div>
          </form>

          {/* Customers Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs sm:text-sm border-collapse">
              <thead>
                <tr className="bg-stone-100 dark:bg-stone-800 font-bold border-b">
                  <th className="p-2.5">العميل</th>
                  <th className="p-2.5">الجوال</th>
                  <th className="p-2.5">العنوان</th>
                  <th className="p-2.5">الدين الحالي</th>
                  <th className="p-2.5 text-center">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                {db.customers.map((c) => {
                  const debt = calculateCustomerDebt(c.name, db.sales, db.debtPayments);
                  return (
                    <tr key={c.id}>
                      <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{c.name}</td>
                      <td className="p-2.5" dir="ltr">{c.phone || '—'}</td>
                      <td className="p-2.5">{c.address || '—'}</td>
                      <td className="p-2.5 font-bold text-rose-700 dark:text-rose-400">{formatMoney(debt)}</td>
                      <td className="p-2.5 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => {
                              const text = [
                                `🌿 *${db.settings.shopName || 'محلات عبدالقادر الشعيبي للقات'}* 🌿`,
                                `📄 *إشعار كشف حساب عميل*`,
                                `────────────────────`,
                                `👤 *العميل:* ${c.name}`,
                                `📅 *التاريخ:* ${today}`,
                                `📊 *إجمالي الرصيد المتبقي:* ${formatMoney(debt)}`,
                                `────────────────────`,
                                db.settings.address ? `📍 *الموقع:* ${db.settings.address}` : '',
                                db.settings.phone ? `📞 *الهاتف:* ${db.settings.phone}` : '',
                              ]
                                .filter(Boolean)
                                .join('\n');

                              if (onOpenWhatsApp) {
                                onOpenWhatsApp({
                                  title: 'إرسال كشف حساب العميل عبر واتساب',
                                  recipientName: c.name,
                                  defaultPhone: c.phone || '',
                                  messageText: text,
                                });
                              } else {
                                window.open(getWhatsAppUrl(c.phone, text), '_blank');
                              }
                            }}
                            className="p-1.5 rounded-lg bg-green-50 text-green-700 hover:bg-green-100 cursor-pointer"
                            title="إرسال عبر واتساب"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => {
                              setEditingCustId(c.id);
                              setCustName(c.name);
                              setCustPhone(c.phone || '');
                              setCustAddress(c.address || '');
                              setCustNote(c.note || '');
                            }}
                            className="p-1.5 rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 cursor-pointer"
                            title="تعديل"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (!confirm(`هل أنت متأكد من حذف العميل (${c.name})؟`)) return;
                              onUpdateDb((prev) => ({
                                ...prev,
                                customers: prev.customers.filter((x) => x.id !== c.id),
                              }));
                            }}
                            className="p-1.5 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 cursor-pointer"
                            title="حذف"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. إدارة الموردين */}
      {(activeSubView === 'supplier' || activeSubView === 'contacts45') && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-emerald-300 mb-4 flex items-center gap-2">
            <Truck className="w-5 h-5 text-emerald-600" />
            <span>🚚 إدارة الموردين والجهات</span>
          </h3>

          <form onSubmit={handleSaveSupplier} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
            <div>
              <label className="block text-xs font-bold mb-1">اسم المورد</label>
              <input
                type="text"
                value={supName}
                onChange={(e) => setSupName(e.target.value)}
                placeholder="اسم المورد"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">رقم الهاتف</label>
              <input
                type="tel"
                value={supPhone}
                onChange={(e) => setSupPhone(e.target.value)}
                placeholder="077..."
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">العنوان / المنطقة</label>
              <input
                type="text"
                value={supAddress}
                onChange={(e) => setSupAddress(e.target.value)}
                placeholder="الضالع، الشعيب، صعدة..."
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">ملاحظات</label>
              <input
                type="text"
                value={supNote}
                onChange={(e) => setSupNote(e.target.value)}
                placeholder="ملاحظات المورد..."
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <div className="sm:col-span-2 lg:col-span-4 flex gap-2">
              <button
                type="submit"
                className="py-2.5 px-6 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow cursor-pointer"
              >
                {editingSupId ? '💾 حفظ تعديل المورد' : '➕ إضافة مورد جديد'}
              </button>
            </div>
          </form>

          {/* Suppliers Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs sm:text-sm border-collapse">
              <thead>
                <tr className="bg-stone-100 dark:bg-stone-800 font-bold border-b">
                  <th className="p-2.5">المورد</th>
                  <th className="p-2.5">الهاتف</th>
                  <th className="p-2.5">العنوان</th>
                  <th className="p-2.5">إجمالي الشحنات المستلمة</th>
                  <th className="p-2.5">المستحق الحالي للمورد</th>
                  <th className="p-2.5 text-center">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                {db.suppliers.map((s) => {
                  const details = db.supplierDetails.find((d) => d.name === s);
                  const fin = getSupplierFinances(s);
                  const recCount = db.receives.filter((r) => r.supplier === s).length;

                  return (
                    <tr key={s}>
                      <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{s}</td>
                      <td className="p-2.5" dir="ltr">{details?.phone || '—'}</td>
                      <td className="p-2.5">{details?.address || '—'}</td>
                      <td className="p-2.5 font-semibold text-emerald-800">{recCount} شحنة</td>
                      <td className="p-2.5 font-bold text-amber-700 dark:text-amber-400">{formatMoney(fin.due)}</td>
                      <td className="p-2.5 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => {
                              const text = [
                                `🌿 *${db.settings.shopName || 'محلات عبدالقادر الشعيبي للقات'}* 🌿`,
                                `🚚 *إشعار كشف حساب مورد*`,
                                `────────────────────`,
                                `👤 *المورد:* ${s}`,
                                `📅 *التاريخ:* ${today}`,
                                `💰 *المستحق الحالي المسجل للمورد:* ${formatMoney(fin.due)}`,
                                `────────────────────`,
                                db.settings.address ? `📍 *الموقع:* ${db.settings.address}` : '',
                                db.settings.phone ? `📞 *الهاتف:* ${db.settings.phone}` : '',
                              ]
                                .filter(Boolean)
                                .join('\n');

                              if (onOpenWhatsApp) {
                                onOpenWhatsApp({
                                  title: 'إرسال كشف حساب المورد عبر واتساب',
                                  recipientName: s,
                                  defaultPhone: details?.phone || '',
                                  messageText: text,
                                });
                              } else {
                                window.open(getWhatsAppUrl(details?.phone, text), '_blank');
                              }
                            }}
                            className="p-1.5 rounded-lg bg-green-50 text-green-700 hover:bg-green-100 cursor-pointer"
                            title="مراسلة المورد عبر واتساب"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => {
                              if (!confirm(`هل أنت متأكد من حذف المورد (${s})؟`)) return;
                              onUpdateDb((prev) => ({
                                ...prev,
                                suppliers: prev.suppliers.filter((x) => x !== s),
                                supplierDetails: prev.supplierDetails.filter((x) => x.name !== s),
                              }));
                            }}
                            className="p-1.5 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 cursor-pointer"
                            title="حذف"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. تسديدات الموردين */}
      {activeSubView === 'supplierPayments' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-emerald-300 mb-4 flex items-center gap-2">
            <BadgeDollarSign className="w-5 h-5 text-emerald-600" />
            <span>💸 تسديدات الموردين</span>
          </h3>

          <form onSubmit={handleSaveSupplierPayment} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
            <div>
              <label className="block text-xs font-bold mb-1">المورد</label>
              <select
                value={spSupplier}
                onChange={(e) => setSpSupplier(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-emerald-600"
              >
                {db.suppliers.map((s) => (
                  <option key={s} value={s}>
                    {s} (المستحق: {formatMoney(getSupplierFinances(s).due)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold mb-1">تاريخ السداد</label>
              <input
                type="date"
                value={spDate}
                onChange={(e) => setSpDate(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold mb-1">المبلغ (ريال)</label>
              <input
                type="number"
                min="1"
                value={spAmount}
                onChange={(e) => setSpAmount(e.target.value ? Number(e.target.value) : '')}
                placeholder="المبلغ"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm font-bold text-emerald-800 outline-none focus:ring-2 focus:ring-emerald-600"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold mb-1">طريقة السداد</label>
              <select
                value={spMethod}
                onChange={(e) => setSpMethod(e.target.value as any)}
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-emerald-600"
              >
                <option value="cash">💵 نقد من الصندوق</option>
                <option value="transfer">🏦 حوالة بنكية</option>
              </select>
            </div>

            <div className="sm:col-span-2 lg:col-span-3">
              <input
                type="text"
                value={spNote}
                onChange={(e) => setSpNote(e.target.value)}
                placeholder="البيان ورقم الحوالة أو السند..."
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <button
              type="submit"
              className="py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow cursor-pointer"
            >
              ➕ تسجيل تسديد المورد
            </button>
          </form>

          {/* Supplier Payments History */}
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs sm:text-sm border-collapse">
              <thead>
                <tr className="bg-stone-100 dark:bg-stone-800 font-bold border-b">
                  <th className="p-2.5">التاريخ</th>
                  <th className="p-2.5">المورد</th>
                  <th className="p-2.5">المبلغ</th>
                  <th className="p-2.5">الطريقة</th>
                  <th className="p-2.5">البيان</th>
                  <th className="p-2.5 text-center">إجراء</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                {db.supplierPayments.map((p) => (
                  <tr key={p.id}>
                    <td className="p-2.5 font-medium">{p.date}</td>
                    <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{p.supplier}</td>
                    <td className="p-2.5 font-black text-emerald-800 dark:text-emerald-300">{formatMoney(p.amount)}</td>
                    <td className="p-2.5 font-semibold">{p.method === 'cash' ? 'نقد' : 'حوالة'}</td>
                    <td className="p-2.5 text-stone-500">{p.note || '—'}</td>
                    <td className="p-2.5 text-center">
                      <button
                        onClick={() => {
                          if (!confirm('حذف هذا السداد؟')) return;
                          onUpdateDb((prev) => ({
                            ...prev,
                            supplierPayments: prev.supplierPayments.filter((x) => x.id !== p.id),
                          }));
                        }}
                        className="p-1 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. أعمار ديون العملاء */}
      {activeSubView === 'customerDebtAging' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base sm:text-lg font-black text-rose-950 dark:text-rose-300 flex items-center gap-2">
              <Hourglass className="w-5 h-5 text-rose-600" />
              <span>⏳ أعمار ديون العملاء (FIFO)</span>
            </h3>
            <span className="text-xs text-stone-500 font-semibold">توزيع زمني: 30 - 60 - 90 يومًا فأكثر</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs sm:text-sm border-collapse">
              <thead>
                <tr className="bg-stone-100 dark:bg-stone-800 font-bold border-b">
                  <th className="p-2.5">العميل</th>
                  <th className="p-2.5 text-emerald-700">0 - 30 يوم</th>
                  <th className="p-2.5 text-blue-700">31 - 60 يوم</th>
                  <th className="p-2.5 text-amber-700">61 - 90 يوم</th>
                  <th className="p-2.5 text-rose-700 font-black">+90 يوم</th>
                  <th className="p-2.5 font-black">إجمالي الدين</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                {db.customers.map((c) => {
                  const bins = calculateDebtAging(c.name, db.sales, db.debtPayments, today);
                  const total = bins.reduce((a, b) => a + b, 0);
                  if (total === 0) return null;

                  return (
                    <tr key={c.id}>
                      <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{c.name}</td>
                      <td className="p-2.5 text-emerald-800">{formatMoney(bins[0])}</td>
                      <td className="p-2.5 text-blue-800">{formatMoney(bins[1])}</td>
                      <td className="p-2.5 text-amber-800">{formatMoney(bins[2])}</td>
                      <td className="p-2.5 font-bold text-rose-800">{formatMoney(bins[3])}</td>
                      <td className="p-2.5 font-black text-stone-900 dark:text-stone-100">{formatMoney(total)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. كشف حساب العميل والمورد التفاعلي */}
      {activeSubView === 'contacts45' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* كشف حساب العميل */}
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-5 shadow-sm">
            <h4 className="font-bold text-sm text-blue-900 dark:text-blue-300 mb-3 flex items-center justify-between">
              <span>📕 كشف حساب عميل مفصل</span>
              <button onClick={() => window.print()} className="text-xs text-blue-600 flex items-center gap-1">
                <Printer className="w-3.5 h-3.5" />
                <span>طباعة</span>
              </button>
            </h4>

            <div className="mb-3">
              <select
                value={ledgerCust}
                onChange={(e) => setLedgerCust(e.target.value)}
                className="w-full px-3 py-1.5 bg-stone-50 dark:bg-stone-800 border rounded-xl text-xs font-bold"
              >
                {db.customers.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="overflow-x-auto max-h-72">
              <table className="w-full text-right text-xs border-collapse">
                <thead>
                  <tr className="bg-stone-100 dark:bg-stone-800 text-stone-700">
                    <th className="p-2">التاريخ</th>
                    <th className="p-2">العملية</th>
                    <th className="p-2">دين</th>
                    <th className="p-2">سداد</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                  {db.sales
                    .filter((s) => (s.customer || '').trim() === ledgerCust && getPaymentOf(s).debt > 0)
                    .map((s) => (
                      <tr key={`s-${s.id}`}>
                        <td className="p-2">{s.date}</td>
                        <td className="p-2">بيع ({formatQuantityText(s.qty)})</td>
                        <td className="p-2 text-rose-700 font-bold">{formatMoney(getPaymentOf(s).debt)}</td>
                        <td className="p-2">—</td>
                      </tr>
                    ))}
                  {db.debtPayments
                    .filter((p) => (p.customer || '').trim() === ledgerCust)
                    .map((p) => (
                      <tr key={`p-${p.id}`} className="bg-emerald-50/50">
                        <td className="p-2">{p.date}</td>
                        <td className="p-2">سداد ({p.method === 'cash' ? 'نقد' : 'حوالة'})</td>
                        <td className="p-2">—</td>
                        <td className="p-2 text-emerald-700 font-bold">{formatMoney(p.amount)}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>

            <div className="mt-3 p-2 bg-stone-100 dark:bg-stone-800 rounded-xl text-xs flex justify-between font-bold">
              <span>الدين المتبقي:</span>
              <span className="text-rose-700">
                {formatMoney(calculateCustomerDebt(ledgerCust, db.sales, db.debtPayments))}
              </span>
            </div>
          </div>

          {/* كشف حساب المورد */}
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-5 shadow-sm">
            <h4 className="font-bold text-sm text-emerald-900 dark:text-emerald-300 mb-3 flex items-center justify-between">
              <span>🏪 كشف حساب مورد مفصل</span>
              <button onClick={() => window.print()} className="text-xs text-emerald-600 flex items-center gap-1">
                <Printer className="w-3.5 h-3.5" />
                <span>طباعة</span>
              </button>
            </h4>

            <div className="mb-3">
              <select
                value={ledgerSup}
                onChange={(e) => setLedgerSup(e.target.value)}
                className="w-full px-3 py-1.5 bg-stone-50 dark:bg-stone-800 border rounded-xl text-xs font-bold"
              >
                {db.suppliers.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div className="overflow-x-auto max-h-72">
              <table className="w-full text-right text-xs border-collapse">
                <thead>
                  <tr className="bg-stone-100 dark:bg-stone-800 text-stone-700">
                    <th className="p-2">التاريخ</th>
                    <th className="p-2">العملية</th>
                    <th className="p-2">تكلفة / مستحق</th>
                    <th className="p-2">المسدد له</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                  {db.receives
                    .filter((r) => r.supplier === ledgerSup)
                    .map((r) => {
                      const cost = Number(r.cost || 0) + Number(r.transport || 0) + Number(r.commission || 0);
                      return (
                        <tr key={`r-${r.id}`}>
                          <td className="p-2">{r.date}</td>
                          <td className="p-2">استلام ({r.shapes} شكل)</td>
                          <td className="p-2 text-stone-900 font-bold">{formatMoney(cost)}</td>
                          <td className="p-2">—</td>
                        </tr>
                      );
                    })}
                  {db.supplierPayments
                    .filter((p) => p.supplier === ledgerSup)
                    .map((p) => (
                      <tr key={`sp-${p.id}`} className="bg-emerald-50/50">
                        <td className="p-2">{p.date}</td>
                        <td className="p-2">دفعة مسددة ({p.method === 'cash' ? 'نقد' : 'حوالة'})</td>
                        <td className="p-2">—</td>
                        <td className="p-2 text-emerald-700 font-bold">{formatMoney(p.amount)}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>

            <div className="mt-3 p-2 bg-stone-100 dark:bg-stone-800 rounded-xl text-xs flex justify-between font-bold">
              <span>المتبقي للمورد:</span>
              <span className="text-amber-700">{formatMoney(getSupplierFinances(ledgerSup).due)}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
