import React, { useState } from 'react';
import {
  Wallet,
  CreditCard,
  Landmark,
  Printer,
  Plus,
  Trash2,
  Download,
  AlertCircle,
  Repeat,
} from 'lucide-react';
import { AppDatabase, DebtPayment, CashTransaction } from '../../types/accounting';
import { formatMoney, exportHtmlTableToExcel } from '../../utils/initialData';
import { calculateCustomerDebt, calculateCashBalances, formatQuantityText } from '../../utils/accountingLogic';

interface AccountsViewProps {
  db: AppDatabase;
  onUpdateDb: (updater: (prev: AppDatabase) => AppDatabase) => void;
}

export const AccountsView: React.FC<AccountsViewProps> = ({ db, onUpdateDb }) => {
  const today = new Date().toISOString().slice(0, 10);

  // Debt payment state
  const [dpCustomer, setDpCustomer] = useState('');
  const [dpDate, setDpDate] = useState(today);
  const [dpAmount, setDpAmount] = useState<number | ''>('');
  const [dpMethod, setDpMethod] = useState<'cash' | 'transfer'>('cash');
  const [dpNote, setDpNote] = useState('');

  // Cash movement state
  const [cmDate, setCmDate] = useState(today);
  const [cmType, setCmType] = useState<'opening' | 'deposit' | 'withdrawal' | 'transfer_to_cash'>('deposit');
  const [cmAmount, setCmAmount] = useState<number | ''>('');
  const [cmMethod, setCmMethod] = useState<'cash' | 'transfer'>('cash');
  const [cmNote, setCmNote] = useState('');

  // Ledger filters
  const [ledgerCustomer, setLedgerCustomer] = useState(db.customers[0]?.name || '');
  const [ledgerSupplier, setLedgerSupplier] = useState(db.suppliers[0] || '');

  const balances = calculateCashBalances(
    db.sales,
    db.expenses,
    db.debtPayments,
    db.supplierPayments,
    db.cashTransactions
  );

  const customerNames = Array.from(
    new Set([
      ...db.customers.map((c) => c.name),
      ...db.sales.map((s) => s.customer || ''),
      ...db.debtPayments.map((p) => p.customer),
    ].filter(Boolean))
  );

  const totalAllDebt = customerNames.reduce(
    (sum, c) => sum + calculateCustomerDebt(c, db.sales, db.debtPayments),
    0
  );

  // Submit debt payment
  const handleAddDebtPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const cust = dpCustomer.trim();
    const amt = Number(dpAmount);

    if (!cust) return alert('يرجى إدخال اسم الزبون');
    if (!amt || amt <= 0) return alert('يرجى إدخال مبلغ صحيح');

    const remainingDebt = calculateCustomerDebt(cust, db.sales, db.debtPayments);
    if (remainingDebt <= 0) {
      alert(`لا يوجد دين مسجل على الزبون (${cust})`);
      return;
    }
    if (amt > remainingDebt) {
      alert(`❌ مبلغ السداد (${formatMoney(amt)}) أكبر من الدين المتبقي (${formatMoney(remainingDebt)})!`);
      return;
    }

    const newPayment: DebtPayment = {
      id: Date.now(),
      date: dpDate,
      customer: cust,
      amount: amt,
      method: dpMethod,
      note: dpNote.trim(),
    };

    onUpdateDb((prev) => ({
      ...prev,
      debtPayments: [newPayment, ...prev.debtPayments],
    }));

    setDpAmount('');
    setDpNote('');
    alert(`✅ تم تسجيل سداد دين الزبون (${cust}) بمبلغ ${formatMoney(amt)}`);
  };

  // Submit cashbox movement
  const handleAddCashMovement = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(cmAmount);
    if (!amt || amt <= 0) return alert('يرجى إدخال مبلغ صحيح');

    if (cmType === 'transfer_to_cash') {
      if (amt > balances.transfer) {
        alert(`❌ لا يمكن سحب هذا المبلغ من الحوالات. الرصيد المتاح: ${formatMoney(balances.transfer)}`);
        return;
      }
    }

    const newTx: CashTransaction = {
      id: Date.now(),
      date: cmDate,
      type: cmType,
      amount: amt,
      method: cmType === 'transfer_to_cash' ? 'transfer' : cmMethod,
      note: cmNote.trim() || (cmType === 'transfer_to_cash' ? 'سحب من الحوالات إلى الصندوق النقدي' : ''),
    };

    onUpdateDb((prev) => ({
      ...prev,
      cashTransactions: [newTx, ...prev.cashTransactions],
    }));

    setCmAmount('');
    setCmNote('');
    alert('✅ تم تسجيل الحركة المالية بنجاح');
  };

  return (
    <div className="space-y-6">
      {/* Overview Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-4 rounded-2xl shadow-sm">
          <span className="text-xs text-rose-600 block mb-1 font-bold">إجمالي ديون الزبائن</span>
          <b className="text-lg sm:text-2xl text-rose-700 dark:text-rose-400">{formatMoney(totalAllDebt)}</b>
        </div>
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-4 rounded-2xl shadow-sm">
          <span className="text-xs text-emerald-600 block mb-1 font-bold">النقد الفعلي بالصندوق</span>
          <b className="text-lg sm:text-2xl text-emerald-700 dark:text-emerald-400">{formatMoney(balances.cash)}</b>
        </div>
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-4 rounded-2xl shadow-sm">
          <span className="text-xs text-sky-600 block mb-1 font-bold">رصيد الحوالات</span>
          <b className="text-lg sm:text-2xl text-sky-700 dark:text-sky-400">{formatMoney(balances.transfer)}</b>
        </div>
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-4 rounded-2xl shadow-sm">
          <span className="text-xs text-amber-600 block mb-1 font-bold">إجمالي السيولة</span>
          <b className="text-lg sm:text-2xl text-amber-700 dark:text-amber-400">{formatMoney(balances.totalLiquidity)}</b>
        </div>
      </div>

      {/* Debt Payments Card */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
        <h3 className="text-base sm:text-lg font-black text-amber-950 dark:text-amber-300 mb-4 flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-amber-600" />
          <span>👥 تسديد ديون الزبائن</span>
        </h3>

        <form onSubmit={handleAddDebtPayment} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
          <div>
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">اسم الزبون</label>
            <input
              list="customerList"
              value={dpCustomer}
              onChange={(e) => setDpCustomer(e.target.value)}
              placeholder="اختر أو اكتب اسم الزبون"
              className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
              required
            />
            {dpCustomer && (
              <span className="text-[11px] text-rose-600 font-bold mt-1 block">
                الدين الحالي: {formatMoney(calculateCustomerDebt(dpCustomer, db.sales, db.debtPayments))}
              </span>
            )}
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">التاريخ</label>
            <input
              type="date"
              value={dpDate}
              onChange={(e) => setDpDate(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">المبلغ المسدد (ريال)</label>
            <input
              type="number"
              min="1"
              value={dpAmount}
              onChange={(e) => setDpAmount(e.target.value ? Number(e.target.value) : '')}
              placeholder="المبلغ"
              className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm font-bold text-emerald-800 outline-none focus:ring-2 focus:ring-emerald-600"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">طريقة السداد</label>
            <select
              value={dpMethod}
              onChange={(e) => setDpMethod(e.target.value as any)}
              className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-emerald-600"
            >
              <option value="cash">💵 نقد للصندوق</option>
              <option value="transfer">🏦 حوالة لحساب البنك</option>
            </select>
          </div>

          <div className="sm:col-span-2 lg:col-span-3">
            <input
              type="text"
              value={dpNote}
              onChange={(e) => setDpNote(e.target.value)}
              placeholder="ملاحظات السداد..."
              className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <button
            type="submit"
            className="py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-black text-sm shadow transition-colors cursor-pointer"
          >
            ➕ تسجيل السداد
          </button>
        </form>

        {/* Customer Debts Summary Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-stone-100 dark:bg-stone-800 text-stone-800 dark:text-stone-200 font-bold border-b">
                <th className="p-2.5">الزبون</th>
                <th className="p-2.5">إجمالي الآجل المشتري به</th>
                <th className="p-2.5">المسدد</th>
                <th className="p-2.5 font-black text-rose-700 dark:text-rose-400">الدين المتبقي</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
              {customerNames.map((name) => {
                const totalDebtPurchased = db.sales
                  .filter((s) => (s.customer || '').trim() === name)
                  .reduce((sum, s) => sum + (s.payments?.debt ?? (s.pay === 'debt' ? s.price : 0)), 0);

                const paid = db.debtPayments
                  .filter((p) => (p.customer || '').trim() === name)
                  .reduce((sum, p) => sum + Number(p.amount || 0), 0);

                const balance = Math.max(0, totalDebtPurchased - paid);

                return (
                  <tr key={name} className="hover:bg-stone-50 dark:hover:bg-stone-800/50">
                    <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{name}</td>
                    <td className="p-2.5">{formatMoney(totalDebtPurchased)}</td>
                    <td className="p-2.5 text-emerald-700 dark:text-emerald-400">{formatMoney(paid)}</td>
                    <td className="p-2.5 font-black text-rose-700 dark:text-rose-400">{formatMoney(balance)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cashbox Movements Card */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
        <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-emerald-300 mb-4 flex items-center gap-2">
          <Landmark className="w-5 h-5 text-emerald-600" />
          <span>🏦 حركة الصندوق والحسابات البنكية</span>
        </h3>

        <form onSubmit={handleAddCashMovement} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
          <div>
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">التاريخ</label>
            <input
              type="date"
              value={cmDate}
              onChange={(e) => setCmDate(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">نوع الحركة</label>
            <select
              value={cmType}
              onChange={(e) => {
                const val = e.target.value as any;
                setCmType(val);
                if (val === 'transfer_to_cash') setCmMethod('transfer');
              }}
              className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-emerald-600"
            >
              <option value="deposit">📥 إيداع</option>
              <option value="withdrawal">📤 سحب</option>
              <option value="transfer_to_cash">🔁 سحب من الحوالات إلى الصندوق النقدي</option>
              <option value="opening">🧾 رصيد افتتاحي</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">المبلغ</label>
            <input
              type="number"
              min="1"
              value={cmAmount}
              onChange={(e) => setCmAmount(e.target.value ? Number(e.target.value) : '')}
              placeholder="المبلغ"
              className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm font-bold text-emerald-800 outline-none focus:ring-2 focus:ring-emerald-600"
              required
            />
          </div>

          {cmType !== 'transfer_to_cash' && (
            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">الحساب</label>
              <select
                value={cmMethod}
                onChange={(e) => setCmMethod(e.target.value as any)}
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-emerald-600"
              >
                <option value="cash">الصندوق النقدي</option>
                <option value="transfer">الحوالات / البنك</option>
              </select>
            </div>
          )}

          <div className="sm:col-span-2 lg:col-span-3">
            <input
              type="text"
              value={cmNote}
              onChange={(e) => setCmNote(e.target.value)}
              placeholder="بيان الحركة وسببها..."
              className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <button
            type="submit"
            className="py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-sm shadow transition-colors cursor-pointer"
          >
            ➕ حفظ الحركة المالية
          </button>
        </form>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-stone-100 dark:bg-stone-800 text-stone-800 dark:text-stone-200 font-bold border-b">
                <th className="p-2.5">التاريخ</th>
                <th className="p-2.5">النوع</th>
                <th className="p-2.5">الحساب</th>
                <th className="p-2.5">المبلغ</th>
                <th className="p-2.5">البيان</th>
                <th className="p-2.5 text-center">إجراء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
              {db.cashTransactions.map((tx) => (
                <tr key={tx.id}>
                  <td className="p-2.5 font-medium">{tx.date}</td>
                  <td className="p-2.5">
                    {tx.type === 'deposit' && '📥 إيداع'}
                    {tx.type === 'withdrawal' && '📤 سحب'}
                    {tx.type === 'transfer_to_cash' && '🔁 تحويل للصندوق النقدي'}
                    {tx.type === 'opening' && '🧾 رصيد افتتاحي'}
                  </td>
                  <td className="p-2.5 font-bold">{tx.method === 'transfer' ? 'حوالة' : 'نقد'}</td>
                  <td className="p-2.5 font-black text-emerald-800 dark:text-emerald-300">{formatMoney(tx.amount)}</td>
                  <td className="p-2.5 text-stone-500">{tx.note || '—'}</td>
                  <td className="p-2.5 text-center">
                    <button
                      onClick={() => {
                        if (!confirm('حذف هذه الحركة؟')) return;
                        onUpdateDb((prev) => ({
                          ...prev,
                          cashTransactions: prev.cashTransactions.filter((c) => c.id !== tx.id),
                        }));
                      }}
                      className="p-1 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <datalist id="customerList">
        {customerNames.map((n) => (
          <option key={n} value={n} />
        ))}
      </datalist>
    </div>
  );
};
