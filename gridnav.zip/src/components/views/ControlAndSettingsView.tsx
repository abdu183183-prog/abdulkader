import React, { useState } from 'react';
import {
  ShieldCheck,
  LayoutDashboard,
  HardDrive,
  Database,
  Settings,
  Receipt,
  RotateCcw,
  Tag,
  ClipboardCheck,
  ArrowLeftRight,
  Upload,
  Download,
  AlertOctagon,
  Phone,
  MessageCircle,
  Mail,
  Globe,
  Trash2,
} from 'lucide-react';
import { AppDatabase } from '../../types/accounting';
import { formatMoney, sampleSeedDatabase } from '../../utils/initialData';
import { calculateCashBalances } from '../../utils/accountingLogic';

interface ControlAndSettingsViewProps {
  db: AppDatabase;
  activeSubView:
    | 'control47'
    | 'dashboard50'
    | 'backup'
    | 'backup48'
    | 'settings'
    | 'invoiceHistory'
    | 'returns'
    | 'discounts'
    | 'stocktake'
    | 'stockMovement';
  onUpdateDb: (updater: (prev: AppDatabase) => AppDatabase) => void;
  onOpenReceipt: (data: { title: string; items: { label: string; value: string | number }[]; notes?: string }) => void;
}

export const ControlAndSettingsView: React.FC<ControlAndSettingsViewProps> = ({
  db,
  activeSubView,
  onUpdateDb,
  onOpenReceipt,
}) => {
  const today = new Date().toISOString().slice(0, 10);

  // Settings state
  const [userName, setUserName] = useState(db.settings.userName || '');
  const [shopName, setShopName] = useState(db.settings.shopName || '');
  const [address, setAddress] = useState(db.settings.address || '');
  const [phone, setPhone] = useState(db.settings.phone || '');

  // Tracking state
  const [returnCust, setReturnCust] = useState('');
  const [returnSup, setReturnSup] = useState(db.suppliers[0] || '');
  const [returnQty, setReturnQty] = useState<number | ''>('');
  const [returnAmt, setReturnAmt] = useState<number | ''>('');
  const [returnNote, setReturnNote] = useState('');

  const [discCust, setDiscCust] = useState('');
  const [discAmt, setDiscAmt] = useState<number | ''>('');
  const [discNote, setDiscNote] = useState('');

  const [stockCounted, setStockCounted] = useState<number | ''>('');
  const [stockNote, setStockNote] = useState('');

  const [moveType, setMoveType] = useState<'addition' | 'issue' | 'damage' | 'transfer'>('addition');
  const [moveQty, setMoveQty] = useState<number | ''>('');
  const [moveItem, setMoveItem] = useState('');
  const [moveNote, setMoveNote] = useState('');

  const balances = calculateCashBalances(
    db.sales,
    db.expenses,
    db.debtPayments,
    db.supplierPayments,
    db.cashTransactions
  );

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateDb((prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        userName,
        shopName: shopName || 'محلات عبدالقادر الشعيبي للقات',
        address,
        phone,
      },
    }));
    alert('✅ تم حفظ إعدادات المحل بنجاح');
  };

  const handleExportBackup = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(db, null, 2));
    const dlAnchorElem = document.createElement('a');
    dlAnchorElem.setAttribute('href', dataStr);
    dlAnchorElem.setAttribute('download', `qat_backup_${today}.json`);
    dlAnchorElem.click();
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const parsed = JSON.parse(evt.target?.result as string);
        if (!parsed.receives || !parsed.sales) throw new Error('الملف غير مطابق');
        onUpdateDb(() => parsed);
        alert('✅ تمت استعادة النسخة الاحتياطية بنجاح!');
      } catch {
        alert('❌ ملف النسخة الاحتياطية غير صالح!');
      }
    };
    reader.readAsText(file);
  };

  const handleResetData = () => {
    if (confirm('⚠️ تحذير: هل أنت متأكد من مسح جميع البيانات؟')) {
      if (confirm('تأكيد نهائي: سيتم تصفير كل السجلات!')) {
        onUpdateDb(() => sampleSeedDatabase);
        alert('تمت استعادة البيانات الافتراضية.');
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Dashboard 5.0 */}
      {activeSubView === 'dashboard50' && (
        <div className="space-y-5">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
            <h3 className="text-base sm:text-lg font-black text-indigo-950 dark:text-indigo-300 mb-2 flex items-center gap-2">
              <LayoutDashboard className="w-5 h-5 text-indigo-600" />
              <span>🚀 لوحة التحكم اليومية V5.0</span>
            </h3>
            <p className="text-xs text-stone-500">
              {new Date().toLocaleDateString('ar-YE', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
              <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl text-center">
                <span className="text-xs text-indigo-700 block">إجمالي السيولة</span>
                <b className="text-base font-black text-indigo-900 dark:text-indigo-200">
                  {formatMoney(balances.totalLiquidity)}
                </b>
              </div>
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl text-center">
                <span className="text-xs text-emerald-700 block">النقد بالصندوق</span>
                <b className="text-base font-black text-emerald-900 dark:text-emerald-200">{formatMoney(balances.cash)}</b>
              </div>
              <div className="p-3 bg-sky-50 dark:bg-sky-950/40 rounded-xl text-center">
                <span className="text-xs text-sky-700 block">رصيد الحوالات</span>
                <b className="text-base font-black text-sky-900 dark:text-sky-200">{formatMoney(balances.transfer)}</b>
              </div>
              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl text-center">
                <span className="text-xs text-amber-700 block">إجمالي المقبوض</span>
                <b className="text-base font-black text-amber-900 dark:text-amber-200">{formatMoney(balances.collected)}</b>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Control & Closures V4.7 */}
      {activeSubView === 'control47' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-base sm:text-lg font-black text-rose-950 dark:text-rose-300 mb-4 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-rose-600" />
            <span>🔐 الإقفال والرقابة وسجل التعديلات</span>
          </h3>

          <div className="flex gap-3 mb-5">
            <input type="date" defaultValue={today} className="px-3 py-2 bg-stone-50 border rounded-xl text-sm" />
            <button
              onClick={() => alert(`تم إقفال حسابات اليوم (${today}) بنجاح`)}
              className="px-4 py-2 bg-rose-700 hover:bg-rose-800 text-white font-bold text-xs rounded-xl cursor-pointer"
            >
              🔒 إقفال اليومية
            </button>
            <button
              onClick={() => alert(`تم فتح يومية (${today})`)}
              className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs rounded-xl cursor-pointer"
            >
              🔓 فتح اليومية
            </button>
          </div>

          <h4 className="font-bold text-xs text-stone-500 mb-2">سجل الحركات والرقابة:</h4>
          <div className="overflow-x-auto max-h-60">
            <table className="w-full text-right text-xs border-collapse">
              <thead>
                <tr className="bg-stone-100 font-bold border-b">
                  <th className="p-2">الوقت</th>
                  <th className="p-2">العملية</th>
                  <th className="p-2">المرجع</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {db.auditLog.map((log) => (
                  <tr key={log.id}>
                    <td className="p-2 font-mono text-[11px]">{new Date(log.date).toLocaleTimeString('ar-YE')}</td>
                    <td className="p-2 font-bold">{log.action}</td>
                    <td className="p-2 text-stone-500">{log.ref || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Backup & Liquidity */}
      {(activeSubView === 'backup' || activeSubView === 'backup48') && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm text-center">
          <h3 className="text-base sm:text-lg font-black text-stone-900 dark:text-stone-100 mb-2 flex items-center justify-center gap-2">
            <HardDrive className="w-5 h-5 text-emerald-600" />
            <span>💾 إدارة النسخ الاحتياطية وقاعدة البيانات</span>
          </h3>
          <p className="text-xs text-stone-500 dark:text-stone-400 mb-5">
            يمكنك حفظ نسخة كاملة من البيانات بصيغة JSON لنقلها لأي جهاز آخر أو استعادتها في أي وقت.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleExportBackup}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>📥 تصدير نسخة احتياطية (JSON)</span>
            </button>

            <label className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-sm shadow cursor-pointer">
              <Upload className="w-4 h-4" />
              <span>📤 استعادة نسخة احتياطية</span>
              <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
            </label>
          </div>

          <div className="border-t border-stone-200 dark:border-stone-800 mt-6 pt-5">
            <button
              onClick={handleResetData}
              className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs mx-auto cursor-pointer"
            >
              <AlertOctagon className="w-4 h-4" />
              <span>⚠️ تصفير ومسح كافة البيانات نهائياً</span>
            </button>
          </div>
        </div>
      )}

      {/* Shop Settings */}
      {activeSubView === 'settings' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-emerald-300 mb-4 flex items-center gap-2">
            <Settings className="w-5 h-5 text-emerald-600" />
            <span>⚙️ إعدادات هوية المحل والمستخدم</span>
          </h3>

          <form onSubmit={handleSaveSettings} className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
            <div>
              <label className="block text-xs font-bold mb-1">اسم المستخدم / المحاسب</label>
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="اكتب اسم المستخدم"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">اسم المحل</label>
              <input
                type="text"
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                placeholder="اسم المحل"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">العنوان</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="العنوان"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">رقم الجوال</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="رقم الهاتف"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border rounded-xl text-sm"
              />
            </div>

            <div className="sm:col-span-2">
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow cursor-pointer"
              >
                💾 حفظ إعدادات المحل
              </button>
            </div>
          </form>

          {/* Developer Contact Card */}
          <div className="border-t border-stone-200 dark:border-stone-800 pt-4 text-xs text-stone-600 dark:text-stone-300">
            <h4 className="font-bold text-sm text-stone-800 dark:text-stone-100 mb-2">📞 تواصل بنا — فريق الدعم الفني:</h4>
            <div className="flex flex-wrap gap-2">
              <a
                href={`https://wa.me/${db.settings.developerWhatsApp || '967771501259'}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>واتساب</span>
              </a>
              <a
                href={`tel:${db.settings.developerPhone || '0771501259'}`}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-sky-100 dark:bg-sky-950 text-sky-800 dark:text-sky-300 font-bold"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>اتصال هاتف</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Invoice History */}
      {activeSubView === 'invoiceHistory' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-emerald-300 mb-4 flex items-center gap-2">
            <Receipt className="w-5 h-5 text-emerald-600" />
            <span>🧾 سجل الفواتير والإيصالات المحفوظة</span>
          </h3>

          <div className="space-y-3">
            {db.sales.slice(0, 20).map((s) => (
              <div
                key={s.id}
                className="p-3 rounded-xl border border-stone-200 dark:border-stone-700 flex items-center justify-between"
              >
                <div>
                  <b className="text-sm">{s.customer || 'فاتورة بيع عامة'}</b>
                  <div className="text-xs text-stone-500">
                    {s.date} — {s.supplier} ({s.qty} حبة)
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <b className="text-emerald-700">{formatMoney(s.price)}</b>
                  <button
                    onClick={() =>
                      onOpenReceipt({
                        title: 'فاتورة رسمية',
                        items: [
                          { label: 'المورد', value: s.supplier },
                          { label: 'الكمية', value: `${s.qty} حبة` },
                          { label: 'المبلغ', value: formatMoney(s.price) },
                          { label: 'الزبون', value: s.customer || 'نقدي' },
                        ],
                      })
                    }
                    className="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold rounded-lg text-xs"
                  >
                    معاينة
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Returns view */}
      {activeSubView === 'returns' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-base sm:text-lg font-black text-rose-950 dark:text-rose-300 mb-4 flex items-center gap-2">
            <RotateCcw className="w-5 h-5 text-rose-600" />
            <span>↩️ سجل المرتجعات</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
            <input
              type="text"
              placeholder="اسم العميل"
              value={returnCust}
              onChange={(e) => setReturnCust(e.target.value)}
              className="px-3 py-2 border rounded-xl text-xs"
            />
            <input
              type="number"
              placeholder="الكمية بالحبات"
              value={returnQty}
              onChange={(e) => setReturnQty(e.target.value ? Number(e.target.value) : '')}
              className="px-3 py-2 border rounded-xl text-xs"
            />
            <input
              type="number"
              placeholder="المبلغ (إن وجد)"
              value={returnAmt}
              onChange={(e) => setReturnAmt(e.target.value ? Number(e.target.value) : '')}
              className="px-3 py-2 border rounded-xl text-xs"
            />
            <input
              type="text"
              placeholder="سبب الإرجاع..."
              value={returnNote}
              onChange={(e) => setReturnNote(e.target.value)}
              className="sm:col-span-2 px-3 py-2 border rounded-xl text-xs"
            />
            <button
              onClick={() => {
                if (!returnQty) return alert('أدخل الكمية');
                onUpdateDb((prev) => ({
                  ...prev,
                  returns: [
                    {
                      id: Date.now(),
                      date: today,
                      customer: returnCust,
                      supplier: returnSup,
                      qty: Number(returnQty),
                      amount: Number(returnAmt || 0),
                      note: returnNote,
                    },
                    ...prev.returns,
                  ],
                }));
                setReturnQty('');
                alert('تم تسجيل المرتجع');
              }}
              className="px-4 py-2 bg-rose-700 text-white font-bold rounded-xl text-xs"
            >
              ➕ حفظ المرتجع
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-stone-100 font-bold border-b">
                  <th className="p-2">التاريخ</th>
                  <th className="p-2">العميل</th>
                  <th className="p-2">الكمية</th>
                  <th className="p-2">السبب</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {db.returns.map((r) => (
                  <tr key={r.id}>
                    <td className="p-2">{r.date}</td>
                    <td className="p-2 font-bold">{r.customer}</td>
                    <td className="p-2 font-bold text-rose-700">{r.qty} حبة</td>
                    <td className="p-2 text-stone-500">{r.note || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Discounts view */}
      {activeSubView === 'discounts' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-base sm:text-lg font-black text-purple-950 dark:text-purple-300 mb-4 flex items-center gap-2">
            <Tag className="w-5 h-5 text-purple-600" />
            <span>🏷️ سجل الخصومات</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
            <input
              type="text"
              placeholder="اسم العميل"
              value={discCust}
              onChange={(e) => setDiscCust(e.target.value)}
              className="px-3 py-2 border rounded-xl text-xs"
            />
            <input
              type="number"
              placeholder="قيمة الخصم"
              value={discAmt}
              onChange={(e) => setDiscAmt(e.target.value ? Number(e.target.value) : '')}
              className="px-3 py-2 border rounded-xl text-xs"
            />
            <button
              onClick={() => {
                if (!discAmt) return alert('أدخل قيمة الخصم');
                onUpdateDb((prev) => ({
                  ...prev,
                  discounts: [
                    {
                      id: Date.now(),
                      date: today,
                      customer: discCust,
                      amount: Number(discAmt),
                      note: discNote,
                    },
                    ...prev.discounts,
                  ],
                }));
                setDiscAmt('');
                alert('تم تسجيل الخصم');
              }}
              className="px-4 py-2 bg-purple-700 text-white font-bold rounded-xl text-xs"
            >
              ➕ حفظ الخصم
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-stone-100 font-bold border-b">
                  <th className="p-2">التاريخ</th>
                  <th className="p-2">العميل</th>
                  <th className="p-2">الخصم</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {db.discounts.map((d) => (
                  <tr key={d.id}>
                    <td className="p-2">{d.date}</td>
                    <td className="p-2 font-bold">{d.customer}</td>
                    <td className="p-2 font-bold text-purple-700">{formatMoney(d.amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Stocktake view */}
      {activeSubView === 'stocktake' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-base sm:text-lg font-black text-stone-900 dark:text-stone-100 mb-4 flex items-center gap-2">
            <ClipboardCheck className="w-5 h-5 text-emerald-600" />
            <span>📋 الجرد الفعلي ومطابقة المخزون</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
            <input
              type="number"
              placeholder="الكمية المعدودة فعلياً بالحبات"
              value={stockCounted}
              onChange={(e) => setStockCounted(e.target.value ? Number(e.target.value) : '')}
              className="px-3 py-2 border rounded-xl text-xs"
            />
            <button
              onClick={() => {
                if (stockCounted === '') return alert('أدخل الكمية الفعلية');
                const sys =
                  db.receives.reduce((a, b) => a + Number(b.shapes || 0) * 2, 0) -
                  db.sales.reduce((a, b) => a + Number(b.qty || 0), 0);
                onUpdateDb((prev) => ({
                  ...prev,
                  stocktakes: [
                    {
                      id: Date.now(),
                      date: today,
                      systemQty: sys,
                      countedQty: Number(stockCounted),
                      difference: Number(stockCounted) - sys,
                      note: stockNote,
                    },
                    ...prev.stocktakes,
                  ],
                }));
                setStockCounted('');
                alert('تم حفظ نتيجة الجرد');
              }}
              className="px-4 py-2 bg-emerald-700 text-white font-bold rounded-xl text-xs"
            >
              💾 حفظ نتيجة الجرد
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-stone-100 font-bold border-b">
                  <th className="p-2">التاريخ</th>
                  <th className="p-2">المخزون المسجل</th>
                  <th className="p-2">الفعلي بالجرد</th>
                  <th className="p-2">الفرق</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {db.stocktakes.map((st) => (
                  <tr key={st.id}>
                    <td className="p-2">{st.date}</td>
                    <td className="p-2">{st.systemQty} حبة</td>
                    <td className="p-2 font-bold">{st.countedQty} حبة</td>
                    <td
                      className={`p-2 font-bold ${
                        st.difference === 0 ? 'text-emerald-700' : 'text-rose-700'
                      }`}
                    >
                      {st.difference} حبة
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Stock movement view */}
      {activeSubView === 'stockMovement' && (
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
          <h3 className="text-base sm:text-lg font-black text-indigo-950 dark:text-indigo-300 mb-4 flex items-center gap-2">
            <ArrowLeftRight className="w-5 h-5 text-indigo-600" />
            <span>🔄 سجل حركة المخزون</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
            <select
              value={moveType}
              onChange={(e) => setMoveType(e.target.value as any)}
              className="px-3 py-2 border rounded-xl text-xs font-bold"
            >
              <option value="addition">إضافة</option>
              <option value="issue">صرف</option>
              <option value="damage">تالف</option>
              <option value="transfer">نقل</option>
            </select>
            <input
              type="number"
              placeholder="الكمية"
              value={moveQty}
              onChange={(e) => setMoveQty(e.target.value ? Number(e.target.value) : '')}
              className="px-3 py-2 border rounded-xl text-xs"
            />
            <input
              type="text"
              placeholder="البيان أو الصنف"
              value={moveItem}
              onChange={(e) => setMoveItem(e.target.value)}
              className="px-3 py-2 border rounded-xl text-xs"
            />
            <button
              onClick={() => {
                if (!moveQty) return alert('أدخل الكمية');
                onUpdateDb((prev) => ({
                  ...prev,
                  stockMovements: [
                    {
                      id: Date.now(),
                      date: today,
                      type: moveType,
                      qty: Number(moveQty),
                      item: moveItem,
                      note: moveNote,
                    },
                    ...prev.stockMovements,
                  ],
                }));
                setMoveQty('');
                alert('تم توثيق حركة المخزون');
              }}
              className="px-4 py-2 bg-indigo-700 text-white font-bold rounded-xl text-xs"
            >
              ➕ توثيق الحركة
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-stone-100 font-bold border-b">
                  <th className="p-2">التاريخ</th>
                  <th className="p-2">النوع</th>
                  <th className="p-2">الكمية</th>
                  <th className="p-2">الصنف</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {db.stockMovements.map((m) => (
                  <tr key={m.id}>
                    <td className="p-2">{m.date}</td>
                    <td className="p-2 font-bold">{m.type}</td>
                    <td className="p-2 font-bold text-indigo-700">{m.qty} حبة</td>
                    <td className="p-2">{m.item || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
