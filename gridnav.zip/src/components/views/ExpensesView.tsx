import React, { useState } from 'react';
import { ReceiptText, Search, Download, Trash2 } from 'lucide-react';
import { AppDatabase, ExpenseItem } from '../../types/accounting';
import { formatMoney, exportHtmlTableToExcel } from '../../utils/initialData';

interface ExpensesViewProps {
  db: AppDatabase;
  onUpdateDb: (updater: (prev: AppDatabase) => AppDatabase) => void;
}

export const ExpensesView: React.FC<ExpensesViewProps> = ({ db, onUpdateDb }) => {
  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(today);
  const [type, setType] = useState<'general' | 'specific'>('general');
  const [supplier, setSupplier] = useState(db.suppliers[0] || '');
  const [item, setItem] = useState('');
  const [amount, setAmount] = useState<number | ''>('');
  const [note, setNote] = useState('');
  const [search, setSearch] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'storage'>('all');

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!item.trim()) return alert('يرجى إدخال بيان المصروف');
    if (!amount || Number(amount) <= 0) return alert('يرجى إدخال المبلغ');
    if (type === 'specific' && !supplier) return alert('يرجى تحديد المورد الخاص بهذا المصروف');

    const newExp: ExpenseItem = {
      id: Date.now(),
      date,
      type,
      supplier: type === 'specific' ? supplier : undefined,
      item: item.trim(),
      amount: Number(amount),
      note: note.trim(),
    };

    onUpdateDb((prev) => ({
      ...prev,
      expenses: [newExp, ...prev.expenses],
    }));

    setItem('');
    setAmount('');
    setNote('');
    alert('✅ تم إضافة المصروف بنجاح');
  };

  const handleDelete = (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذا المصروف؟')) return;
    onUpdateDb((prev) => ({
      ...prev,
      expenses: prev.expenses.filter((e) => e.id !== id),
    }));
  };

  // Combine regular expenses and storage expenses if viewing all
  const storageSales = db.sales.filter((s) => s.pay === 'storage');

  const filteredExpenses = db.expenses.filter(
    (e) =>
      !search ||
      e.item.toLowerCase().includes(search.toLowerCase()) ||
      (e.supplier && e.supplier.toLowerCase().includes(search.toLowerCase())) ||
      e.date.includes(search)
  );

  return (
    <div className="space-y-6">
      {/* Add Expense Form Card */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
        <div className="flex items-center gap-2 border-b border-stone-200 dark:border-stone-700 pb-3 mb-4">
          <ReceiptText className="w-5 h-5 text-rose-600" />
          <h3 className="text-base sm:text-lg font-black text-rose-950 dark:text-rose-300">
            💸 تسجيل الخرج والمصاريف اليومية
          </h3>
        </div>

        <form onSubmit={handleAddExpense} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">التاريخ</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">نوع المصروف</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-emerald-600"
              >
                <option value="general">عام (يُخصم تناسبياً من كافة الموردين)</option>
                <option value="specific">خاص (يُخصم من حساب مورد محدد)</option>
              </select>
            </div>

            {type === 'specific' && (
              <div>
                <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                  تحديد المورد الخاص
                </label>
                <select
                  value={supplier}
                  onChange={(e) => setSupplier(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm font-bold text-emerald-800 outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  {db.suppliers.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                بيان المصروف
              </label>
              <input
                type="text"
                value={item}
                onChange={(e) => setItem(e.target.value)}
                placeholder="غداء، إيجار، ثلج، أكياس، ضرائب..."
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                المبلغ (ريال)
              </label>
              <input
                type="number"
                min="1"
                value={amount}
                onChange={(e) => setAmount(e.target.value ? Number(e.target.value) : '')}
                placeholder="المبلغ"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm font-bold text-rose-700 outline-none focus:ring-2 focus:ring-emerald-600"
                required
              />
            </div>

            <div className="sm:col-span-2 lg:col-span-1">
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">ملاحظات</label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="تفاصيل إضافية..."
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-rose-700 hover:bg-rose-800 text-white font-bold text-sm shadow transition-colors cursor-pointer"
          >
            ➕ إضافة المصروف
          </button>
        </form>
      </div>

      {/* Expenses Table Card */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2 flex-1">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                placeholder="🔍 بحث في الخرج والمصاريف..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-3 pr-9 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <select
              value={filterMode}
              onChange={(e) => setFilterMode(e.target.value as any)}
              className="text-xs bg-stone-100 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl px-2.5 py-2 font-bold"
            >
              <option value="all">كل الخرج والمصاريف</option>
              <option value="storage">التخزينات فقط</option>
            </select>
          </div>

          <button
            onClick={() => exportHtmlTableToExcel('e_table_el', 'سجل_الخرج_العام')}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 text-xs font-bold shadow-sm transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تصدير Excel</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table id="e_table_el" className="w-full text-right text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-stone-100 dark:bg-stone-800 text-emerald-900 dark:text-emerald-300 font-bold border-b border-stone-200 dark:border-stone-700">
                <th className="p-2.5">التاريخ</th>
                <th className="p-2.5">النوع</th>
                <th className="p-2.5">البيان / المستفيد</th>
                <th className="p-2.5">المبلغ</th>
                <th className="p-2.5">ملاحظات</th>
                <th className="p-2.5 no-print text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
              {filterMode !== 'storage' &&
                filteredExpenses.map((e) => (
                  <tr key={e.id} className="hover:bg-stone-50 dark:hover:bg-stone-800/50">
                    <td className="p-2.5 font-medium">{e.date}</td>
                    <td className="p-2.5">
                      {e.type === 'general' ? (
                        <span className="px-2 py-0.5 rounded-full text-xs bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold">
                          عام (تناسبي)
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-xs bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-bold">
                          خاص: {e.supplier}
                        </span>
                      )}
                    </td>
                    <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{e.item}</td>
                    <td className="p-2.5 font-bold text-rose-700 dark:text-rose-400">{formatMoney(e.amount)}</td>
                    <td className="p-2.5 text-stone-500 max-w-xs truncate">{e.note || '—'}</td>
                    <td className="p-2.5 no-print text-center">
                      <button
                        onClick={() => handleDelete(e.id)}
                        className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 text-rose-700 dark:text-rose-300"
                        title="حذف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}

              {/* Show storage sales as expenses too */}
              {storageSales.map((s) => (
                <tr key={`storage-${s.id}`} className="bg-amber-50/50 dark:bg-amber-950/20">
                  <td className="p-2.5 font-medium">{s.date}</td>
                  <td className="p-2.5">
                    <span className="px-2 py-0.5 rounded-full text-xs bg-yellow-100 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-300 font-bold">
                      📦 تخزينة قات
                    </span>
                  </td>
                  <td className="p-2.5 font-bold text-stone-800 dark:text-stone-200">
                    تخزينة ({s.supplier}) — {s.qty} حبة
                  </td>
                  <td className="p-2.5 font-bold text-amber-700 dark:text-amber-400">
                    {formatMoney(s.storageValue ?? s.price)}
                  </td>
                  <td className="p-2.5 text-stone-500">{s.customer || s.note || 'تخزينة يومية'}</td>
                  <td className="p-2.5 no-print text-center text-xs text-stone-400">من المبيعات</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
