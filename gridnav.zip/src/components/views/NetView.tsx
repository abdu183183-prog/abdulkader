import React from 'react';
import { Calculator, Download, Info } from 'lucide-react';
import { AppDatabase } from '../../types/accounting';
import { formatMoney, exportHtmlTableToExcel } from '../../utils/initialData';
import { calculateProportionalShare } from '../../utils/accountingLogic';

interface NetViewProps {
  db: AppDatabase;
}

export const NetView: React.FC<NetViewProps> = ({ db }) => {
  const suppliers = Array.from(
    new Set([...db.suppliers, ...db.receives.map((r) => r.supplier), ...db.sales.map((s) => s.supplier)].filter(Boolean))
  );

  const totalSoldPieces = db.sales
    .filter((s) => s.pay !== 'storage')
    .reduce((sum, s) => sum + Number(s.qty || 0), 0);

  const generalExpensesPure = db.expenses
    .filter((e) => e.type !== 'specific')
    .reduce((sum, e) => sum + Number(e.amount || 0), 0);

  const totalStorageValue = db.sales
    .filter((s) => s.pay === 'storage')
    .reduce((sum, s) => sum + Number(s.storageValue ?? s.price ?? 0), 0);

  const generalExpenseTotal = generalExpensesPure + totalStorageValue;

  const rows = suppliers.map((supplier) => {
    const receivedShapes = db.receives
      .filter((r) => r.supplier === supplier)
      .reduce((sum, r) => sum + Number(r.shapes || 0), 0);

    const soldPieces = db.sales
      .filter((s) => s.supplier === supplier && s.pay !== 'storage')
      .reduce((sum, s) => sum + Number(s.qty || 0), 0);

    const grossSales = db.sales
      .filter((s) => s.supplier === supplier && s.pay !== 'storage')
      .reduce((sum, s) => sum + Number(s.price || 0), 0);

    // Share of general expenses (including storage) based on sold pieces
    const shareGeneral = calculateProportionalShare(
      totalSoldPieces,
      soldPieces,
      generalExpensesPure,
      totalStorageValue
    );

    // Specific expenses for this supplier
    const specExp = db.expenses
      .filter((e) => e.type === 'specific' && e.supplier === supplier)
      .reduce((sum, e) => sum + Number(e.amount || 0), 0);

    // Receive direct costs (transport, commission, purchase cost)
    const recCosts = db.receives
      .filter((r) => r.supplier === supplier)
      .reduce((sum, r) => sum + Number(r.cost || 0) + Number(r.transport || 0) + Number(r.commission || 0), 0);

    const totalSpecificAndDirect = specExp + recCosts;
    const finalNet = grossSales - shareGeneral - totalSpecificAndDirect;
    const netPerPiece = soldPieces > 0 ? Math.round(finalNet / soldPieces) : 0;

    return {
      supplier,
      receivedShapes,
      soldPieces,
      grossSales,
      shareGeneral: Math.round(shareGeneral),
      totalSpecificAndDirect,
      finalNet: Math.round(finalNet),
      netPerPiece,
    };
  });

  return (
    <div className="space-y-6">
      {/* Rule Explanation Banner */}
      <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 rounded-2xl p-4 sm:p-5 shadow-sm">
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1.5 text-xs sm:text-sm text-stone-800 dark:text-stone-200">
            <h3 className="font-black text-amber-900 dark:text-amber-300 text-sm sm:text-base">
              💡 قاعدة التقسيم التناسبي للخرج العام والتخزينة:
            </h3>
            <p>
              • يتم جمع <b>المصاريف العامة ({formatMoney(generalExpensesPure)})</b> +{' '}
              <b>إجمالي قيمة التخزينة ({formatMoney(totalStorageValue)})</b> لتكوين [إجمالي الخرج العام ={' '}
              <b>{formatMoney(generalExpenseTotal)}</b>].
            </p>
            <p>
              • يُوزع الخرج العام تناسبياً على الموردين بحسب <u>عدد الحبات المباعة فقط ({totalSoldPieces} حبة)</u> لكل مورد.
            </p>
            <p>• يُخصم الخرج الخاص وتكاليف النقل والعمولات المباشرة من حساب المورد المخصص فوراً.</p>
          </div>
        </div>
      </div>

      {/* Main Net Table */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-5 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-emerald-600" />
            <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-emerald-300">
              📈 التوزيع التناسبي للخرج والتخزينة والصافي لكل مورد
            </h3>
          </div>

          <button
            onClick={() => exportHtmlTableToExcel('n_table_el', 'الصافي_والتقسيم_التناسبي')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 text-xs font-bold transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تصدير Excel</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table id="n_table_el" className="w-full text-right text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-stone-100 dark:bg-stone-800 text-emerald-900 dark:text-emerald-300 font-bold border-b border-stone-200 dark:border-stone-700">
                <th className="p-2.5">المورد</th>
                <th className="p-2.5">أشكال مستلمة</th>
                <th className="p-2.5">مباع (حبات)</th>
                <th className="p-2.5">إجمالي المبيعات</th>
                <th className="p-2.5 text-rose-700 dark:text-rose-400">نصيب الخرج العام</th>
                <th className="p-2.5 text-rose-700 dark:text-rose-400">الخرج الخاص والنقل</th>
                <th className="p-2.5 font-black text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40">
                  الصافي النهائي للمورد
                </th>
                <th className="p-2.5">صافي الحبة المباعة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
              {rows.map((r) => (
                <tr key={r.supplier} className="hover:bg-stone-50 dark:hover:bg-stone-800/50">
                  <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{r.supplier}</td>
                  <td className="p-2.5">{r.receivedShapes} شكل</td>
                  <td className="p-2.5 font-bold text-blue-700 dark:text-blue-400">{r.soldPieces} حبة</td>
                  <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{formatMoney(r.grossSales)}</td>
                  <td className="p-2.5 font-semibold text-rose-700 dark:text-rose-400">{formatMoney(r.shareGeneral)}</td>
                  <td className="p-2.5 font-semibold text-rose-700 dark:text-rose-400">
                    {formatMoney(r.totalSpecificAndDirect)}
                  </td>
                  <td className="p-2.5 font-black text-emerald-900 dark:text-emerald-200 bg-emerald-50/60 dark:bg-emerald-950/30">
                    {formatMoney(r.finalNet)}
                  </td>
                  <td className="p-2.5 font-semibold text-amber-700 dark:text-amber-400">{formatMoney(r.netPerPiece)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
