import React, { useState } from 'react';
import { PackagePlus, Search, Printer, Trash2, Edit3, Download, Sparkles, MessageSquare } from 'lucide-react';
import { AppDatabase, ReceiveItem } from '../../types/accounting';
import { formatMoney, exportHtmlTableToExcel } from '../../utils/initialData';
import { buildSupplierReceiveMessage, getWhatsAppUrl } from '../../utils/whatsapp';

interface ReceiveViewProps {
  db: AppDatabase;
  onUpdateDb: (updater: (prev: AppDatabase) => AppDatabase) => void;
  onOpenReceipt: (data: { title: string; items: { label: string; value: string | number }[]; notes?: string }) => void;
  onOpenWhatsApp?: (payload: { title: string; recipientName: string; defaultPhone?: string; messageText: string }) => void;
}

export const ReceiveView: React.FC<ReceiveViewProps> = ({
  db,
  onUpdateDb,
  onOpenReceipt,
  onOpenWhatsApp,
}) => {
  const today = new Date().toISOString().slice(0, 10);
  const days = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const dayName = days[new Date().getDay()];

  const [date, setDate] = useState(today);
  const [supplier, setSupplier] = useState('');
  const [phone, setPhone] = useState('');
  const [type, setType] = useState('ضالعي ممتاز');
  const [shapes, setShapes] = useState<number | ''>(10);
  const [bundles, setBundles] = useState<number | ''>(20);
  const [cost, setCost] = useState<number | ''>('');
  const [transport, setTransport] = useState<number | ''>('');
  const [commission, setCommission] = useState<number | ''>('');
  const [note, setNote] = useState('');
  const [search, setSearch] = useState('');
  const [lastSavedReceive, setLastSavedReceive] = useState<ReceiveItem | null>(null);

  // Editing state
  const [editingItem, setEditingItem] = useState<ReceiveItem | null>(null);

  const handleSupplierChange = (val: string) => {
    setSupplier(val);
    const existing = db.supplierDetails.find((s) => s.name === val.trim());
    if (existing && existing.phone) {
      setPhone(existing.phone);
    }
  };

  const handleSaveReceive = (e: React.FormEvent) => {
    e.preventDefault();
    const supName = supplier.trim();
    if (!supName) {
      alert('يرجى إدخال اسم المورد');
      return;
    }
    const numShapes = Number(shapes);
    if (!numShapes || numShapes <= 0) {
      alert('يرجى إدخال الكمية بالأشكال بشكل صحيح');
      return;
    }

    const calculatedDay = days[new Date(date).getDay()] || '';

    if (editingItem) {
      onUpdateDb((prev) => ({
        ...prev,
        receives: prev.receives.map((r) =>
          r.id === editingItem.id
            ? {
                ...r,
                date,
                day: calculatedDay,
                supplier: supName,
                phone,
                type,
                shapes: numShapes,
                bundles: Number(bundles || 0),
                cost: Number(cost || 0),
                transport: Number(transport || 0),
                commission: Number(commission || 0),
                note,
              }
            : r
        ),
      }));
      setEditingItem(null);
      alert('تم تحديث بيانات الاستلام بنجاح');
    } else {
      const newReceive: ReceiveItem = {
        id: Date.now(),
        date,
        day: calculatedDay,
        supplier: supName,
        phone,
        type,
        shapes: numShapes,
        bundles: Number(bundles || 0),
        time: new Date().toTimeString().slice(0, 5),
        cost: Number(cost || 0),
        transport: Number(transport || 0),
        commission: Number(commission || 0),
        note,
      };

      onUpdateDb((prev) => {
        // Add supplier to list if new
        const suppliersList = prev.suppliers.includes(supName) ? prev.suppliers : [...prev.suppliers, supName];
        const supplierDetailsList = prev.supplierDetails.some((s) => s.name === supName)
          ? prev.supplierDetails
          : [
              ...prev.supplierDetails,
              {
                id: prev.supplierDetails.length ? Math.max(...prev.supplierDetails.map((s) => s.id)) + 1 : 1,
                name: supName,
                phone,
              },
            ];

        return {
          ...prev,
          suppliers: suppliersList,
          supplierDetails: supplierDetailsList,
          receives: [newReceive, ...prev.receives],
        };
      });

      setLastSavedReceive(newReceive);

      if (onOpenWhatsApp) {
        onOpenWhatsApp({
          title: 'إشعار استلام شحنة قات للمورد عبر واتساب',
          recipientName: newReceive.supplier,
          defaultPhone: newReceive.phone || '',
          messageText: buildSupplierReceiveMessage(newReceive, db.settings),
        });
      }
    }

    // Reset form
    setShapes('');
    setBundles('');
    setCost('');
    setTransport('');
    setCommission('');
    setNote('');
  };

  const handleEdit = (item: ReceiveItem) => {
    setEditingItem(item);
    setDate(item.date);
    setSupplier(item.supplier);
    setPhone(item.phone || '');
    setType(item.type || '');
    setShapes(item.shapes);
    setBundles(item.bundles || '');
    setCost(item.cost || '');
    setTransport(item.transport || '');
    setCommission(item.commission || '');
    setNote(item.note || '');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = (id: number) => {
    const item = db.receives.find((r) => r.id === id);
    if (!item) return;

    // Check if supplier has sales
    const supplierSalesCount = db.sales.filter((s) => s.supplier === item.supplier).length;
    if (supplierSalesCount > 0) {
      if (!confirm(`المورد (${item.supplier}) لديه مبيعات مسجلة. هل أنت متأكد من حذف هذا السند؟`)) {
        return;
      }
    } else {
      if (!confirm('هل أنت متأكد من حذف سند الاستلام هذا؟')) return;
    }

    onUpdateDb((prev) => ({
      ...prev,
      receives: prev.receives.filter((r) => r.id !== id),
    }));
  };

  const filteredReceives = db.receives.filter(
    (r) =>
      !search ||
      r.supplier.toLowerCase().includes(search.toLowerCase()) ||
      (r.type && r.type.toLowerCase().includes(search.toLowerCase())) ||
      r.date.includes(search)
  );

  return (
    <div className="space-y-6">
      {/* Last Saved Receive WhatsApp Banner */}
      {lastSavedReceive && (
        <div className="bg-emerald-50 dark:bg-emerald-950/60 border-2 border-emerald-500 rounded-2xl p-3.5 sm:p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-sm shrink-0">✓</div>
            <div>
              <div className="font-black text-sm text-emerald-950 dark:text-emerald-100">
                تم حفظ استلام شحنة القات للمورد ({lastSavedReceive.supplier}) بنجاح!
              </div>
              <div className="text-xs text-emerald-700 dark:text-emerald-300">
                الكمية: {lastSavedReceive.shapes} شكل ({lastSavedReceive.shapes * 2} حبة) {lastSavedReceive.phone ? `— الهاتف: ${lastSavedReceive.phone}` : ''}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => {
                if (onOpenWhatsApp) {
                  onOpenWhatsApp({
                    title: 'إرسال إشعار استلام للمورد عبر واتساب',
                    recipientName: lastSavedReceive.supplier,
                    defaultPhone: lastSavedReceive.phone || '',
                    messageText: buildSupplierReceiveMessage(lastSavedReceive, db.settings),
                  });
                } else {
                  window.open(getWhatsAppUrl(lastSavedReceive.phone, buildSupplierReceiveMessage(lastSavedReceive, db.settings)), '_blank');
                }
              }}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-stone-950 font-black text-xs sm:text-sm shadow cursor-pointer"
            >
              <MessageSquare className="w-4 h-4" />
              <span>📱 إرسال إشعار للمورد عبر واتساب</span>
            </button>
            <button
              type="button"
              onClick={() => setLastSavedReceive(null)}
              className="p-2 text-stone-400 hover:text-stone-600 text-xs cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Receive Form Card */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-6 shadow-sm">
        <div className="flex items-center justify-between border-b border-stone-200 dark:border-stone-700 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <PackagePlus className="w-5 h-5 text-emerald-600" />
            <h3 className="text-base sm:text-lg font-black text-emerald-950 dark:text-emerald-300">
              {editingItem ? '✏️ تعديل بيانات استلام الشحنة' : '📦 استلام شحنات القات اليومية'}
            </h3>
          </div>
          {editingItem && (
            <button
              onClick={() => setEditingItem(null)}
              className="text-xs bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 px-3 py-1 rounded-lg text-stone-600 dark:text-stone-300 font-bold"
            >
              إلغاء التعديل
            </button>
          )}
        </div>

        <form onSubmit={handleSaveReceive} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {/* التاريخ */}
            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                📅 التاريخ واليوم ({days[new Date(date).getDay()] || dayName})
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-600 outline-none"
                required
              />
            </div>

            {/* اسم المورد */}
            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                اسم المورد
              </label>
              <input
                list="suppliersDatalist"
                value={supplier}
                onChange={(e) => handleSupplierChange(e.target.value)}
                placeholder="اختر أو اكتب اسم المورد"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-600 outline-none"
                required
              />
              <datalist id="suppliersDatalist">
                {db.suppliers.map((s) => (
                  <option key={s} value={s} />
                ))}
              </datalist>
            </div>

            {/* جوال المورد */}
            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                جوال المورد
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="077..."
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-600 outline-none"
              />
            </div>

            {/* نوع القات */}
            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                نوع القات
              </label>
              <input
                type="text"
                value={type}
                onChange={(e) => setType(e.target.value)}
                placeholder="ضالعي، صعدي، شعيبي..."
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-600 outline-none"
              />
            </div>

            {/* الكمية بالأشكال */}
            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                الكمية (بالأشكال) <span className="text-amber-600 dark:text-amber-400 font-black">({Number(shapes || 0) * 2} حبة)</span>
              </label>
              <input
                type="number"
                step="0.25"
                min="0.25"
                value={shapes}
                onChange={(e) => setShapes(e.target.value ? Number(e.target.value) : '')}
                placeholder="مثال: 10 أشكال"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm font-bold text-emerald-800 dark:text-emerald-300 focus:ring-2 focus:ring-emerald-600 outline-none"
                required
              />
            </div>

            {/* عدد المرابط */}
            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                عدد المرابط
              </label>
              <input
                type="number"
                value={bundles}
                onChange={(e) => setBundles(e.target.value ? Number(e.target.value) : '')}
                placeholder="مثال: 20 مربط"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-600 outline-none"
              />
            </div>

            {/* تكلفة الشراء */}
            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                تكلفة الشراء (ريال)
              </label>
              <input
                type="number"
                min="0"
                value={cost}
                onChange={(e) => setCost(e.target.value ? Number(e.target.value) : '')}
                placeholder="المبلغ"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-600 outline-none"
              />
            </div>

            {/* أجرة النقل والتحميل */}
            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                أجرة النقل والتحميل
              </label>
              <input
                type="number"
                min="0"
                value={transport}
                onChange={(e) => setTransport(e.target.value ? Number(e.target.value) : '')}
                placeholder="أجرة النقل"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-600 outline-none"
              />
            </div>

            {/* عمولة المورد */}
            <div>
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                عمولة المورد
              </label>
              <input
                type="number"
                min="0"
                value={commission}
                onChange={(e) => setCommission(e.target.value ? Number(e.target.value) : '')}
                placeholder="العمولة"
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-600 outline-none"
              />
            </div>

            {/* ملاحظات الاستلام */}
            <div className="sm:col-span-2 lg:col-span-3">
              <label className="block text-xs font-bold text-stone-700 dark:text-stone-300 mb-1">
                ملاحظات وتفاصيل الشحنة
              </label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="أي تفاصيل أو ملاحظات إضافية..."
                className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-600 outline-none"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-700 to-emerald-900 hover:from-emerald-800 hover:to-emerald-950 text-white font-black text-sm sm:text-base shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Sparkles className="w-5 h-5 text-amber-300" />
              <span>{editingItem ? 'حفظ التعديلات' : '➕ حفظ بيانات سند الاستلام'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Receives Table Card */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              placeholder="🔍 بحث بالمورد أو النوع أو التاريخ..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-3 pr-9 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs sm:text-sm text-stone-800 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <button
            onClick={() => exportHtmlTableToExcel('r_table_el', 'سجل_استلام_القات')}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 text-xs font-bold shadow-sm transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تصدير Excel</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table id="r_table_el" className="w-full text-right text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-stone-100 dark:bg-stone-800 text-emerald-900 dark:text-emerald-300 font-bold border-b border-stone-200 dark:border-stone-700">
                <th className="p-2.5">التاريخ واليوم</th>
                <th className="p-2.5">المورد</th>
                <th className="p-2.5">النوع</th>
                <th className="p-2.5">الأشكال</th>
                <th className="p-2.5">الحبات</th>
                <th className="p-2.5">المرابط</th>
                <th className="p-2.5">التكلفة الإجمالية</th>
                <th className="p-2.5">ملاحظات</th>
                <th className="p-2.5 no-print text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
              {filteredReceives.map((r) => {
                const totalCost = Number(r.cost || 0) + Number(r.transport || 0) + Number(r.commission || 0);

                return (
                  <tr key={r.id} className="hover:bg-stone-50 dark:hover:bg-stone-800/50 transition-colors">
                    <td className="p-2.5">
                      <div className="font-semibold text-stone-800 dark:text-stone-200">{r.date}</div>
                      <div className="text-[11px] text-amber-600 dark:text-amber-400">{r.day}</div>
                    </td>
                    <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{r.supplier}</td>
                    <td className="p-2.5 text-stone-600 dark:text-stone-300">{r.type || '—'}</td>
                    <td className="p-2.5 font-bold text-emerald-700 dark:text-emerald-400">{r.shapes} شكل</td>
                    <td className="p-2.5 font-bold text-emerald-800 dark:text-emerald-300">{r.shapes * 2} حبة</td>
                    <td className="p-2.5">{r.bundles || 0}</td>
                    <td className="p-2.5 font-bold text-stone-800 dark:text-stone-200">{formatMoney(totalCost)}</td>
                    <td className="p-2.5 text-stone-500 dark:text-stone-400 max-w-xs truncate">{r.note || '—'}</td>
                    <td className="p-2.5 no-print">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() =>
                            onOpenReceipt({
                              title: 'سند استلام قات',
                              items: [
                                { label: 'المورد', value: r.supplier },
                                { label: 'التاريخ', value: `${r.date} (${r.day || ''})` },
                                { label: 'النوع', value: r.type || 'عادي' },
                                { label: 'الكمية بالأشكال', value: `${r.shapes} شكل` },
                                { label: 'الكمية بالحبات', value: `${r.shapes * 2} حبة` },
                                { label: 'عدد المرابط', value: `${r.bundles || 0} مربط` },
                                { label: 'تكلفة الشراء', value: formatMoney(r.cost) },
                                { label: 'أجرة النقل', value: formatMoney(r.transport) },
                                { label: 'عمولة المورد', value: formatMoney(r.commission) },
                                { label: 'إجمالي التكلفة', value: formatMoney(totalCost) },
                              ],
                              notes: r.note,
                            })
                          }
                          className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 text-emerald-700 dark:text-emerald-300"
                          title="طباعة سند الاستلام"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (onOpenWhatsApp) {
                              onOpenWhatsApp({
                                title: 'إشعار استلام شحنة قات للمورد عبر واتساب',
                                recipientName: r.supplier,
                                defaultPhone: r.phone || '',
                                messageText: buildSupplierReceiveMessage(r, db.settings),
                              });
                            } else {
                              window.open(getWhatsAppUrl(r.phone, buildSupplierReceiveMessage(r, db.settings)), '_blank');
                            }
                          }}
                          className="p-1.5 rounded-lg bg-green-50 dark:bg-green-950/60 hover:bg-green-100 text-green-700 dark:text-green-300 cursor-pointer"
                          title="إرسال إشعار للمورد عبر واتساب"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => handleEdit(r)}
                          className="p-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 text-amber-700 dark:text-amber-300"
                          title="تعديل"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => handleDelete(r.id)}
                          className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 text-rose-700 dark:text-rose-300"
                          title="حذف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
