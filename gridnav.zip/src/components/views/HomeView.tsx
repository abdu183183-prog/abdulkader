import React from 'react';
import {
  PackageCheck,
  TrendingUp,
  Boxes,
  Banknote,
  Repeat,
  AlertCircle,
  Archive,
  ArrowDownCircle,
  Landmark,
  Wallet,
  ShieldCheck,
  Award,
  Download,
} from 'lucide-react';
import { AppDatabase } from '../../types/accounting';
import { formatMoney, exportHtmlTableToExcel } from '../../utils/initialData';
import { getPaymentOf } from '../../utils/accountingLogic';

interface HomeViewProps {
  db: AppDatabase;
  onNavigate: (pageId: any) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ db, onNavigate }) => {
  // Aggregate calculations
  const totalShapes = db.receives.reduce((sum, r) => sum + Number(r.shapes || 0), 0);
  const totalReceivedPieces = totalShapes * 2;
  const totalSoldPieces = db.sales.reduce((sum, s) => sum + Number(s.qty || 0), 0);
  const totalStockPieces = totalReceivedPieces - totalSoldPieces;

  const salesCash = db.sales.reduce((sum, s) => sum + getPaymentOf(s).cash, 0);
  const salesTransfer = db.sales.reduce((sum, s) => sum + getPaymentOf(s).transfer, 0);
  const salesDebt = db.sales.reduce((sum, s) => sum + getPaymentOf(s).debt, 0);
  const totalSalesVal = db.sales.reduce((sum, s) => sum + Number(s.price || 0), 0);

  const storageValTotal = db.sales
    .filter((s) => s.pay === 'storage')
    .reduce((sum, s) => sum + Number(s.storageValue ?? s.price ?? 0), 0);

  const totalRegularSoldPieces = db.sales
    .filter((s) => s.pay !== 'storage')
    .reduce((sum, s) => sum + Number(s.qty || 0), 0);

  const totalStoredPieces = db.sales
    .filter((s) => s.pay === 'storage')
    .reduce((sum, s) => sum + Number(s.qty || 0), 0);

  const totalProgressPercent =
    totalReceivedPieces > 0
      ? Math.min(100, Math.round(((totalRegularSoldPieces + totalStoredPieces) / totalReceivedPieces) * 100))
      : 0;

  const generalExpensesPure = db.expenses
    .filter((e) => e.type !== 'specific')
    .reduce((sum, e) => sum + Number(e.amount || 0), 0);
  const generalExpenseTotal = generalExpensesPure + storageValTotal;

  const specificExpensesTotal = db.expenses
    .filter((e) => e.type === 'specific')
    .reduce((sum, e) => sum + Number(e.amount || 0), 0);

  const receiveCostsTotal = db.receives.reduce(
    (sum, r) => sum + Number(r.cost || 0) + Number(r.transport || 0) + Number(r.commission || 0),
    0
  );

  const grandExpenses = generalExpenseTotal + specificExpensesTotal + receiveCostsTotal;
  const netProfit = totalSalesVal - grandExpenses;

  // Real cashbox & transfer
  const debtCash = db.debtPayments
    .filter((d) => d.method === 'cash')
    .reduce((sum, d) => sum + Number(d.amount || 0), 0);
  const debtTransfer = db.debtPayments
    .filter((d) => d.method === 'transfer')
    .reduce((sum, d) => sum + Number(d.amount || 0), 0);

  const cashMoves = db.cashTransactions
    .filter((c) => c.method === 'cash' && c.type !== 'transfer_to_cash')
    .reduce((sum, c) => sum + (c.type === 'withdrawal' ? -Number(c.amount || 0) : Number(c.amount || 0)), 0);

  const internalTransfers = db.cashTransactions
    .filter((c) => c.type === 'transfer_to_cash')
    .reduce((sum, c) => sum + Number(c.amount || 0), 0);

  const transferMoves = db.cashTransactions
    .filter((c) => c.method === 'transfer' && c.type !== 'transfer_to_cash')
    .reduce((sum, c) => sum + (c.type === 'withdrawal' ? -Number(c.amount || 0) : Number(c.amount || 0)), 0);

  const supplierPaidCash = db.supplierPayments
    .filter((s) => s.method === 'cash')
    .reduce((sum, s) => sum + Number(s.amount || 0), 0);

  const supplierPaidTransfer = db.supplierPayments
    .filter((s) => s.method === 'transfer')
    .reduce((sum, s) => sum + Number(s.amount || 0), 0);

  const cashInBox =
    salesCash + debtCash + cashMoves + internalTransfers - (generalExpensesPure + specificExpensesTotal) - supplierPaidCash;
  const transferInBox = salesTransfer + debtTransfer + transferMoves - internalTransfers - supplierPaidTransfer;
  const totalLiquidity = cashInBox + transferInBox;

  // Unique suppliers list
  const allSuppliers = Array.from(
    new Set([...db.suppliers, ...db.receives.map((r) => r.supplier), ...db.sales.map((s) => s.supplier)].filter(Boolean))
  );

  return (
    <div className="space-y-6">
      {/* Overview Stat Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* المستلم */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 mb-1">
            <span className="text-xs font-bold">إجمالي المستلم</span>
            <PackageCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-lg sm:text-2xl font-black text-emerald-950 dark:text-emerald-300">
            {totalShapes} <span className="text-xs font-normal">شكل ({totalReceivedPieces} حبة)</span>
          </div>
        </div>

        {/* المباع */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 mb-1">
            <span className="text-xs font-bold">إجمالي المباع</span>
            <TrendingUp className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-lg sm:text-2xl font-black text-blue-950 dark:text-blue-300">
            {totalSoldPieces} <span className="text-xs font-normal">حبة</span>
          </div>
        </div>

        {/* المخزون المتبقي */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 mb-1">
            <span className="text-xs font-bold">المخزون المتبقي</span>
            <Boxes className="w-4 h-4 text-amber-600" />
          </div>
          <div
            className={`text-lg sm:text-2xl font-black ${
              totalStockPieces < 0 ? 'text-rose-600' : 'text-stone-800 dark:text-stone-100'
            }`}
          >
            {totalStockPieces} <span className="text-xs font-normal">حبة</span>
          </div>
        </div>

        {/* المبيعات النقدية */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 mb-1">
            <span className="text-xs font-bold">المبيعات النقدية</span>
            <Banknote className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-base sm:text-xl font-black text-emerald-700 dark:text-emerald-400">
            {formatMoney(salesCash)}
          </div>
        </div>

        {/* الحوالات */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 mb-1">
            <span className="text-xs font-bold">المبيعات حوالة</span>
            <Repeat className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-base sm:text-xl font-black text-sky-700 dark:text-sky-400">
            {formatMoney(salesTransfer)}
          </div>
        </div>

        {/* الديون والآجل */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 mb-1">
            <span className="text-xs font-bold">الديون والآجل</span>
            <AlertCircle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-base sm:text-xl font-black text-rose-700 dark:text-rose-400">
            {formatMoney(salesDebt)}
          </div>
        </div>

        {/* التخزينة */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 mb-1">
            <span className="text-xs font-bold">قيمة التخزينة</span>
            <Archive className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-base sm:text-xl font-black text-amber-700 dark:text-amber-400">
            {formatMoney(storageValTotal)}
          </div>
        </div>

        {/* الخرج العام */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 mb-1">
            <span className="text-xs font-bold">الخرج العام شامل التخزينة</span>
            <ArrowDownCircle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-base sm:text-xl font-black text-rose-700 dark:text-rose-400">
            {formatMoney(generalExpenseTotal)}
          </div>
        </div>

        {/* النقد بالصندوق */}
        <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-emerald-800 dark:text-emerald-300 mb-1">
            <span className="text-xs font-bold">النقد بالصندوق</span>
            <Wallet className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-base sm:text-xl font-black text-emerald-900 dark:text-emerald-200">
            {formatMoney(cashInBox)}
          </div>
        </div>

        {/* رصيد الحوالات */}
        <div className="bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-sky-800 dark:text-sky-300 mb-1">
            <span className="text-xs font-bold">رصيد الحوالات</span>
            <Landmark className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-base sm:text-xl font-black text-sky-900 dark:text-sky-200">
            {formatMoney(transferInBox)}
          </div>
        </div>

        {/* إجمالي السيولة */}
        <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-amber-800 dark:text-amber-300 mb-1">
            <span className="text-xs font-bold">إجمالي السيولة الفعلية</span>
            <ShieldCheck className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-base sm:text-xl font-black text-amber-900 dark:text-amber-200">
            {formatMoney(totalLiquidity)}
          </div>
        </div>

        {/* الصافي الكلي للربح */}
        <div className="bg-gradient-to-br from-emerald-800 to-teal-900 text-white rounded-2xl p-3.5 shadow-md">
          <div className="flex items-center justify-between text-emerald-200 mb-1">
            <span className="text-xs font-bold">الصافي الكلي للربح</span>
            <Award className="w-4 h-4 text-amber-300" />
          </div>
          <div className="text-base sm:text-xl font-black text-white">
            {formatMoney(netProfit)}
          </div>
        </div>
      </div>

      {/* Supplier Performance Table */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 sm:p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-base sm:text-lg font-black text-emerald-900 dark:text-emerald-300">
              📊 ملخص حركة العمليات والموردين
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              متابعة الكميات المستلمة والمباعة ونسبة الإنجاز والمبيعات لكل مورد
            </p>
          </div>

          <button
            onClick={() => exportHtmlTableToExcel('homeTableEl', 'ملخص_حركة_العمليات_الكلية')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 text-xs font-bold shadow-sm transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تصدير Excel</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table id="homeTableEl" className="w-full text-right text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-stone-100 dark:bg-stone-800 text-emerald-900 dark:text-emerald-300 font-bold border-b border-stone-200 dark:border-stone-700">
                <th className="p-2.5">المورد</th>
                <th className="p-2.5">المستلم (حبات)</th>
                <th className="p-2.5">المباع</th>
                <th className="p-2.5">التخزينة (حبات)</th>
                <th className="p-2.5 text-amber-800 dark:text-amber-300">قيمة التخزينة</th>
                <th className="p-2.5">المتبقي</th>
                <th className="p-2.5">نسبة الإنجاز</th>
                <th className="p-2.5">مبيعات نقدية</th>
                <th className="p-2.5">حوالات</th>
                <th className="p-2.5">ديون وآجل</th>
                <th className="p-2.5 font-black">إجمالي المبيعات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
              {allSuppliers.map((supplier) => {
                const recPieces = db.receives
                  .filter((r) => r.supplier === supplier)
                  .reduce((sum, r) => sum + Number(r.shapes || 0) * 2, 0);

                const soldPieces = db.sales
                  .filter((s) => s.supplier === supplier && s.pay !== 'storage')
                  .reduce((sum, s) => sum + Number(s.qty || 0), 0);

                const storedPieces = db.sales
                  .filter((s) => s.supplier === supplier && s.pay === 'storage')
                  .reduce((sum, s) => sum + Number(s.qty || 0), 0);

                const storedVal = db.sales
                  .filter((s) => s.supplier === supplier && s.pay === 'storage')
                  .reduce((sum, s) => sum + Number(s.storageValue ?? s.price ?? 0), 0);

                const remaining = recPieces - (soldPieces + storedPieces);
                const percent = recPieces > 0 ? Math.min(100, Math.round(((soldPieces + storedPieces) / recPieces) * 100)) : 0;

                const supCash = db.sales
                  .filter((s) => s.supplier === supplier)
                  .reduce((sum, s) => sum + getPaymentOf(s).cash, 0);

                const supTransfer = db.sales
                  .filter((s) => s.supplier === supplier)
                  .reduce((sum, s) => sum + getPaymentOf(s).transfer, 0);

                const supDebt = db.sales
                  .filter((s) => s.supplier === supplier)
                  .reduce((sum, s) => sum + getPaymentOf(s).debt, 0);

                const supTotal = db.sales
                  .filter((s) => s.supplier === supplier)
                  .reduce((sum, s) => sum + Number(s.price || 0), 0);

                return (
                  <tr key={supplier} className="hover:bg-stone-50 dark:hover:bg-stone-800/50 transition-colors">
                    <td className="p-2.5 font-bold text-stone-800 dark:text-stone-200">{supplier}</td>
                    <td className="p-2.5">{recPieces}</td>
                    <td className="p-2.5 text-blue-700 dark:text-blue-400 font-semibold">{soldPieces}</td>
                    <td className="p-2.5 text-amber-700 dark:text-amber-400 font-medium">{storedPieces}</td>
                    <td className="p-2.5 font-bold text-amber-800 dark:text-amber-300">{formatMoney(storedVal)}</td>
                    <td
                      className={`p-2.5 font-bold ${
                        remaining < 0
                          ? 'text-rose-600'
                          : remaining === 0
                          ? 'text-emerald-600'
                          : 'text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      {remaining}
                    </td>
                    <td className="p-2.5 w-32">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-mono font-bold">{percent}%</span>
                        <div className="flex-1 h-2 bg-stone-200 dark:bg-stone-700 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-emerald-600 rounded-full transition-all duration-300"
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="p-2.5 text-emerald-700 dark:text-emerald-400">{formatMoney(supCash)}</td>
                    <td className="p-2.5 text-sky-700 dark:text-sky-400">{formatMoney(supTransfer)}</td>
                    <td className="p-2.5 text-rose-700 dark:text-rose-400">{formatMoney(supDebt)}</td>
                    <td className="p-2.5 font-bold text-stone-900 dark:text-stone-100">{formatMoney(supTotal)}</td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="bg-stone-200/80 dark:bg-stone-800/90 font-black border-t-2 border-stone-300 dark:border-stone-700 text-stone-900 dark:text-stone-100">
                <td className="p-2.5">الإجمالي الكلي</td>
                <td className="p-2.5">{totalReceivedPieces}</td>
                <td className="p-2.5 text-blue-700 dark:text-blue-400">{totalRegularSoldPieces}</td>
                <td className="p-2.5 text-amber-700 dark:text-amber-400">{totalStoredPieces}</td>
                <td className="p-2.5 text-amber-800 dark:text-amber-300">{formatMoney(storageValTotal)}</td>
                <td className="p-2.5 text-stone-800 dark:text-stone-200">{totalStockPieces}</td>
                <td className="p-2.5">{totalProgressPercent}%</td>
                <td className="p-2.5 text-emerald-700 dark:text-emerald-400">{formatMoney(salesCash)}</td>
                <td className="p-2.5 text-sky-700 dark:text-sky-400">{formatMoney(salesTransfer)}</td>
                <td className="p-2.5 text-rose-700 dark:text-rose-400">{formatMoney(salesDebt)}</td>
                <td className="p-2.5 font-black text-emerald-900 dark:text-emerald-300">{formatMoney(totalSalesVal)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
};
