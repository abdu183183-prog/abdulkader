import React from 'react';
import { Printer, Download, X, Share2 } from 'lucide-react';
import { ShopSettings } from '../types/accounting';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  receiptData: {
    title: string;
    items: { label: string; value: string | number }[];
    notes?: string;
  } | null;
  settings: ShopSettings;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  isOpen,
  onClose,
  title = 'سند إيصال رسمي',
  receiptData,
  settings,
}) => {
  if (!isOpen || !receiptData) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-1.5 rounded-full bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 text-stone-500"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Printable slip area */}
        <div id="receiptPrintArea" className="text-center border border-dashed border-stone-300 dark:border-stone-700 rounded-2xl p-4 bg-stone-50 dark:bg-stone-800/40">
          <div className="w-12 h-12 mx-auto rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-xl mb-2">
            {settings.shopLogo ? (
              <img src={settings.shopLogo} alt="الشعار" className="w-full h-full object-contain rounded-full" />
            ) : (
              <span>🌿</span>
            )}
          </div>

          <h3 className="text-base sm:text-lg font-black text-emerald-900 dark:text-emerald-300">
            {settings.shopName || 'محلات عبدالقادر الشعيبي للقات'}
          </h3>
          <p className="text-xs text-stone-500 dark:text-stone-400 mb-3">{title}</p>

          <div className="border-t border-b border-stone-200 dark:border-stone-700 py-3 space-y-2 text-right text-xs sm:text-sm">
            {receiptData.items.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center py-0.5">
                <span className="text-stone-500 dark:text-stone-400 font-semibold">{item.label}:</span>
                <span className="font-bold text-stone-800 dark:text-stone-100">{item.value}</span>
              </div>
            ))}

            {receiptData.notes && (
              <div className="pt-2 text-xs text-stone-500 dark:text-stone-400 border-t border-dashed border-stone-200 dark:border-stone-700">
                <span className="font-semibold">ملاحظات:</span> {receiptData.notes}
              </div>
            )}
          </div>

          <div className="mt-3 text-[11px] text-stone-500 dark:text-stone-400">
            <div>{settings.address || 'عدن - المنصورة - الهنجر الجديد'}</div>
            <div>هاتف: {settings.phone || '0771501259'}</div>
            <div className="mt-1 font-mono text-[10px] text-stone-400">{new Date().toLocaleString('ar-YE')}</div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex gap-2 mt-5 no-print">
          <button
            onClick={handlePrint}
            className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm shadow transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة الإيصال</span>
          </button>

          <a
            href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
              [
                `🌿 *${settings.shopName || 'محلات عبدالقادر الشعيبي للقات'}* 🌿`,
                `🧾 *${title}*`,
                `────────────────────`,
                ...receiptData.items.map((i) => `🔹 *${i.label}:* ${i.value}`),
                receiptData.notes ? `📝 *ملاحظات:* ${receiptData.notes}` : '',
                `────────────────────`,
                settings.address ? `📍 *الموقع:* ${settings.address}` : '',
                settings.phone ? `📞 *الهاتف:* ${settings.phone}` : '',
              ]
                .filter(Boolean)
                .join('\n')
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-stone-950 font-bold text-xs sm:text-sm shadow transition-all cursor-pointer"
          >
            <Share2 className="w-4 h-4" />
            <span>📱 إرسال واتساب</span>
          </a>

          <button
            onClick={onClose}
            className="px-3 py-2.5 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 font-bold text-xs sm:text-sm transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
