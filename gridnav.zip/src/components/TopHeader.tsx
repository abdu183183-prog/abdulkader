import React from 'react';
import { Moon, Sun, MapPin, Phone, User, Landmark, DollarSign, Wallet } from 'lucide-react';
import { ShopSettings } from '../types/accounting';
import { formatMoney } from '../utils/initialData';

interface TopHeaderProps {
  settings: ShopSettings;
  isDark: boolean;
  onToggleTheme: () => void;
  metrics: {
    cash: number;
    transfer: number;
    totalLiquidity: number;
    totalSales: number;
    customerDebt: number;
  };
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  settings,
  isDark,
  onToggleTheme,
  metrics,
}) => {
  return (
    <header className="relative bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-950 text-white border-b-4 border-amber-500 shadow-md">
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4">
        {/* Top bar: Brand & Theme Toggle */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5 w-full md:w-auto justify-between md:justify-start">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-white/10 border-2 border-amber-400/80 flex items-center justify-center text-2xl shadow-inner overflow-hidden">
                {settings.headerImage ? (
                  <img
                    src={settings.headerImage}
                    alt="شعار المحل"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span>🌿</span>
                )}
              </div>

              <div>
                <h1 className="text-lg sm:text-2xl font-black tracking-wide text-white flex items-center gap-2">
                  {settings.shopName || 'محلات عبدالقادر الشعيبي للقات'}
                </h1>
                <p className="text-xs sm:text-sm text-emerald-100/80 font-medium">
                  نظام المبيعات والحسابات اليومية والتقسيم التناسبي للخرج والتخزينة
                </p>
              </div>
            </div>

            {/* Dark mode button for mobile */}
            <button
              onClick={onToggleTheme}
              className="md:hidden p-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-bold transition-colors flex items-center gap-1.5"
              title="تبديل الوضع"
            >
              {isDark ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-emerald-200" />}
            </button>
          </div>

          {/* Contact and user info */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3 w-full md:w-auto justify-end">
            <div className="flex items-center gap-2 bg-black/25 backdrop-blur-sm border border-white/15 px-3 py-1.5 rounded-xl text-xs">
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-semibold">{settings.address || 'عدن - المنصورة - الهنجر الجديد'}</span>
            </div>

            <div className="flex items-center gap-2 bg-black/25 backdrop-blur-sm border border-white/15 px-3 py-1.5 rounded-xl text-xs">
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              <span dir="ltr" className="font-bold">{settings.phone || '0771501259'}</span>
            </div>

            {settings.userName && (
              <div className="flex items-center gap-1.5 bg-black/25 backdrop-blur-sm border border-white/15 px-3 py-1.5 rounded-xl text-xs">
                <User className="w-3.5 h-3.5 text-amber-400" />
                <span>{settings.userName}</span>
              </div>
            )}

            {/* Dark mode toggle desktop */}
            <button
              onClick={onToggleTheme}
              className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-bold transition-colors cursor-pointer"
            >
              {isDark ? (
                <>
                  <Sun className="w-4 h-4 text-amber-300" />
                  <span>الوضع الفاتح</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-emerald-200" />
                  <span>الوضع الليلي</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Live fast status ticker bar */}
        <div className="mt-3 pt-3 border-t border-emerald-700/40 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="bg-black/20 rounded-xl p-2 flex items-center justify-between border border-emerald-600/30">
            <div className="flex items-center gap-1.5 text-emerald-200">
              <Wallet className="w-3.5 h-3.5 text-emerald-400" />
              <span>النقد بالصندوق:</span>
            </div>
            <b className="text-white font-extrabold">{formatMoney(metrics.cash)}</b>
          </div>

          <div className="bg-black/20 rounded-xl p-2 flex items-center justify-between border border-emerald-600/30">
            <div className="flex items-center gap-1.5 text-emerald-200">
              <Landmark className="w-3.5 h-3.5 text-sky-400" />
              <span>رصيد الحوالات:</span>
            </div>
            <b className="text-white font-extrabold">{formatMoney(metrics.transfer)}</b>
          </div>

          <div className="bg-black/20 rounded-xl p-2 flex items-center justify-between border border-emerald-600/30">
            <div className="flex items-center gap-1.5 text-emerald-200">
              <DollarSign className="w-3.5 h-3.5 text-amber-400" />
              <span>إجمالي السيولة:</span>
            </div>
            <b className="text-amber-300 font-extrabold">{formatMoney(metrics.totalLiquidity)}</b>
          </div>

          <div className="bg-black/20 rounded-xl p-2 flex items-center justify-between border border-emerald-600/30">
            <div className="flex items-center gap-1.5 text-rose-200">
              <span>ديون الزبائن:</span>
            </div>
            <b className="text-rose-300 font-extrabold">{formatMoney(metrics.customerDebt)}</b>
          </div>
        </div>
      </div>
    </header>
  );
};
