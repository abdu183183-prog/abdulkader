import React from 'react';
import { ArrowRight, Printer, Download, LayoutGrid, ChevronDown, ChevronUp } from 'lucide-react';
import { PageId, navItems } from './NavigationGrid';

interface PageHeaderBarProps {
  currentPageId: PageId;
  onBackToGrid: () => void;
  onSelectPage: (id: PageId) => void;
  onPrint?: () => void;
  onExport?: () => void;
  isGridOpen?: boolean;
  onToggleGrid?: () => void;
}

export const PageHeaderBar: React.FC<PageHeaderBarProps> = ({
  currentPageId,
  onBackToGrid,
  onSelectPage,
  onPrint,
  onExport,
  isGridOpen = false,
  onToggleGrid,
}) => {
  const currentItem = navItems.find((x) => x.id === currentPageId);

  return (
    <div className="sticky top-0 z-30 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md border border-stone-200 dark:border-stone-800 rounded-2xl shadow-sm px-3 sm:px-4 py-2.5 flex items-center justify-between gap-2.5">
      {/* Back button to grid */}
      <div className="flex items-center gap-2">
        <button
          onClick={onBackToGrid}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-stone-950 font-black text-xs sm:text-sm shadow-sm transition-all transform active:scale-95 cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
          <span>القائمة والشبكة (2 بكل صف)</span>
        </button>

        {/* Toggle 2-column grid button */}
        {onToggleGrid && (
          <button
            onClick={onToggleGrid}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
              isGridOpen
                ? 'bg-emerald-700 text-white border-emerald-600'
                : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 border-stone-300 dark:border-stone-700 hover:bg-stone-200'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>{isGridOpen ? 'إخفاء الشبكة' : 'عرض شبكة الأزرار'}</span>
            {isGridOpen ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        )}
      </div>

      {/* Current page title */}
      <div className="text-center truncate px-2">
        <h2 className="text-sm sm:text-base font-black text-emerald-900 dark:text-emerald-300 truncate">
          {currentItem?.title || 'الصفحة'}
        </h2>
      </div>

      {/* Action buttons */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {onPrint && (
          <button
            onClick={onPrint}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-200 text-xs font-bold border border-stone-300 dark:border-stone-700 transition-colors cursor-pointer"
            title="طباعة الصفحة"
          >
            <Printer className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span className="hidden sm:inline">طباعة</span>
          </button>
        )}

        {/* Quick jump select */}
        <select
          value={currentPageId}
          onChange={(e) => onSelectPage(e.target.value as PageId)}
          className="text-xs bg-stone-100 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl px-2 py-1.5 font-bold text-stone-700 dark:text-stone-200 focus:outline-none focus:ring-2 focus:ring-emerald-600 cursor-pointer max-w-[130px] sm:max-w-[170px]"
        >
          {navItems.map((item) => (
            <option key={item.id} value={item.id}>
              {item.title}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};
