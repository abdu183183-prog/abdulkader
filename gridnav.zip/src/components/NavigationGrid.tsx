import React, { useState } from 'react';
import {
  Home,
  PackagePlus,
  ShoppingCart,
  Receipt,
  RotateCcw,
  Tag,
  Boxes,
  Archive,
  ClipboardCheck,
  ArrowLeftRight,
  Truck,
  Users,
  FileSpreadsheet,
  FileText,
  BadgeDollarSign,
  CreditCard,
  Hourglass,
  Contact,
  ReceiptText,
  Calculator,
  TrendingUp,
  BarChart3,
  Calendar,
  Wallet,
  Landmark,
  Repeat,
  FileCheck2,
  Scale,
  ShieldCheck,
  LayoutDashboard,
  HardDrive,
  Database,
  Settings,
  Search,
  Sparkles,
} from 'lucide-react';

export type PageId =
  | 'home'
  | 'receive'
  | 'sale'
  | 'invoiceHistory'
  | 'returns'
  | 'discounts'
  | 'inventory'
  | 'storageReport'
  | 'stocktake'
  | 'stockMovement'
  | 'supplier'
  | 'customers'
  | 'supplierStatement'
  | 'customerStatement'
  | 'supplierPayments'
  | 'customerPayments'
  | 'customerDebtAging'
  | 'contacts45'
  | 'expense'
  | 'net'
  | 'profit46'
  | 'report'
  | 'periodReport'
  | 'accounts'
  | 'cashbox'
  | 'transfers'
  | 'openingBalances'
  | 'match46'
  | 'control47'
  | 'dashboard50'
  | 'backup'
  | 'backup48'
  | 'settings';

export interface NavButtonConfig {
  id: PageId;
  title: string;
  subtitle: string;
  icon: React.ElementType;
  category: 'ops' | 'stock' | 'contacts' | 'finance' | 'reports' | 'system';
  badge?: string;
  colorClass: string;
}

interface NavigationGridProps {
  activePage: PageId;
  onSelectPage: (pageId: PageId) => void;
  stats?: {
    receivedCount?: number;
    salesCount?: number;
    stockQty?: number;
    cashBalance?: number;
    debtTotal?: number;
    supplierDue?: number;
  };
}

export const navItems: NavButtonConfig[] = [
  // 1. العمليات والبيع
  {
    id: 'home',
    title: 'الرئيسية والملخص',
    subtitle: 'نظرة عامة والسيولة والصندوق',
    icon: Home,
    category: 'ops',
    badge: 'ملخص شامل',
    colorClass: 'from-emerald-700 to-emerald-900 border-emerald-600',
  },
  {
    id: 'receive',
    title: 'استلام القات',
    subtitle: 'تسجيل الشحنات بالأشكال والمرابط',
    icon: PackagePlus,
    category: 'ops',
    badge: 'يومي',
    colorClass: 'from-emerald-800 to-teal-950 border-emerald-600',
  },
  {
    id: 'sale',
    title: 'المبيعات والديون',
    subtitle: 'فواتير نقد، آجل، حوالة، وتخزينة',
    icon: ShoppingCart,
    category: 'ops',
    badge: 'دفع متعدد',
    colorClass: 'from-amber-600 to-amber-800 border-amber-500',
  },
  {
    id: 'invoiceHistory',
    title: 'سجل الفواتير',
    subtitle: 'الإيصالات المصدّرة والطباعة',
    icon: Receipt,
    category: 'ops',
    colorClass: 'from-sky-700 to-blue-900 border-sky-600',
  },
  {
    id: 'returns',
    title: 'المرتجعات',
    subtitle: 'سجل إرجاع القات والزبائن',
    icon: RotateCcw,
    category: 'ops',
    colorClass: 'from-rose-700 to-red-900 border-rose-600',
  },
  {
    id: 'discounts',
    title: 'الخصومات',
    subtitle: 'متابعة الخصم والتنزيل بالفواتير',
    icon: Tag,
    category: 'ops',
    colorClass: 'from-purple-700 to-indigo-950 border-purple-600',
  },

  // 2. المخزون والتخزين
  {
    id: 'inventory',
    title: 'المخزون والتكلفة',
    subtitle: 'المستلم والمباع والتكلفة التقديرية',
    icon: Boxes,
    category: 'stock',
    badge: 'رصيد حبات',
    colorClass: 'from-teal-700 to-cyan-900 border-teal-600',
  },
  {
    id: 'storageReport',
    title: 'تقرير التخزينات',
    subtitle: 'تخزينة القات وقيمتها حسب المورد',
    icon: Archive,
    category: 'stock',
    badge: 'تخزينة',
    colorClass: 'from-yellow-700 to-amber-900 border-yellow-600',
  },
  {
    id: 'stocktake',
    title: 'الجرد الفعلي',
    subtitle: 'جرد القات ومطابقة فرق المخزون',
    icon: ClipboardCheck,
    category: 'stock',
    colorClass: 'from-slate-700 to-slate-900 border-slate-600',
  },
  {
    id: 'stockMovement',
    title: 'حركة المخزون',
    subtitle: 'إضافة، صرف، تالف، ونقل',
    icon: ArrowLeftRight,
    category: 'stock',
    colorClass: 'from-indigo-700 to-indigo-950 border-indigo-600',
  },

  // 3. الموردون والعملاء
  {
    id: 'supplier',
    title: 'إدارة الموردين',
    subtitle: 'دليل موردي القات وأرقام الهواتف',
    icon: Truck,
    category: 'contacts',
    colorClass: 'from-emerald-700 to-stone-900 border-emerald-600',
  },
  {
    id: 'customers',
    title: 'إدارة العملاء',
    subtitle: 'دليل الزبائن وحساباتهم',
    icon: Users,
    category: 'contacts',
    colorClass: 'from-blue-700 to-blue-950 border-blue-600',
  },
  {
    id: 'supplierStatement',
    title: 'كشوفات الموردين',
    subtitle: 'كشف حساب التكلفة والنقل والمسدد',
    icon: FileSpreadsheet,
    category: 'contacts',
    colorClass: 'from-cyan-700 to-teal-950 border-cyan-600',
  },
  {
    id: 'customerStatement',
    title: 'كشوفات العملاء',
    subtitle: 'كشف ديون الزبائن والمسدد',
    icon: FileText,
    category: 'contacts',
    colorClass: 'from-sky-700 to-indigo-950 border-sky-600',
  },
  {
    id: 'supplierPayments',
    title: 'تسديدات الموردين',
    subtitle: 'دفعات نقدية وحوالات للموردين',
    icon: BadgeDollarSign,
    category: 'contacts',
    colorClass: 'from-emerald-800 to-green-950 border-emerald-600',
  },
  {
    id: 'customerPayments',
    title: 'تسديدات العملاء',
    subtitle: 'قبض مبالغ ديون الزبائن',
    icon: CreditCard,
    category: 'contacts',
    badge: 'سداد ديون',
    colorClass: 'from-amber-700 to-yellow-950 border-amber-600',
  },
  {
    id: 'customerDebtAging',
    title: 'أعمار ديون العملاء',
    subtitle: 'تصنيف الديون زمنيًا 30-60-90 يومًا',
    icon: Hourglass,
    category: 'contacts',
    badge: 'FIFO',
    colorClass: 'from-rose-800 to-pink-950 border-rose-600',
  },
  {
    id: 'contacts45',
    title: 'دليل الحسابات الشامل',
    subtitle: 'كشوف حساب وسداد تفصيلي V4.5',
    icon: Contact,
    category: 'contacts',
    colorClass: 'from-teal-800 to-stone-950 border-teal-600',
  },

  // 4. المصروفات والأرباح
  {
    id: 'expense',
    title: 'الخرج والمصاريف',
    subtitle: 'مصاريف عامة وخاصة بالموردين',
    icon: ReceiptText,
    category: 'reports',
    colorClass: 'from-red-700 to-stone-900 border-red-600',
  },
  {
    id: 'net',
    title: 'الصافي والتقسيم',
    subtitle: 'التقسيم التناسبي للخرج والتخزينة',
    icon: Calculator,
    category: 'reports',
    badge: 'تناسبي',
    colorClass: 'from-emerald-800 to-teal-900 border-emerald-500',
  },
  {
    id: 'profit46',
    title: 'الأرباح والخسائر',
    subtitle: 'المبيعات، التكلفة، وهامش الربح',
    icon: TrendingUp,
    category: 'reports',
    badge: 'أرباح',
    colorClass: 'from-green-700 to-emerald-950 border-green-500',
  },
  {
    id: 'report',
    title: 'التقارير الشاملة',
    subtitle: 'تصفية الحسابات حسب المورد والفترة',
    icon: BarChart3,
    category: 'reports',
    colorClass: 'from-amber-700 to-stone-900 border-amber-600',
  },
  {
    id: 'periodReport',
    title: 'التقارير الزمنية',
    subtitle: 'تقارير يومية وشهرية ورسوم بيانية',
    icon: Calendar,
    category: 'reports',
    colorClass: 'from-blue-700 to-indigo-900 border-blue-600',
  },

  // 5. الصندوق والمالية
  {
    id: 'accounts',
    title: 'الحسابات العامة',
    subtitle: 'مركز الحسابات والصندوق والديون',
    icon: Wallet,
    category: 'finance',
    badge: 'صندوق',
    colorClass: 'from-emerald-700 to-green-950 border-emerald-500',
  },
  {
    id: 'cashbox',
    title: 'ملخص الصندوق',
    subtitle: 'النقد، الحوالات، وإجمالي السيولة',
    icon: Landmark,
    category: 'finance',
    colorClass: 'from-teal-800 to-cyan-950 border-teal-600',
  },
  {
    id: 'transfers',
    title: 'حركة الحوالات',
    subtitle: 'إيداع وسحب وحوالات البنوك',
    icon: Repeat,
    category: 'finance',
    colorClass: 'from-sky-700 to-blue-900 border-sky-500',
  },
  {
    id: 'openingBalances',
    title: 'الأرصدة الافتتاحية',
    subtitle: 'تسجيل بداية رصيد النقد والحساب',
    icon: FileCheck2,
    category: 'finance',
    colorClass: 'from-stone-700 to-stone-900 border-stone-600',
  },
  {
    id: 'match46',
    title: 'المطابقة المالية',
    subtitle: 'مطابقة المبيعات والمخزون والدفع',
    icon: Scale,
    category: 'finance',
    colorClass: 'from-amber-800 to-yellow-950 border-amber-600',
  },

  // 6. الرقابة والإدارة
  {
    id: 'control47',
    title: 'الإقفال والرقابة',
    subtitle: 'إقفال اليومية وسجل التعديلات',
    icon: ShieldCheck,
    category: 'system',
    badge: 'أمان',
    colorClass: 'from-rose-800 to-stone-950 border-rose-600',
  },
  {
    id: 'dashboard50',
    title: 'لوحة التحكم',
    subtitle: 'مؤشرات اليوم، الرسم، وأعلى الموردين',
    icon: LayoutDashboard,
    category: 'system',
    badge: 'مباشر',
    colorClass: 'from-indigo-800 to-purple-950 border-indigo-600',
  },
  {
    id: 'backup',
    title: 'النسخ والسيولة',
    subtitle: 'تصدير واستعادة ملف قاعدة البيانات',
    icon: HardDrive,
    category: 'system',
    colorClass: 'from-stone-700 to-zinc-900 border-stone-500',
  },
  {
    id: 'backup48',
    title: 'إدارة النسخ V4.8',
    subtitle: 'النسخ المحلية وفحص حجم الذاكرة',
    icon: Database,
    category: 'system',
    colorClass: 'from-slate-700 to-zinc-950 border-slate-600',
  },
  {
    id: 'settings',
    title: 'إعدادات المحل',
    subtitle: 'اسم المحل، الشعار، وبيانات المطور',
    icon: Settings,
    category: 'system',
    colorClass: 'from-emerald-900 to-stone-900 border-emerald-700',
  },
];

export const NavigationGrid: React.FC<NavigationGridProps> = ({
  activePage,
  onSelectPage,
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = [
    { id: 'all', label: '🌟 كل الأقسام' },
    { id: 'ops', label: '🛒 العمليات والمبيعات' },
    { id: 'stock', label: '📦 المخزون والتخزين' },
    { id: 'contacts', label: '👥 الموردين والعملاء' },
    { id: 'reports', label: '📈 المصاريف والأرباح' },
    { id: 'finance', label: '💰 الصندوق والمالية' },
    { id: 'system', label: '🔐 الرقابة والإعدادات' },
  ];

  const filteredItems = navItems.filter((item) => {
    const matchesCategory = filterCategory === 'all' || item.category === filterCategory;
    const matchesSearch =
      !searchQuery ||
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.subtitle.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="w-full bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3 sm:p-5 shadow-sm mb-6">
      {/* Category Pills & Search */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setFilterCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-150 ${
                filterCategory === cat.id
                  ? 'bg-emerald-700 text-white shadow-md shadow-emerald-900/20'
                  : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="relative min-w-[200px]">
          <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            placeholder="بحث في أزرار التنقل..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-3 pr-9 py-1.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-xs sm:text-sm text-stone-800 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-600"
          />
        </div>
      </div>

      {/* Notice header explaining 2 buttons per row */}
      <div className="flex items-center justify-between text-xs text-stone-700 dark:text-stone-200 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 rounded-xl px-3 py-2 mb-3.5">
        <div className="flex items-center gap-1.5 font-bold text-emerald-800 dark:text-emerald-300">
          <Sparkles className="w-4 h-4 text-amber-500" />
          <span>شبكة أزرار التنقل الرئيسية — صفين (2 أزرار بكل صف)</span>
        </div>
        <span className="font-semibold">{filteredItems.length} زر متاح</span>
      </div>

      {/* THE 2-BUTTONS-PER-ROW GRID (بكل صف 2 أزرار) */}
      <div className="grid grid-cols-2 gap-2.5 sm:gap-3.5">
        {filteredItems.map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onSelectPage(item.id)}
              className={`group relative text-right flex flex-col justify-between p-3 sm:p-4 rounded-xl sm:rounded-2xl border transition-all duration-200 min-h-[92px] sm:min-h-[110px] select-none ${
                isActive
                  ? 'bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 text-stone-950 border-amber-300 shadow-lg shadow-amber-600/25 ring-2 ring-amber-400 -translate-y-0.5'
                  : 'bg-gradient-to-br from-emerald-800 to-emerald-950 text-white border-emerald-700/70 hover:border-amber-400 hover:shadow-md hover:-translate-y-0.5'
              }`}
            >
              {/* Top row: Icon and Optional Badge */}
              <div className="flex items-center justify-between w-full mb-1">
                <div
                  className={`w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl flex items-center justify-center transition-colors ${
                    isActive
                      ? 'bg-stone-950 text-amber-400 shadow-inner'
                      : 'bg-white/15 text-amber-300 group-hover:bg-white/25'
                  }`}
                >
                  <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>

                {item.badge && (
                  <span
                    className={`text-[10px] sm:text-xs font-black px-2 py-0.5 rounded-full ${
                      isActive
                        ? 'bg-stone-950/25 text-stone-950'
                        : 'bg-amber-400/20 text-amber-300 border border-amber-400/30'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </div>

              {/* Title & Subtitle */}
              <div className="w-full">
                <div
                  className={`font-black text-xs sm:text-base leading-tight truncate ${
                    isActive ? 'text-stone-950 font-extrabold' : 'text-white group-hover:text-amber-200'
                  }`}
                >
                  {item.title}
                </div>
                <div
                  className={`text-[10px] sm:text-xs mt-0.5 line-clamp-1 leading-snug ${
                    isActive ? 'text-stone-800 font-medium' : 'text-emerald-200/70 group-hover:text-emerald-100'
                  }`}
                >
                  {item.subtitle}
                </div>
              </div>

              {/* Active Indicator Bar */}
              {isActive && (
                <div className="absolute -top-1 right-1/2 translate-x-1/2 w-8 h-1.5 bg-stone-900 rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
