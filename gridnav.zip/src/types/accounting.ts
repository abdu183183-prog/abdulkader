export interface PaymentBreakdown {
  cash: number;
  transfer: number;
  debt: number;
}

export interface ReceiveItem {
  id: number;
  date: string;
  day?: string;
  supplier: string;
  phone?: string;
  type?: string;
  shapes: number;
  bundles?: number;
  time?: string;
  cost?: number;
  transport?: number;
  commission?: number;
  note?: string;
}

export interface SaleItem {
  id: number;
  date: string;
  supplier: string;
  qty: number;
  price: number;
  pay: 'cash' | 'transfer' | 'debt' | 'storage' | 'mixed';
  payments?: PaymentBreakdown;
  storageValue?: number;
  customer?: string;
  customerPhone?: string;
  note?: string;
}

export interface ExpenseItem {
  id: number;
  date: string;
  type: 'general' | 'specific';
  supplier?: string;
  item: string;
  amount: number;
  note?: string;
}

export interface DebtPayment {
  id: number;
  date: string;
  customer: string;
  amount: number;
  method: 'cash' | 'transfer';
  note?: string;
}

export interface SupplierPayment {
  id: number;
  date: string;
  supplier: string;
  amount: number;
  method: 'cash' | 'transfer';
  note?: string;
}

export interface CashTransaction {
  id: number;
  date: string;
  type: 'opening' | 'deposit' | 'withdrawal' | 'transfer_to_cash';
  amount: number;
  method: 'cash' | 'transfer';
  note?: string;
}

export interface Customer {
  id: number;
  name: string;
  phone?: string;
  address?: string;
  note?: string;
}

export interface SupplierDetail {
  id: number;
  name: string;
  phone?: string;
  address?: string;
  note?: string;
}

export interface ReturnItem {
  id: number;
  date: string;
  customer: string;
  supplier: string;
  qty: number;
  amount: number;
  note?: string;
}

export interface DiscountItem {
  id: number;
  date: string;
  customer: string;
  invoice?: string;
  amount: number;
  note?: string;
}

export interface StocktakeItem {
  id: number;
  date: string;
  systemQty: number;
  countedQty: number;
  difference: number;
  note?: string;
}

export interface StockMovementItem {
  id: number;
  date: string;
  type: 'addition' | 'issue' | 'damage' | 'transfer';
  qty: number;
  item: string;
  note?: string;
}

export interface ClosureItem {
  id: number;
  date: string;
  closed: boolean;
  note?: string;
  closedAt?: string;
  openedAt?: string;
  snapshot?: {
    sales: number;
    expenses: number;
    profit: number;
    cash: number;
    transfer: number;
  };
}

export interface AuditLogItem {
  id: number;
  date: string;
  action: string;
  ref?: any;
  before?: any;
  after?: any;
}

export interface ShopSettings {
  userName: string;
  shopName: string;
  address: string;
  phone: string;
  headerImage?: string;
  shopLogo?: string;
  developerName?: string;
  developerPhone?: string;
  developerWhatsApp?: string;
  developerEmail?: string;
  developerFacebook?: string;
  developerYoutube?: string;
  developerWebsite?: string;
}

export interface ExportedInvoice {
  id: number;
  kind: string;
  isStorage?: boolean;
  createdAt: string;
  title: string;
  html: string;
  shopName?: string;
  fileUri?: string;
}

export interface AppDatabase {
  suppliers: string[];
  receives: ReceiveItem[];
  sales: SaleItem[];
  expenses: ExpenseItem[];
  supplierDetails: SupplierDetail[];
  customers: Customer[];
  supplierPayments: SupplierPayment[];
  debtPayments: DebtPayment[];
  cashTransactions: CashTransaction[];
  auditLog: AuditLogItem[];
  returns: ReturnItem[];
  discounts: DiscountItem[];
  stocktakes: StocktakeItem[];
  stockMovements: StockMovementItem[];
  closures?: ClosureItem[];
  exportedInvoices: ExportedInvoice[];
  settings: ShopSettings;
}
