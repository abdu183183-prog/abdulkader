import test from 'node:test';
import assert from 'node:assert/strict';
import {
  cleanPhoneNumber,
  getWhatsAppUrl,
  buildSupplierReceiveMessage,
  buildCustomerSaleMessage,
} from './whatsapp';
import { formatMoney } from './initialData';

test('cleanPhoneNumber formats local and international numbers correctly', () => {
  // Local 077... -> 96777...
  assert.equal(cleanPhoneNumber('0771501259'), '967771501259');
  // Local 77... -> 96777...
  assert.equal(cleanPhoneNumber('771501259'), '967771501259');
  // Phone with spaces, dashes or plus
  assert.equal(cleanPhoneNumber('+967 77-150-1259'), '967771501259');
  // Phone with leading 00
  assert.equal(cleanPhoneNumber('00967771501259'), '967771501259');
  // Empty or undefined
  assert.equal(cleanPhoneNumber(''), '');
  assert.equal(cleanPhoneNumber(undefined), '');
});

test('getWhatsAppUrl generates valid link with and without phone', () => {
  const urlWithPhone = getWhatsAppUrl('0771501259', 'مرحبا');
  assert.match(urlWithPhone, /^https:\/\/wa\.me\/967771501259\?text=%D9%85%D8%B1%D8%AD%D8%A8%D8%A7$/);

  const urlWithoutPhone = getWhatsAppUrl('', 'فاتورة');
  assert.match(urlWithoutPhone, /^https:\/\/api\.whatsapp\.com\/send\?text=/);
});

test('buildSupplierReceiveMessage formats shipment receipt nicely', () => {
  const msg = buildSupplierReceiveMessage(
    {
      id: 1,
      date: '2026-10-26',
      day: 'الإثنين',
      supplier: 'قاسم الضالعي',
      type: 'ضالعي ممتاز',
      shapes: 10,
      bundles: 20,
      cost: 150000,
      transport: 10000,
      commission: 5000,
      note: 'طازج',
    },
    { shopName: 'محلات الشعيبي', phone: '0771501259' }
  );

  assert.ok(msg.includes('محلات الشعيبي'));
  assert.ok(msg.includes('قاسم الضالعي'));
  assert.ok(msg.includes('10 شكل (20 حبة)'));
  assert.ok(msg.includes('20 مربط'));
  assert.ok(msg.includes(formatMoney(165000))); // total cost = 150000 + 10000 + 5000
});

test('buildCustomerSaleMessage formats customer invoice with debt balance', () => {
  const msg = buildCustomerSaleMessage(
    {
      id: 10,
      date: '2026-10-26',
      supplier: 'قاسم الضالعي',
      qty: 3,
      price: 36000,
      pay: 'mixed',
      payments: { cash: 16000, transfer: 0, debt: 20000 },
      customer: 'أحمد صالح',
      note: 'دفعة أولى',
    },
    {
      settings: { shopName: 'محلات الشعيبي', phone: '0771501259' },
      customerTotalDebt: 45000,
    }
  );

  assert.ok(msg.includes('أحمد صالح'));
  assert.ok(msg.includes(formatMoney(36000)));
  assert.ok(msg.includes(formatMoney(20000))); // debt part
  assert.ok(msg.includes(formatMoney(45000))); // total debt remaining
});

