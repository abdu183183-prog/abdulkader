/**
 * Pure accounting calculation logic for Qat Store System
 */

export interface ReceiveItem {
  id: number;
  date: string;
  day?: string;
  supplier: string;
  phone?: string;
  type?: string;
  shapes: number;
  bundles?: number;
  time?: string;
  cost?: number;
  transport?: number;
  commission?: number;
  note?: string;
}

export interface PaymentBreakdown {
  cash: number;
  transfer: number;
  debt: number;
}

export interface SaleItem {
  id: number;
  date: string;
  supplier: string;
  qty: number;
  price: number;
  pay: 'cash' | 'transfer' | 'debt' | 'storage' | 'mixed';
  payments?: PaymentBreakdown;
  storageValue?: number;
  customer?: string;
  note?: string;
}

export interface ExpenseItem {
  id: number;
  date: string;
  type: 'general' | 'specific';
  supplier?: string;
  item: string;
  amount: number;
  note?: string;
}

export interface DebtPayment {
  id: number;
  date: string;
  customer: string;
  amount: number;
  method: 'cash' | 'transfer';
  note?: string;
}

export interface SupplierPayment {
  id: number;
  date: string;
  supplier: string;
  amount: number;
  method: 'cash' | 'transfer';
  note?: string;
}

export interface CashTransaction {
  id: number;
  date: string;
  type: 'opening' | 'deposit' | 'withdrawal' | 'transfer_to_cash';
  amount: number;
  method: 'cash' | 'transfer';
  note?: string;
}

/**
 * Format quantity in Arabic text (shapes and pieces)
 */
export function formatQuantityText(q: number): string {
  if (!q || q <= 0) return '0 حبة';
  const shapes = Math.floor(q / 2);
  const rem = q % 2;

  let sTxt = '';
  if (shapes === 1) sTxt = 'شكل';
  else if (shapes === 2) sTxt = 'شكلين';
  else if (shapes >= 3 && shapes <= 10) sTxt = `${shapes} أشكال`;
  else if (shapes > 10) sTxt = `${shapes} شكل`;

  const rMap: Record<number, string> = {
    0.25: 'ربع',
    0.5: 'نص',
    0.75: 'حبة إلا ربع',
    1: 'حبة',
    1.25: 'حبة وربع',
    1.5: 'حبة ونص',
    1.75: 'حبة و3 أرباع',
  };
  const rTxt = rMap[rem] || (rem > 0 ? `${rem} حبة` : '');

  if (sTxt && rTxt) return `${sTxt} و${rTxt}`;
  return sTxt || rTxt;
}

/**
 * Extract payment breakdown
 */
export function getPaymentOf(x: Partial<SaleItem>): PaymentBreakdown {
  const price = Number(x.price || 0);
  if (x.pay === 'storage') {
    return { cash: 0, transfer: 0, debt: 0 };
  }
  if (x.payments && typeof x.payments === 'object') {
    return {
      cash: Number(x.payments.cash || 0),
      transfer: Number(x.payments.transfer || 0),
      debt: Number(x.payments.debt || 0),
    };
  }
  if (x.pay === 'cash') return { cash: price, transfer: 0, debt: 0 };
  if (x.pay === 'transfer') return { cash: 0, transfer: price, debt: 0 };
  if (x.pay === 'debt') return { cash: 0, transfer: 0, debt: price };
  return { cash: 0, transfer: 0, debt: 0 };
}

/**
 * Calculate Proportional Distribution of General Expenses & Storage
 */
export function calculateProportionalShare(
  totalSoldQty: number,
  supplierSoldQty: number,
  generalExpensesPure: number,
  totalStorageValue: number
): number {
  if (totalSoldQty <= 0 || supplierSoldQty <= 0) return 0;
  const generalExpenseTotal = generalExpensesPure + totalStorageValue;
  return (generalExpenseTotal * supplierSoldQty) / totalSoldQty;
}

/**
 * Calculate Customer Debt
 */
export function calculateCustomerDebt(
  customerName: string,
  sales: SaleItem[],
  debtPayments: DebtPayment[]
): number {
  const target = customerName.trim();
  if (!target) return 0;
  const totalDebt = sales
    .filter((s) => (s.customer || '').trim() === target)
    .reduce((sum, s) => sum + getPaymentOf(s).debt, 0);
  const totalPaid = debtPayments
    .filter((p) => (p.customer || '').trim() === target)
    .reduce((sum, p) => sum + Number(p.amount || 0), 0);
  return Math.max(0, totalDebt - totalPaid);
}

/**
 * Calculate Cash & Liquidity Balances
 */
export function calculateCashBalances(
  sales: SaleItem[],
  expenses: ExpenseItem[],
  debtPayments: DebtPayment[],
  supplierPayments: SupplierPayment[],
  cashTransactions: CashTransaction[]
) {
  const salesCash = sales.reduce((a, x) => a + getPaymentOf(x).cash, 0);
  const salesTransfer = sales.reduce((a, x) => a + getPaymentOf(x).transfer, 0);
  const debtCash = debtPayments
    .filter((x) => x.method === 'cash')
    .reduce((a, x) => a + Number(x.amount || 0), 0);
  const debtTransfer = debtPayments
    .filter((x) => x.method === 'transfer')
    .reduce((a, x) => a + Number(x.amount || 0), 0);

  const regularCashMoves = cashTransactions
    .filter((x) => x.method === 'cash' && x.type !== 'transfer_to_cash')
    .reduce((a, x) => a + (x.type === 'withdrawal' ? -Number(x.amount || 0) : Number(x.amount || 0)), 0);

  const regularTransferMoves = cashTransactions
    .filter((x) => x.method === 'transfer' && x.type !== 'transfer_to_cash')
    .reduce((a, x) => a + (x.type === 'withdrawal' ? -Number(x.amount || 0) : Number(x.amount || 0)), 0);

  const internalTransfers = cashTransactions
    .filter((x) => x.type === 'transfer_to_cash')
    .reduce((a, x) => a + Number(x.amount || 0), 0);

  const expTotal = expenses.reduce((a, x) => a + Number(x.amount || 0), 0);
  const supplierCash = supplierPayments
    .filter((x) => x.method === 'cash')
    .reduce((a, x) => a + Number(x.amount || 0), 0);
  const supplierTransfer = supplierPayments
    .filter((x) => x.method === 'transfer')
    .reduce((a, x) => a + Number(x.amount || 0), 0);

  const cash = salesCash + debtCash + regularCashMoves + internalTransfers - expTotal - supplierCash;
  const transfer = salesTransfer + debtTransfer + regularTransferMoves - internalTransfers - supplierTransfer;
  const totalLiquidity = cash + transfer;
  const collected = salesCash + salesTransfer + debtCash + debtTransfer;

  return {
    cash,
    transfer,
    totalLiquidity,
    collected,
    salesCash,
    salesTransfer,
    internalTransfers,
  };
}

/**
 * Customer debt aging FIFO breakdown into buckets: [0-30, 31-60, 61-90, >90]
 */
export function calculateDebtAging(
  customerName: string,
  sales: SaleItem[],
  debtPayments: DebtPayment[],
  referenceDateStr: string
): [number, number, number, number] {
  const target = customerName.trim();
  const invoices = sales
    .filter((s) => (s.customer || '').trim() === target)
    .map((s) => ({
      date: s.date,
      amount: getPaymentOf(s).debt,
      remaining: getPaymentOf(s).debt,
    }))
    .filter((x) => x.amount > 0)
    .sort((a, b) => a.date.localeCompare(b.date));

  let paid = debtPayments
    .filter((p) => (p.customer || '').trim() === target)
    .reduce((sum, p) => sum + Number(p.amount || 0), 0);

  for (const inv of invoices) {
    const used = Math.min(inv.remaining, paid);
    inv.remaining -= used;
    paid -= used;
    if (paid <= 0) break;
  }

  const refDate = new Date(referenceDateStr + 'T00:00:00');
  const bins: [number, number, number, number] = [0, 0, 0, 0];

  for (const inv of invoices) {
    if (inv.remaining <= 0) continue;
    const dt = new Date(inv.date + 'T00:00:00');
    const diffDays = Math.max(0, Math.floor((refDate.getTime() - dt.getTime()) / (1000 * 60 * 60 * 24)));
    if (diffDays <= 30) bins[0] += inv.remaining;
    else if (diffDays <= 60) bins[1] += inv.remaining;
    else if (diffDays <= 90) bins[2] += inv.remaining;
    else bins[3] += inv.remaining;
  }

  return bins;
}
