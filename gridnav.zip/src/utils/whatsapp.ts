/**
 * WhatsApp message generation and phone formatting utilities for Qat Accounting System
 */

import { ReceiveItem, SaleItem, ShopSettings } from '../types/accounting';
import { formatMoney } from './initialData';
import { formatQuantityText, getPaymentOf } from './accountingLogic';

/**
 * Clean and format phone number for WhatsApp link
 * Handles Yemeni numbers (starting with 7, 07, or with 967) and international numbers
 */
export function cleanPhoneNumber(phone?: string, defaultCountryCode = '967'): string {
  if (!phone) return '';
  // Remove non-digit characters
  let digits = phone.replace(/\D/g, '');
  if (!digits) return '';

  // Remove leading 00
  if (digits.startsWith('00')) {
    digits = digits.slice(2);
  }

  // If local Yemeni 10-digit number starting with 07 (e.g. 0771501259)
  if (digits.length === 10 && digits.startsWith('07')) {
    return defaultCountryCode + digits.slice(1);
  }

  // If local Yemeni 9-digit number starting with 7 (e.g. 771501259)
  if (digits.length === 9 && digits.startsWith('7')) {
    return defaultCountryCode + digits;
  }

  // If already starts with 967 and has 12 digits
  if (digits.startsWith('967') && digits.length >= 11) {
    return digits;
  }

  return digits;
}

/**
 * Generate WhatsApp URL
 * If clean phone is provided, opens chat with that number: https://wa.me/PHONE?text=...
 * If phone is empty, opens WhatsApp share selector: https://api.whatsapp.com/send?text=...
 */
export function getWhatsAppUrl(phone?: string, message?: string): string {
  const clean = cleanPhoneNumber(phone);
  const encodedText = encodeURIComponent(message || '');
  if (clean) {
    return `https://wa.me/${clean}?text=${encodedText}`;
  }
  return `https://api.whatsapp.com/send?text=${encodedText}`;
}

/**
 * Build WhatsApp message for supplier upon receiving shipment
 */
export function buildSupplierReceiveMessage(
  receive: ReceiveItem,
  settings?: Partial<ShopSettings>
): string {
  const shopName = settings?.shopName || 'محلات عبدالقادر الشعيبي للقات';
  const totalCost = Number(receive.cost || 0) + Number(receive.transport || 0) + Number(receive.commission || 0);
  const pieces = Number(receive.shapes || 0) * 2;

  const lines = [
    `🌿 *${shopName}* 🌿`,
    `📦 *إشعار استلام شحنة قات*`,
    `────────────────────`,
    `👤 *المورد:* ${receive.supplier}`,
    `📅 *التاريخ:* ${receive.date} (${receive.day || ''})`,
    receive.time ? `⏰ *الوقت:* ${receive.time}` : '',
    receive.type ? `🍃 *نوع القات:* ${receive.type}` : '',
    `🔢 *الكمية المستلمة:* ${receive.shapes} شكل (${pieces} حبة)`,
    receive.bundles ? `🎗️ *عدد المرابط:* ${receive.bundles} مربط` : '',
    receive.cost ? `💵 *تكلفة الشراء:* ${formatMoney(receive.cost)}` : '',
    receive.transport ? `🚚 *أجرة النقل:* ${formatMoney(receive.transport)}` : '',
    receive.commission ? `🏷️ *عمولة المورد:* ${formatMoney(receive.commission)}` : '',
    totalCost > 0 ? `💰 *إجمالي التكلفة:* ${formatMoney(totalCost)}` : '',
    receive.note ? `📝 *ملاحظات:* ${receive.note}` : '',
    `────────────────────`,
    settings?.address ? `📍 *الموقع:* ${settings.address}` : '',
    settings?.phone ? `📞 *هاتف:* ${settings.phone}` : '',
    `نسعد بتعاملنا الدائم معكم، جزاكم الله خيراً 🙏`,
  ];

  return lines.filter(Boolean).join('\n');
}

/**
 * Build WhatsApp message for customer upon sale
 */
export function buildCustomerSaleMessage(
  sale: SaleItem,
  options?: {
    settings?: Partial<ShopSettings>;
    customerTotalDebt?: number;
  }
): string {
  const settings = options?.settings;
  const shopName = settings?.shopName || 'محلات عبدالقادر الشعيبي للقات';
  const p = getPaymentOf(sale);
  const qtyDesc = formatQuantityText(sale.qty);

  let payLabel = 'نقد';
  if (sale.pay === 'transfer') payLabel = 'حوالة بنكية';
  else if (sale.pay === 'debt') payLabel = 'آجل (دين مسجل)';
  else if (sale.pay === 'storage') payLabel = 'تخزينة';
  else if (sale.pay === 'mixed') {
    const parts = [];
    if (p.cash > 0) parts.push(`نقد: ${formatMoney(p.cash)}`);
    if (p.transfer > 0) parts.push(`حوالة: ${formatMoney(p.transfer)}`);
    if (p.debt > 0) parts.push(`آجل: ${formatMoney(p.debt)}`);
    payLabel = `مختلط (${parts.join(' + ')})`;
  }

  const lines = [
    `🌿 *${shopName}* 🌿`,
    `🧾 *فاتورة مبيعات قات*`,
    `────────────────────`,
    sale.customer ? `👤 *العميل:* ${sale.customer}` : `👤 *العميل:* زبون كرام`,
    `📅 *التاريخ:* ${sale.date}`,
    sale.supplier ? `🍃 *الصنف:* قات (${sale.supplier})` : '',
    `🔢 *الكمية:* ${sale.qty} حبة (${qtyDesc})`,
    `💰 *المبلغ الإجمالي:* ${formatMoney(sale.price)}`,
    `💳 *طريقة الدفع:* ${payLabel}`,
    p.debt > 0 ? `📕 *المبلغ المقيّد آجل (دين):* ${formatMoney(p.debt)}` : '',
    options?.customerTotalDebt !== undefined && options.customerTotalDebt > 0
      ? `📊 *إجمالي الرصيد المتبقي على حسابكم:* ${formatMoney(options.customerTotalDebt)}`
      : '',
    sale.note ? `📝 *ملاحظات:* ${sale.note}` : '',
    `────────────────────`,
    settings?.address ? `📍 *الموقع:* ${settings.address}` : '',
    settings?.phone ? `📞 *للتواصل والاستفسار:* ${settings.phone}` : '',
    `شكراً لتعاملكم معنا ونسعد بزيارتكم دائماً 🌿`,
  ];

  return lines.filter(Boolean).join('\n');
}
