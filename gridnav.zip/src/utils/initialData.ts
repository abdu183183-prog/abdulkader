import { AppDatabase } from '../types/accounting';

export const STORAGE_KEY = 'qat_v3_data';

const today = new Date().toISOString().slice(0, 10);

export const defaultSettings = {
  userName: 'أبو أحمد',
  shopName: 'محلات عبدالقادر الشعيبي للقات',
  address: 'عدن - المنصورة - الهنجر الجديد',
  phone: '0771501259',
  headerImage: '',
  shopLogo: '',
  developerName: 'فريق التطوير المحاسبي',
  developerPhone: '0771501259',
  developerWhatsApp: '967771501259',
  developerEmail: 'support@alshuaibi-qat.com',
  developerFacebook: '',
  developerYoutube: '',
  developerWebsite: '',
};

export const sampleSeedDatabase: AppDatabase = {
  suppliers: ['قاسم الضالعي', 'ناصر الشعيبي', 'صالح الصعدي'],
  supplierDetails: [
    { id: 1, name: 'قاسم الضالعي', phone: '0771122334', address: 'الضالع - جحاف' },
    { id: 2, name: 'ناصر الشعيبي', phone: '0775566778', address: 'الشعيب - العوابل' },
    { id: 3, name: 'صالح الصعدي', phone: '0779988776', address: 'صعدة - ساقين' },
  ],
  customers: [
    { id: 1, name: 'محمد صالح', phone: '0770112233', address: 'المنصورة' },
    { id: 2, name: 'أحمد قاسم', phone: '0773344556', address: 'الشيخ عثمان' },
    { id: 3, name: 'عمار عبدالكريم', phone: '0778899001', address: 'المعلا' },
  ],
  receives: [
    {
      id: 101,
      date: today,
      day: 'اليوم',
      supplier: 'قاسم الضالعي',
      phone: '0771122334',
      type: 'ضالعي ممتاز',
      shapes: 15, // 30 pieces
      bundles: 30,
      cost: 180000,
      transport: 15000,
      commission: 5000,
      note: 'شحنة صباحية طازجة',
    },
    {
      id: 102,
      date: today,
      day: 'اليوم',
      supplier: 'ناصر الشعيبي',
      phone: '0775566778',
      type: 'شعيبي قطاف أول',
      shapes: 12, // 24 pieces
      bundles: 24,
      cost: 160000,
      transport: 12000,
      commission: 4000,
      note: 'مربوط وجاهز',
    },
    {
      id: 103,
      date: today,
      day: 'اليوم',
      supplier: 'صالح الصعدي',
      phone: '0779988776',
      type: 'صعدي بيضاء',
      shapes: 10, // 20 pieces
      bundles: 20,
      cost: 130000,
      transport: 10000,
      commission: 3000,
      note: 'درجة أولى',
    },
  ],
  sales: [
    {
      id: 201,
      date: today,
      supplier: 'قاسم الضالعي',
      qty: 6,
      price: 60000,
      pay: 'cash',
      payments: { cash: 60000, transfer: 0, debt: 0 },
      customer: 'زبون نقدي',
      note: 'مبيعات نقدية صباحية',
    },
    {
      id: 202,
      date: today,
      supplier: 'قاسم الضالعي',
      qty: 4,
      price: 44000,
      pay: 'debt',
      payments: { cash: 0, transfer: 0, debt: 44000 },
      customer: 'محمد صالح',
      note: 'دين مسجل',
    },
    {
      id: 203,
      date: today,
      supplier: 'ناصر الشعيبي',
      qty: 5,
      price: 55000,
      pay: 'mixed',
      payments: { cash: 25000, transfer: 20000, debt: 10000 },
      customer: 'أحمد قاسم',
      note: 'دفع مختلط نقدي وحوالة ودين',
    },
    {
      id: 204,
      date: today,
      supplier: 'ناصر الشعيبي',
      qty: 2,
      price: 22000,
      pay: 'storage',
      storageValue: 22000,
      customer: 'تخزينة المحل والعاملين',
      note: 'تخزينة اليوم',
    },
    {
      id: 205,
      date: today,
      supplier: 'صالح الصعدي',
      qty: 4,
      price: 40000,
      pay: 'transfer',
      payments: { cash: 0, transfer: 40000, debt: 0 },
      customer: 'عمار عبدالكريم',
      note: 'حوالة عبر بنك القطيبي',
    },
  ],
  expenses: [
    {
      id: 301,
      date: today,
      type: 'general',
      item: 'غداء وعصير للعاملين',
      amount: 14000,
      note: 'مصروف عام يوزع تناسبياً',
    },
    {
      id: 302,
      date: today,
      type: 'general',
      item: 'إيجار كهرباء وثلج',
      amount: 8000,
      note: 'مصروف عام',
    },
    {
      id: 303,
      date: today,
      type: 'specific',
      supplier: 'قاسم الضالعي',
      item: 'أكياس خاصة وتغليف',
      amount: 3000,
      note: 'خاص بالمورد قاسم',
    },
  ],
  supplierPayments: [
    {
      id: 401,
      date: today,
      supplier: 'قاسم الضالعي',
      amount: 50000,
      method: 'cash',
      note: 'دفعة نقدية تحت الحساب',
    },
  ],
  debtPayments: [
    {
      id: 501,
      date: today,
      customer: 'محمد صالح',
      amount: 14000,
      method: 'cash',
      note: 'سداد جزئي من الدين',
    },
  ],
  cashTransactions: [
    {
      id: 601,
      date: today,
      type: 'opening',
      amount: 50000,
      method: 'cash',
      note: 'رصيد افتتاحي لصندوق المحل',
    },
    {
      id: 602,
      date: today,
      type: 'opening',
      amount: 100000,
      method: 'transfer',
      note: 'رصيد افتتاحي في الحساب البنكي / الحوالات',
    },
  ],
  auditLog: [
    {
      id: 701,
      date: new Date().toISOString(),
      action: 'بدء تشغيل النظام المحاسبي',
      ref: 'النظام',
    },
  ],
  returns: [],
  discounts: [],
  stocktakes: [],
  stockMovements: [],
  closures: [],
  exportedInvoices: [],
  settings: defaultSettings,
};

export function loadDatabase(): AppDatabase {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return sampleSeedDatabase;
    const parsed = JSON.parse(raw);
    return {
      suppliers: Array.isArray(parsed.suppliers) ? parsed.suppliers : sampleSeedDatabase.suppliers,
      supplierDetails: Array.isArray(parsed.supplierDetails) ? parsed.supplierDetails : sampleSeedDatabase.supplierDetails,
      customers: Array.isArray(parsed.customers) ? parsed.customers : sampleSeedDatabase.customers,
      receives: Array.isArray(parsed.receives) ? parsed.receives : sampleSeedDatabase.receives,
      sales: Array.isArray(parsed.sales) ? parsed.sales : sampleSeedDatabase.sales,
      expenses: Array.isArray(parsed.expenses) ? parsed.expenses : sampleSeedDatabase.expenses,
      supplierPayments: Array.isArray(parsed.supplierPayments) ? parsed.supplierPayments : sampleSeedDatabase.supplierPayments,
      debtPayments: Array.isArray(parsed.debtPayments) ? parsed.debtPayments : sampleSeedDatabase.debtPayments,
      cashTransactions: Array.isArray(parsed.cashTransactions) ? parsed.cashTransactions : sampleSeedDatabase.cashTransactions,
      auditLog: Array.isArray(parsed.auditLog) ? parsed.auditLog : [],
      returns: Array.isArray(parsed.returns) ? parsed.returns : [],
      discounts: Array.isArray(parsed.discounts) ? parsed.discounts : [],
      stocktakes: Array.isArray(parsed.stocktakes) ? parsed.stocktakes : [],
      stockMovements: Array.isArray(parsed.stockMovements) ? parsed.stockMovements : [],
      closures: Array.isArray(parsed.closures) ? parsed.closures : [],
      exportedInvoices: Array.isArray(parsed.exportedInvoices) ? parsed.exportedInvoices : [],
      settings: { ...defaultSettings, ...(parsed.settings || {}) },
    };
  } catch {
    return sampleSeedDatabase;
  }
}

export function saveDatabase(data: AppDatabase) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('Failed to save to localStorage', e);
  }
}

export function formatMoney(amount: number | undefined | null): string {
  return Number(amount || 0).toLocaleString('ar-YE') + ' ريال';
}

export function exportHtmlTableToExcel(tableId: string, filename: string) {
  const table = document.getElementById(tableId);
  if (!table) {
    alert('لا توجد بيانات للتصدير');
    return;
  }
  const rows = Array.from(table.querySelectorAll('tr'));
  const tableHtml = rows
    .map(
      (r) =>
        '<tr>' +
        Array.from(r.querySelectorAll('th, td'))
          .filter((c) => !c.classList.contains('no-print'))
          .map(
            (c) =>
              '<td>' +
              (c as HTMLElement).innerText
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/\n/g, ' ') +
              '</td>'
          )
          .join('') +
        '</tr>'
    )
    .join('');

  const xls =
    '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><style>table{border-collapse:collapse;font-family:Arial}td{border:1px solid #999;padding:6px}tr:first-child{font-weight:bold;background:#eaf4e8}</style></head><body><table>' +
    tableHtml +
    '</table></body></html>';

  const blob = new Blob(['\ufeff' + xls], { type: 'application/vnd.ms-excel' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename + '.xls';
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}
