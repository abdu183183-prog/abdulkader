import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatQuantityText,
  getPaymentOf,
  calculateProportionalShare,
  calculateCustomerDebt,
  calculateCashBalances,
  calculateDebtAging,
} from './accountingLogic';

test('formatQuantityText formats correctly in Yemeni terms', () => {
  assert.equal(formatQuantityText(0), '0 حبة');
  assert.equal(formatQuantityText(2), 'شكل');
  assert.equal(formatQuantityText(4), 'شكلين');
  assert.equal(formatQuantityText(5), 'شكلين وحبة');
  assert.equal(formatQuantityText(6), '3 أشكال');
  assert.equal(formatQuantityText(7.5), '3 أشكال وحبة ونص');
});

test('getPaymentOf decomposes single & mixed payments correctly', () => {
  const pCash = getPaymentOf({ price: 10000, pay: 'cash' });
  assert.deepEqual(pCash, { cash: 10000, transfer: 0, debt: 0 });

  const pDebt = getPaymentOf({ price: 5000, pay: 'debt' });
  assert.deepEqual(pDebt, { cash: 0, transfer: 0, debt: 5000 });

  const pMixed = getPaymentOf({
    price: 15000,
    pay: 'mixed',
    payments: { cash: 5000, transfer: 7000, debt: 3000 },
  });
  assert.deepEqual(pMixed, { cash: 5000, transfer: 7000, debt: 3000 });

  const pStorage = getPaymentOf({ price: 4000, pay: 'storage' });
  assert.deepEqual(pStorage, { cash: 0, transfer: 0, debt: 0 });
});

test('calculateProportionalShare divides general expenses + storage proportionally by pieces sold', () => {
  // Total sold across all suppliers: 100 pieces
  // Supplier A sold: 40 pieces
  // General expenses: 30,000, Storage value: 10,000 -> Total pool = 40,000
  // Share = 40,000 * 40 / 100 = 16,000
  const share = calculateProportionalShare(100, 40, 30000, 10000);
  assert.equal(share, 16000);
});

test('calculateCustomerDebt deducts payments accurately', () => {
  const sales = [
    { id: 1, date: '2026-10-20', supplier: 'علي', qty: 2, price: 12000, pay: 'debt' as const, customer: 'محمد' },
    { id: 2, date: '2026-10-21', supplier: 'علي', qty: 1, price: 6000, pay: 'mixed' as const, payments: { cash: 2000, transfer: 0, debt: 4000 }, customer: 'محمد' },
  ];
  const payments = [
    { id: 101, date: '2026-10-22', customer: 'محمد', amount: 5000, method: 'cash' as const },
  ];
  // Total debt = 12000 + 4000 = 16000. Paid = 5000. Balance = 11000.
  const debt = calculateCustomerDebt('محمد', sales, payments);
  assert.equal(debt, 11000);
});

test('calculateCashBalances handles internal transfer_to_cash without altering total liquidity', () => {
  const sales = [
    { id: 1, date: '2026-10-25', supplier: 'سعيد', qty: 2, price: 20000, pay: 'cash' as const },
    { id: 2, date: '2026-10-25', supplier: 'سعيد', qty: 2, price: 30000, pay: 'transfer' as const },
  ];
  const cashTransactions = [
    // Move 10,000 from transfer to cash
    { id: 1, date: '2026-10-25', type: 'transfer_to_cash' as const, amount: 10000, method: 'transfer' as const },
  ];
  const bal = calculateCashBalances(sales, [], [], [], cashTransactions);
  // Initial: cash 20000, transfer 30000 (total 50000)
  // After moving 10000 to cash: cash should be 30000, transfer should be 20000 (total 50000)
  assert.equal(bal.cash, 30000);
  assert.equal(bal.transfer, 20000);
  assert.equal(bal.totalLiquidity, 50000);
});

test('calculateDebtAging accurately applies FIFO allocation across aging bins', () => {
  const sales = [
    { id: 1, date: '2026-09-01', supplier: 'سعيد', qty: 2, price: 10000, pay: 'debt' as const, customer: 'أحمد' }, // ~54 days ago
    { id: 2, date: '2026-10-20', supplier: 'سعيد', qty: 1, price: 5000, pay: 'debt' as const, customer: 'أحمد' }, // 5 days ago
  ];
  const payments = [
    { id: 101, date: '2026-10-21', customer: 'أحمد', amount: 6000, method: 'cash' as const }, // pays 6000 of the 10000
  ];
  // Old invoice remaining = 4000 (in 31-60 bucket)
  // Recent invoice remaining = 5000 (in 0-30 bucket)
  const bins = calculateDebtAging('أحمد', sales, payments, '2026-10-25');
  assert.equal(bins[0], 5000); // 0-30 days
  assert.equal(bins[1], 4000); // 31-60 days
  assert.equal(bins[2], 0);    // 61-90 days
  assert.equal(bins[3], 0);    // >90 days
});
