import React, { useState, useEffect } from 'react';
import { AppDatabase } from './types/accounting';
import { loadDatabase, saveDatabase, defaultSettings } from './utils/initialData';
import { calculateCashBalances, calculateCustomerDebt } from './utils/accountingLogic';
import { NavigationGrid, PageId } from './components/NavigationGrid';
import { TopHeader } from './components/TopHeader';
import { PageHeaderBar } from './components/PageHeaderBar';
import { ReceiptModal } from './components/ReceiptModal';
import { WhatsAppModal } from './components/WhatsAppModal';

// Views
import { HomeView } from './components/views/HomeView';
import { ReceiveView } from './components/views/ReceiveView';
import { SaleView } from './components/views/SaleView';
import { InventoryView } from './components/views/InventoryView';
import { ExpensesView } from './components/views/ExpensesView';
import { NetView } from './components/views/NetView';
import { AccountsView } from './components/views/AccountsView';
import { ContactsAndLedgersView } from './components/views/ContactsAndLedgersView';
import { ReportsView } from './components/views/ReportsView';
import { ControlAndSettingsView } from './components/views/ControlAndSettingsView';

export default function App() {
  const [db, setDb] = useState<AppDatabase>(() => loadDatabase());
  const [activePage, setActivePage] = useState<PageId>('home');
  const [showGridInSubpage, setShowGridInSubpage] = useState<boolean>(false);
  const [isDark, setIsDark] = useState<boolean>(() => {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  // Receipt Modal State
  const [receiptData, setReceiptData] = useState<{
    title: string;
    items: { label: string; value: string | number }[];
    notes?: string;
  } | null>(null);
  const [isReceiptOpen, setIsReceiptOpen] = useState(false);

  // WhatsApp Modal State
  const [whatsAppData, setWhatsAppData] = useState<{
    title: string;
    recipientName: string;
    defaultPhone?: string;
    messageText: string;
  } | null>(null);
  const [isWhatsAppOpen, setIsWhatsAppOpen] = useState(false);

  // Sync dark class on document root
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  // Save changes to localStorage
  const handleUpdateDb = (updater: (prev: AppDatabase) => AppDatabase) => {
    setDb((prev) => {
      const next = updater(prev);
      saveDatabase(next);
      return next;
    });
  };

  const handleOpenReceipt = (data: {
    title: string;
    items: { label: string; value: string | number }[];
    notes?: string;
  }) => {
    setReceiptData(data);
    setIsReceiptOpen(true);
  };

  const handleOpenWhatsApp = (data: {
    title: string;
    recipientName: string;
    defaultPhone?: string;
    messageText: string;
  }) => {
    setWhatsAppData(data);
    setIsWhatsAppOpen(true);
  };

  const balances = calculateCashBalances(
    db.sales,
    db.expenses,
    db.debtPayments,
    db.supplierPayments,
    db.cashTransactions
  );

  const customerNames = Array.from(
    new Set([
      ...db.customers.map((c) => c.name),
      ...db.sales.map((s) => s.customer || ''),
      ...db.debtPayments.map((p) => p.customer),
    ].filter(Boolean))
  );

  const totalAllDebt = customerNames.reduce(
    (sum, c) => sum + calculateCustomerDebt(c, db.sales, db.debtPayments),
    0
  );

  const totalSalesVal = db.sales.reduce((sum, s) => sum + Number(s.price || 0), 0);

  const handleSelectPage = (pageId: PageId) => {
    setActivePage(pageId);
    setShowGridInSubpage(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-stone-100 dark:bg-stone-950 text-stone-900 dark:text-stone-100 transition-colors duration-200">
      {/* Top Header with Store Branding & Metrics Ticker */}
      <TopHeader
        settings={db.settings || defaultSettings}
        isDark={isDark}
        onToggleTheme={() => setIsDark((prev) => !prev)}
        metrics={{
          cash: balances.cash,
          transfer: balances.transfer,
          totalLiquidity: balances.totalLiquidity,
          totalSales: totalSalesVal,
          customerDebt: totalAllDebt,
        }}
      />

      <main className="max-w-7xl mx-auto px-3 sm:px-4 py-3 sm:py-5">
        {/* On Home View: Display the full Navigation Grid (بكل صف 2 أزرار) prominently */}
        {activePage === 'home' && (
          <div className="mb-6 animate-in fade-in duration-200">
            <NavigationGrid
              activePage={activePage}
              onSelectPage={handleSelectPage}
            />
          </div>
        )}

        {/* When in any inner view: Display sticky bar with "رجوع لشبكة الأزرار" + option to toggle grid */}
        {activePage !== 'home' && (
          <div className="space-y-4">
            <PageHeaderBar
              currentPageId={activePage}
              onBackToGrid={() => {
                setActivePage('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onSelectPage={handleSelectPage}
              onPrint={() => window.print()}
              isGridOpen={showGridInSubpage}
              onToggleGrid={() => setShowGridInSubpage((prev) => !prev)}
            />

            {/* Optional drop-down/drawer grid when inside subpage */}
            {showGridInSubpage && (
              <div className="p-3 bg-stone-200/80 dark:bg-stone-900/90 rounded-2xl border border-stone-300 dark:border-stone-800 animate-in fade-in duration-150">
                <NavigationGrid
                  activePage={activePage}
                  onSelectPage={handleSelectPage}
                />
              </div>
            )}
          </div>
        )}

        {/* Active Page View Component */}
        <div className="transition-all duration-150">
          {activePage === 'home' && <HomeView db={db} onNavigate={handleSelectPage} />}

          {activePage === 'receive' && (
            <ReceiveView
              db={db}
              onUpdateDb={handleUpdateDb}
              onOpenReceipt={handleOpenReceipt}
              onOpenWhatsApp={handleOpenWhatsApp}
            />
          )}

          {activePage === 'sale' && (
            <SaleView
              db={db}
              onUpdateDb={handleUpdateDb}
              onOpenReceipt={handleOpenReceipt}
              onOpenWhatsApp={handleOpenWhatsApp}
            />
          )}

          {activePage === 'inventory' && <InventoryView db={db} />}

          {activePage === 'expense' && <ExpensesView db={db} onUpdateDb={handleUpdateDb} />}

          {activePage === 'net' && <NetView db={db} />}

          {activePage === 'accounts' && <AccountsView db={db} onUpdateDb={handleUpdateDb} />}

          {/* Contacts & Statements Views */}
          {(activePage === 'supplier' ||
            activePage === 'customers' ||
            activePage === 'supplierStatement' ||
            activePage === 'customerStatement' ||
            activePage === 'supplierPayments' ||
            activePage === 'customerPayments' ||
            activePage === 'customerDebtAging' ||
            activePage === 'contacts45') && (
            <ContactsAndLedgersView
              db={db}
              activeSubView={activePage as any}
              onUpdateDb={handleUpdateDb}
              onOpenWhatsApp={handleOpenWhatsApp}
            />
          )}

          {/* Reports Views */}
          {(activePage === 'report' ||
            activePage === 'periodReport' ||
            activePage === 'profit46' ||
            activePage === 'match46' ||
            activePage === 'storageReport') && (
            <ReportsView db={db} activeSubView={activePage as any} />
          )}

          {/* Control, Settings & Additional Tracking */}
          {(activePage === 'control47' ||
            activePage === 'dashboard50' ||
            activePage === 'backup' ||
            activePage === 'backup48' ||
            activePage === 'settings' ||
            activePage === 'invoiceHistory' ||
            activePage === 'returns' ||
            activePage === 'discounts' ||
            activePage === 'stocktake' ||
            activePage === 'stockMovement' ||
            activePage === 'cashbox' ||
            activePage === 'transfers' ||
            activePage === 'openingBalances') && (
            <ControlAndSettingsView
              db={db}
              activeSubView={activePage as any}
              onUpdateDb={handleUpdateDb}
              onOpenReceipt={handleOpenReceipt}
            />
          )}
        </div>
      </main>

      {/* Printable Receipt Modal */}
      <ReceiptModal
        isOpen={isReceiptOpen}
        onClose={() => setIsReceiptOpen(false)}
        receiptData={receiptData}
        settings={db.settings || defaultSettings}
      />

      {/* Interactive WhatsApp Send Modal */}
      {whatsAppData && (
        <WhatsAppModal
          isOpen={isWhatsAppOpen}
          onClose={() => setIsWhatsAppOpen(false)}
          title={whatsAppData.title}
          recipientName={whatsAppData.recipientName}
          defaultPhone={whatsAppData.defaultPhone}
          messageText={whatsAppData.messageText}
        />
      )}
    </div>
  );
}
